const PacketType = require('../protocol/PacketType');
const BasicRule = require('../rules/BasicRule');
const RenjuRule = require('../rules/RenjuRule');
const MatchService = require('../services/MatchService');
const PlayerSession = require('../sessions/PlayerSession');
const UserService = require('../services/UserService');
const BadWordService = require('../services/BadWordService');

class GameRoom {
    constructor(roomId, roomManager, turnTimeLimit) {
        this.roomId = roomId;
        this.roomManager = roomManager;
        this.turnTimeLimit = turnTimeLimit;   // 🔥 방 시간 제한

        this.currentMatch = null;   // 현재 진행 중인 경기
        this.lastMatchId = null;    // 가장 최근에 진행한 경기

        this.players = [];
        this.maxPlayers = 2;
    
        this.readyState = new Map(); // playerId → ready
        this.missCount = new Map();  // playerId -> 연속 시간초과 횟수

        this.rule = new RenjuRule(19);
        this.board = Array(19).fill(0).map(() => Array(19).fill(0));

        this.moveHistory = [];

        // 흑백 슬롯 설정
        this.slots = [
            { playerId: null, value: null },
            { playerId: null, value: null },
            { playerId: null, value: null }
        ];

        this.colorPicker = {
            selectedPlayerId: null,
            blackPlayerId: null
        };



        this.turn = 1;
        this.isGameOver = false;
        this.isStarted = false;

        // 플레이어별 stall 타이머
        this.stallTimers = new Map();

        this.undoVotes = new Map();   // playerId → true/false
        this.undoEnabled = false;
        this.isUndoVoting = false;

        this.undoTimer = null;
        this.isGamePaused = false;

        // 🔥 게임 상태 통합 객체(state 객체)
        this.state = {
            phase: "WAITING", // WAITING | COLOR_PICK | PLAYING | UNDO_VOTING | RESTART_PENDING | GAME_OVER

            turn: 1,
            turnTimeLimit: turnTimeLimit,
            turnStartTime: null,

            undo: {
                isVoting: false,
                requester: null,
                startTime: null
            },

            restart: {
                isPending: false,
                requester: null
            },

            game: {
                isOver: false,
                winner: null
            }
        };

        /* 
        A → 요청 → B에게 request 보냄

        "3가지 경우의 수"
            1: B → accept → resetGame + countdown
            2: B → reject → A에게 거절 알림
            3: A → cancel → B UI 닫힘
        */
        this.replayState = new Map(); // playerId → true/false
        this.restartRequester = null; // 요청한 플레이어
    }

    getPlayerProfile(session) {
        return {
            playerId: session.playerId,
            uid: session.uid,
            nickname: session.nickname,
            avatarIndex: session.avatarIndex,

            win: session.win || 0,
            lose: session.lose || 0,
            tier: session.tier || 10
        };
    }

    // 방 입장
    addPlayer(session) {

        const usedIds = this.players.map(p => p.playerId);

        let playerId = null;

        if (!usedIds.includes(1)) playerId = 1;
        else if (!usedIds.includes(2)) playerId = 2;
        else {
            session.send({ type: "FULL" });
            return;
        }

        session.playerId = playerId;
        session.room = this;

        this.players.push(session);

        this.readyState.set(playerId, false);
        this.missCount.set(playerId, 0);

        // 🔥 채팅 상태 초기화
        session.warnCount = 0;
        session.blockUntil = 0;
        session.permaBlocked = false;
        session.chatHistory = [];

        // 🔥 네트워크 상태
        session.isConnected = true;
        session.isBackground = false;
        session.disconnectCount = 0;
        session.backgroundCount = 0;
        session.timeoutTimer = null;

        // 🔥 JOINED
        session.send({
            type: "JOINED",
            playerId,
            roomId: this.roomId
        });

        // 🔥 PLAYER LIST
        this.broadcast({
            type: "PLAYER_LIST",
            players: this.players.map(p => this.getPlayerProfile(p))
        });

        if (this.players.length === 1) {
            session.send({ type: "WAIT" });
        }

        if (this.players.length === 2) {
            this.broadcast({ type: "ROOM_FULL" });
        }
    }

    // disconnect → 30초 유예 → 복귀하면 살림 → 안 오면 패배
    removePlayer(session) {

        // 🔥 기존: ws.playerId → session.playerId
        const leaverId = session.playerId;

        console.log(`❌ P${leaverId} 나감`);

        // 🔥 채팅 상태 정리 (session 기준)
        session.warnCount = 0;
        session.blockUntil = 0;
        session.permaBlocked = false;
        session.chatHistory = [];

        // 🔥 플레이어 제거
        this.players = this.players.filter(p => p !== session);

        this.readyState.delete(leaverId);
        this.replayState.delete(leaverId);
        this.missCount.delete(leaverId);

        this.clearTurnTimer();

        // 🔥 session 초기화 (ws ❌)
        session.room = null;
        session.playerId = null;

        // ========================================
        // 🔥 Undo / Restart 중 disconnect 처리
        // ========================================

        // 🔥 undo 투표 중이면 자동 승인
        if (this.state.phase === "UNDO_VOTING") {
            console.log("⚠️ 상대 disconnect → undo 자동 승인");

            this.applyUndo(); // 네 기존 undo 적용 함수
            return;
        }

        // 🔥 restart 요청 중이면 취소
        if (this.state.phase === "RESTART_PENDING") {
            console.log("⚠️ 상대 disconnect → restart 취소");

            this.state.phase = "PLAYING";
            this.state.restart.isPending = false;
            this.state.restart.requester = null;

            this.broadcast({
                type: PacketType.RESTART_CANCEL
            });

            return;
        }

        // 🔥 게임 중이면 종료 처리
        if (this.isStarted && !this.isGameOver) {

            let winner = -1;

            if (this.players.length === 1) {
                winner = this.players[0].playerId;
            }

            this.isGameOver = true;
            this.state.phase = "GAME_OVER";
            this.state.game.isOver = true;
            this.state.game.winner = winner;
            
            const endMatchId = this.lastMatchId ?? this.currentMatch?.matchId ?? null;

            this.broadcast({
                type: "END",
                winner: winner,
                reason: "DISCONNECT",
                winLine: [],
                matchId: endMatchId
            });
            
            console.log("🔥 END currentMatch:", this.currentMatch);
            console.log("🔥 END matchId:", this.currentMatch?.matchId);

            if (this.currentMatch) {
                this.currentMatch.winner = winner;
                this.currentMatch.winLine = [];
                this.currentMatch.endedAt = Date.now();
                
                // 대국 저장
                MatchService.saveMatch(this.currentMatch);
                this.lastMatchId = this.currentMatch.matchId;
            }

            console.log(`🏆 Disconnect 종료 → winner: P${winner}`);
        }

        // 🔥 한 명 남았을 때 초기화
        if (this.players.length === 1) {
            const remaining = this.players[0];

            this.readyState.clear();
            this.readyState.set(remaining.playerId, false);

            this.replayState.clear();
            this.replayState.set(remaining.playerId, false);

            this.isStarted = false;
            this.restartRequester = null;

            this.board = Array(19).fill(0).map(() => Array(19).fill(0));
            this.turn = 1;

            remaining.send({ type: "WAIT" });
        }

        // 🔥 아무도 없을 때 초기화
        if (this.players.length === 0) {
            this.readyState.clear();
            this.replayState.clear();
            this.missCount.clear();

            this.isStarted = false;
            this.isGameOver = false;
            this.restartRequester = null;
            this.turn = 1;

            this.board = Array(19).fill(0).map(() => Array(19).fill(0));
        }

        // 🔥 핵심: 상태 다시 브로드캐스트
        this.broadcast({
            type: "PLAYER_LIST",
            players: this.players.map(p => this.getPlayerProfile(p))
        });

        // 🔥 방 목록 갱신
        this.roomManager.broadcastRoomListByTime(this.turnTimeLimit);
    }

    setReady(session, isReady) {

        this.readyState.set(session.playerId, isReady);

        this.broadcast({
            type: "READY",
            playerId: session.playerId,
            isReady: isReady
        });

        console.log(`P${session.playerId} READY: ${isReady}`);

        // 🔥 둘 다 준비됐을 때만 시작
        if (this.players.length === 2 &&
            [...this.readyState.values()].every(v => v === true)) {

            this.startUndoOption();
        }
    }

    setReplay(player) {

        this.replayState.set(player.playerId, true);

        this.broadcast({
            type: "REPLAY",
            playerId: player.playerId
        });

        console.log(`P${player.playerId} REPLAY 요청`);

        // 🔥 둘 다 다시하기 눌렀으면 재시작
        if (this.players.length === 2 &&
            [...this.replayState.values()].every(v => v === true)) {

            console.log("🔥 REPLAY → 게임 리셋");

            this.resetGame();
            this.startCountdown();
        }
    }

    startCountdown() {
        let seconds = 3;

        const interval = setInterval(() => {

            this.broadcast({
                type: "COUNTDOWN",
                seconds: seconds
            });

            if (seconds <= 0) {
                console.log("🔥 COUNTDOWN 시작됨");
                clearInterval(interval);
                this.startGame();
            }

            seconds--;

        }, 1000);
    }

    startUndoOption() {
        this.isUndoVoting = true;
        this.undoVotes.clear();

        this.players.forEach(p => {
            this.undoVotes.set(p.playerId, null);
        });

        this.broadcast({
            type: "UNDO_OPTION_START"
        });

        console.log("🧠 Undo 투표 시작");
    }

    startColorPick() {
        this.state.phase = "COLOR_PICK";

        this.colorPicker.selectedPlayerId = null;
        this.colorPicker.blackPlayerId = null;

        this.broadcast({
            type: "COLOR_PICK_START",
            timeLimit: 10,
            startTime: Date.now()
        });

        console.log("🎲 COLOR_PICK 시작");

        // 🔥 추가
        this.startColorPickTimer();
    }

    handlePickColor(session, slotIndex) {

        if (this.state.phase !== "COLOR_PICK") return;
        if (slotIndex < 0 || slotIndex >= 3) return;

        // 이미 선택된 슬롯이면 무시
        if (this.slots[slotIndex].playerId != null) return;

        // 중복 선택 방지: 이미 이 플레이어가 선택했으면 무시
        if (this.slots.some(s => s.playerId === session.playerId)) return;

        // 🔥 1️⃣ 먼저 슬롯 선점
        this.slots[slotIndex].playerId = session.playerId;

        // 🔥 중요： 즉시 브로드캐스트 (랜덤값 없음)
        this.broadcast({
            type: "SLOT_LOCKED",
            slotIndex: slotIndex,
            playerId: session.playerId
        });

        // 🔥 2️⃣ 랜덤값 생성
        const usedValues = this.slots
            .filter(s => s.value != null)
            .map(s => s.value);

        const value = this.getRandomValue(usedValues);

        this.slots[slotIndex].value = value;

        // 🔥 3️⃣ 결과 브로드캐스트
        this.broadcast({
            type: "COLOR_PICK_UPDATE",
            slotIndex: slotIndex,
            playerId: session.playerId,
            value: value
        });

        const selectedCount = this.slots.filter(s => s.playerId != null).length;

        if (selectedCount === 2) {

            // 타이머 종료
            if (this.colorPickTimer) {
                clearTimeout(this.colorPickTimer);
                this.colorPickTimer = null;
            }

            const selectedSlots = this.slots.filter(s => s.playerId != null);

            const s1 = selectedSlots[0];
            const s2 = selectedSlots[1];

            // 흑백 결정
            if (s1.value > s2.value) {
                this.colorPicker.blackPlayerId = s1.playerId;
            } else {
                this.colorPicker.blackPlayerId = s2.playerId;
            }

            console.log("🎯 BLACK:", this.colorPicker.blackPlayerId);

            this.startCountdown();
        }
    }

    getRandomValue(excludeValues) {
        let value;

        do {
            value = Math.floor(Math.random() * 9) + 1; // 1~9
        } while (excludeValues.includes(value));

        return value;
    }

    // COLOR PICK 타이머
    startColorPickTimer() {
        // 기존 타이머 제거
        if (this.colorPickTimer) {
            clearTimeout(this.colorPickTimer);
        }

        this.colorPickTimer = setTimeout(() => {
            console.log("⏰ COLOR_PICK 시간 초과");

            this.autoPickIfNeeded();

        }, 10000); // 10초
    }

    // 자동 선택 로직
    autoPickIfNeeded() {

        if (this.state.phase !== "COLOR_PICK") return;

        const pickedPlayers = this.slots
            .filter(s => s.playerId != null)
            .map(s => s.playerId);

        const notPickedPlayers = this.players.filter(p => 
            !pickedPlayers.includes(p.playerId)
        );

        for (const player of notPickedPlayers) {

            // 남은 슬롯 찾기
            const availableSlots = this.slots
                .map((s, i) => s.playerId == null ? i : -1)
                .filter(i => i !== -1);

            if (availableSlots.length === 0) continue;

            const randomSlot = availableSlots[
                Math.floor(Math.random() * availableSlots.length)
            ];

            console.log(`🤖 자동 선택: P${player.playerId} → 슬롯 ${randomSlot}`);

            this.handlePickColor(player, randomSlot);
        }
    }

    handleUndoOption(player, agree) {

        if (!this.isUndoVoting) return;

        this.undoVotes.set(player.playerId, agree);

        this.broadcast({
            type: "UNDO_VOTE",
            playerId: player.playerId,
            agree: agree
        });

        // 🔥 둘 다 선택했는지 체크
        const votes = [...this.undoVotes.values()];

        if (votes.every(v => v !== null)) {

            this.isUndoVoting = false;

            // 🔥 하나라도 false면 실패
            this.undoEnabled = votes.every(v => v === true);

            this.broadcast({
                type: "UNDO_OPTION_RESULT",
                enabled: this.undoEnabled
            });

            console.log("🧠 Undo 결과:", this.undoEnabled);

            // 👉 결과 보여주고 3초 후 흑백 결정 시작
            setTimeout(() => {
                this.startColorPick();
            }, 3000);
        }
    }

    handleUndoVote(player, agree) {

        if (!this.isUndoVoting) return;

        this.undoVotes.set(player.playerId, agree);

        // 🔥 둘 다 선택했는지 체크
        const votes = [...this.undoVotes.values()];

        if (votes.every(v => v !== null)) {

            clearTimeout(this.undoTimer); 

            this.isUndoVoting = false;
            this.isGamePaused = false;

            const success = votes.every(v => v === true);

            this.broadcast({
                type: "UNDO_RESULT",
                enabled: success
            });

            if (success) {
                this.applyUndo();
            }

            // 🔥 게임 재개
            this.startTurnTimer(this.turn);
        }
    }

    handleUndoRequest(player) {

        // 🔥 기능 비활성화면 무시
        if (!this.undoEnabled) return;

        if (this.state.phase !== "PLAYING") {
            console.log("⚠️ 비정상 UNDO 차단:", this.state.phase);
            return;
        }
        // 🔥 이미 투표 중이면 무시
        if (this.isUndoVoting) return;

        this.state.phase = "UNDO_VOTING";
        this.state.undo.isVoting = true;
        this.state.undo.requester = player.playerId;
        this.state.undo.startTime = Date.now();

        this.isGamePaused = true;
        this.clearTurnTimer();    // 🔥 게임 타이머 멈춤

        this.undoVotes.clear();

        this.players.forEach(p => {
            this.undoVotes.set(p.playerId, null);
        });

        console.log(`🧠 P${player.playerId} 무르기 요청`);

        // 무르기 요청자 자동 승인 처리
        this.undoVotes.set(player.playerId, true);


        // 🔥 핵심: 투표 시작 브로드캐스트
        this.broadcast({
            type: "UNDO_VOTE_START",
            requester: player.playerId,
            startTime: this.state.undo.startTime
        });


        // 🔥 Undo 제한 시간 20초
        this.undoTimer = setTimeout(() => {
            this.handleUndoTimeout();
        }, 20000);
    }

    // Timeout 처리
    handleUndoTimeout() {

        if (!this.isUndoVoting) return;

        console.log("⏰ Undo 시간 초과");

        this.isUndoVoting = false;
        this.state.phase = "PLAYING";
        this.state.undo.isVoting = false;
        this.state.undo.requester = null;
        this.state.undo.startTime = null;

        this.isGamePaused = false;
        this.undoVotes.clear();
        this.undoRequester = null;

        this.broadcast({
            type: "UNDO_CANCEL"
        });

        // 🔥 게임 재개
        this.startTurnTimer(this.turn);
    }

    handleChat(session, message) {

        if (!message || message.trim().length === 0)
            return;

        const now = Date.now();

        // =========================================
        // 🔥 1. 영구 차단 체크
        // =========================================
        if (session.permaBlocked) {
            session.send({
                type: "PERMA_BLOCK",
                message: "채팅이 영구 제한되었습니다."
            });
            return;
        }

        // =========================================
        // 🔥 2. 일시 차단 체크
        // =========================================
        if (session.blockUntil && now < session.blockUntil) {
            const remain = Math.ceil((session.blockUntil - now) / 1000);

            session.send({
                type: "BLOCK",
                message: `채팅 제한 중 (${remain}초)`
            });
            return;
        }

        // =========================================
        // 🔥 3. 길이 제한
        // =========================================
        if (message.length > 30)
            message = message.substring(0, 30);

        const lower = message.toLowerCase();

        // =========================================
        // 🔥 4. 욕설 필터 (업그레이드 버전)
        // =========================================
        if (BadWordService.isBad(message)) {

            // 🔥 warn 초기화 (60초 지나면 리셋)
            if (!session.lastWarnTime || now - session.lastWarnTime > 60000) {
                session.warnCount = 0;
            }
            session.lastWarnTime = now;

            session.warnCount++;

            // 🔥 로그 (운영 핵심)
            console.log(`🚫 욕설 감지: ${message} / uid=${session.uid}`);

            // 🔥 3회 누적 → 영구 차단
            if (session.warnCount >= 3) {
                session.permaBlocked = true;

                session.send({
                    type: "PERMA_BLOCK",
                    message: "욕설 누적으로 채팅이 영구 제한되었습니다."
                });

                return;
            }

            // 🔥 10초 차단
            session.blockUntil = now + 10000;

            session.send({
                type: "BLOCK",
                message: "욕설 사용으로 10초 제한"
            });

            return;
        }

        // =========================================
        // 🔥 5. 도배 검사
        // =========================================
        session.chatHistory = session.chatHistory.filter(t => now - t < 3000);
        session.chatHistory.push(now);

        if (session.chatHistory.length >= 5) {
            session.blockUntil = now + 5000;

            session.send({
                type: "BLOCK",
                message: "도배로 인해 5초 제한"
            });

            return;
        }

        // =========================================
        // 🔥 6. 정상 채팅
        // =========================================
        this.broadcast({
            type: "CHAT",
            playerId: session.playerId,
            message: message,
            timestamp: Date.now()
        });
    }

    handleTyping(player, isTyping) {
        this.broadcast({
            type: isTyping ? "TYPING_START" : "TYPING_STOP",
            playerId: player.playerId
        });
    }

    startGame() {
        this.isStarted = true;
        this.currentMatch = MatchService.createMatch(this);
        this.isGameOver = false;
        this.turn = this.colorPicker.blackPlayerId ?? 1;

        this.state.phase = "PLAYING";
        this.state.turn = this.turn;
        this.state.game.isOver = false;
        this.state.game.winner = null;
        this.state.turnStartTime = Date.now();

        // 🔥 miss count 초기화
        this.missCount.set(1, 0);
        this.missCount.set(2, 0);

        this.players.forEach(p => {
            p.send({
                type: "START",
                turn: this.turn,
                playerId: p.playerId,          // 🔥 내 playerId
                uid: p.uid,                    // 🔥 내 uid
                nickname: p.nickname,          // 🔥 내 nickname
                avatarIndex: p.avatarIndex,    // 🔥 내 avatar
                turnTimeLimit: this.turnTimeLimit,
                turnStartTime: this.state.turnStartTime,
                players: this.players.map(x => this.getPlayerProfile(x)), // 🔥 방 전체 프로필
                blackPlayerId: this.colorPicker.blackPlayerId
            });
        });

        // 🔥 UI miss count 초기화용
        this.broadcast({
            type: PacketType.MISS_COUNT,
            playerId: 1,
            missCount: 0
        });

        this.broadcast({
            type: PacketType.MISS_COUNT,
            playerId: 2,
            missCount: 0
        });

        this.startTurnTimer(this.turn);

        
        console.log(`🚀 Room ${this.roomId} 게임 시작 (${this.turnTimeLimit}초)`);
    }

    resetGame() {

        this.board = Array(19).fill(0).map(() => Array(19).fill(0));

        this.moveHistory = [];

        this.turn = 1;
        this.isGameOver = false;
        this.isStarted = false;
        this.state.phase = "WAITING";
        this.state.turn = 1;
        this.state.game.isOver = false;
        this.state.game.winner = null;

        // 🔥 준비 상태 초기화
        this.readyState.set(1, false);
        this.readyState.set(2, false);

        // 🔥 턴 순서 초기화(흑, 백)
        this.colorPicker.selectedPlayerId = null;
        this.colorPicker.blackPlayerId = null;

        // 🔥 턴 상태 초기화
        this.clearTurnTimer();
        this.missCount.set(1, 0);
        this.missCount.set(2, 0);

        // 🔥 replay 상태 초기화
        this.replayState.set(1, false);
        this.replayState.set(2, false);

        // 🔥 restart 상태 초기화
        this.restartRequester = null;
    }

    // 🔥 공통 INVALID 전송
    sendInvalid(session, reason) {
        session.send({
            type: "INVALID",
            reason
        });
    }

    // 🔥 전체 브로드캐스트
    broadcast(data) {
        console.log("📡 브로드캐스트:", data);

        this.players.forEach(p => {
            p.send(data);
        });
    }

    clearTurnTimer() {
        if (this.turnTimer !== null) {
            clearTimeout(this.turnTimer);
            this.turnTimer = null;
        }
    }

    // 🔥 남은 시간 기준으로 타이머 시작 가능하게 수정
    startTurnTimer(playerId, remainingTime = null) {
        this.clearTurnTimer();

        // 🔥 재접속 복구 시 남은 시간 기준으로 다시 시작
        const timeToUse = (remainingTime != null) ? remainingTime : this.turnTimeLimit;

        // 🔥 turnStartTime도 역산해서 맞춰줌
        this.state.turnStartTime = Date.now() - ((this.turnTimeLimit - timeToUse) * 1000);

        this.turnTimer = setTimeout(() => {
            if (this.isGameOver || !this.isStarted) return;

            console.log(`⏰ P${playerId} 시간 초과`);

            let count = this.missCount.get(playerId) || 0;
            count++;
            this.missCount.set(playerId, count);

            this.broadcast({
                type: PacketType.MISS_COUNT,
                playerId: playerId,
                missCount: count
            });

            if (count >= 3) {
                const winner = (playerId === 1) ? 2 : 1;

                // UI 보내기 전에 데이터 반영
                const winnerSession = this.players.find(p => p.playerId === winner);
                const loserSession = this.players.find(p => p.playerId === playerId);

                if (winnerSession && loserSession) {
                    // 중복 END / reconnect / disconnect 상황 방어
                    if (this.currentMatch?.endedAt != null) return;

                    UserService.applyMatchResult(winnerSession, loserSession);
                }

                // 상태 변화
                this.isGameOver = true;
                this.state.phase = "GAME_OVER";
                this.state.game.isOver = true;
                this.state.game.winner = winner;

                this.clearTurnTimer();

                const endMatchId = this.lastMatchId ?? this.currentMatch?.matchId ?? null;

                this.broadcast({
                    type: "END",
                    winner: winner,
                    reason: "TIMEOUT",
                    winLine: [],
                    matchId: endMatchId
                });

                if (this.currentMatch) {
                    // 🔥 중복 저장 방지
                    if (this.currentMatch.endedAt == null) {
                        this.currentMatch.winner = winner;
                        this.currentMatch.winLine = [];
                        this.currentMatch.endedAt = Date.now();

                        // 대국 저장
                        this.finalizeGame(winnerSession, loserSession, [], "TIMEOUT");
                    }
                }

                return;
            }

            this.turn = (playerId === 1) ? 2 : 1;
            this.state.turn = this.turn;
            this.state.turnStartTime = Date.now();

            const nextPlayer = this.players.find(p => p.playerId === this.turn);

            // 🔥 턴 브로드캐스트
            this.broadcast({
                type: PacketType.TURN,
                turn: this.turn,
                turnStartTime: this.state.turnStartTime
            });

            // 🔥 턴 시작 시 background 상태면 5초 체크
            if (nextPlayer && (nextPlayer.isBackground || !nextPlayer.isConnected)) {
                this.startStallCheck(nextPlayer, "TURN_STALL");
            }

            this.startTurnTimer(this.turn);

        }, timeToUse * 1000);
    }

    // 타이머 함수
    startDisconnectTimeout(player, reason) {
        this.clearDisconnectTimeout(player);

        player.timeoutTimer = setTimeout(() => {
            if (this.isGameOver) return;
            if (!player.isAwaitingReturn) return;

            console.log(`⏰ ${player.uid} ${reason} 30초 초과 → 패배`);
            this.forceLose(player, reason);
        }, 30000);
    }

    clearDisconnectTimeout(player) {
        if (player.timeoutTimer) {
            clearTimeout(player.timeoutTimer);
            player.timeoutTimer = null;
        }
    }

    // 🔥 현재 턴의 남은 시간 계산
    getRemainingTurnTime() {

        // 게임 중이 아니면 기본 턴 시간 반환
        if (!this.isStarted || this.isGameOver || !this.state.turnStartTime) {
            return this.state.turnTimeLimit;
        }

        const elapsedSec = Math.floor((Date.now() - this.state.turnStartTime) / 1000);
        const remaining = this.state.turnTimeLimit - elapsedSec;

        return Math.max(0, remaining);
    }

    markPlayerAway(session, reason) {
        if (!session || this.isGameOver || !this.isStarted) return;

        // 이미 away 상태면 중복 처리 방지
        if (session.isTemporarilyAway) return;

        session.isTemporarilyAway = true;
        session.awayReason = reason; // BACKGROUND | NETWORK
        session.awayStartedAt = Date.now();
        session.hasDisconnectPenaltyOnCurrentAway = false;
        session.pendingStallTurn = this.turn; // 현재 턴 스냅샷
    }

    shouldCountAsStallNow(session) {
        if (!session || !session.isTemporarilyAway) return false;
        if (session.hasDisconnectPenaltyOnCurrentAway) return false;
        if (this.state.phase !== "PLAYING") return false;

        // 지금 이 플레이어 턴이라면 실제 진행 방해 상태
        return this.turn === session.playerId;
    }

    // 5초 타이머 시작 함수
    startStallCheck(session, reason) {
        const playerId = session.playerId;

        // 기존 타이머 있으면 제거
        if (this.stallTimers.has(playerId)) {
            clearTimeout(this.stallTimers.get(playerId));
        }

        const timer = setTimeout(() => {

            // 🔥 5초 후에도 여전히 background면 제재
            if (!session.isConnected || session.isBackground) {
                console.log(`⏱️ 5초 경과 → P${playerId} 제재 적용 (${reason})`);
                this.applyStallCount(session, reason);
            } else {
                console.log(`⏱️ 5초 내 복귀 → P${playerId} 제재 취소`);
            }

            this.stallTimers.delete(playerId);

        }, 5000);

        this.stallTimers.set(playerId, timer);
    }

    // 타이머 취소 함수
    cancelStallCheck(session) {
        const playerId = session.playerId;

        if (this.stallTimers.has(playerId)) {
            clearTimeout(this.stallTimers.get(playerId));
            this.stallTimers.delete(playerId);
        }
    }

    applyStallCount(session, reason) {
        session.hasDisconnectPenaltyOnCurrentAway = true;
        session.stallCount = (session.stallCount || 0) + 1;

        console.log(`⚠️ P${session.playerId} 진행 방해 카운트 ${session.stallCount}회 (${reason})`);

        // 3번째면 즉시 패배
        if (session.stallCount >= 3) {
            this.forceLose(session, `${reason}_LIMIT`);
            return;
        }

        this.pauseForDisconnectedPlayer(session, reason);
    }

    pauseForDisconnectedPlayer(session, reason) {
        if (this.isGameOver || !this.isStarted) return;
        if (this.isGamePaused) return;

        this.isGamePaused = true;
        this.pausedRemainingTurnTime = this.getRemainingTurnTime();
        this.clearTurnTimer();

        session.isAwaitingReturn = true;

        const opponent = this.players.find(p => p !== session);
        if (!opponent) return;
        
        // session: 연결 끊긴 플레이어
        // 상대방에게 session이 끊겼다고 알림
        opponent.send({
            type: "OPPONENT_DISCONNECTED",
            playerId: session.playerId,
            reason,
            timeout: 30,
            startTime: Date.now(),
            disconnectCount: session.stallCount || 0
        });
        
        // 동기화 목적
        session.send({
            type: "OPPONENT_DISCONNECTED",
            playerId: session.playerId,
            reason,
            timeout: 30,
            startTime: Date.now(),
            disconnectCount: session.stallCount || 0
        });

        this.startDisconnectTimeout(session, reason);
    }

    // 백그라운드 → 앱 복귀 시
    resumeFromAway(session) {
        this.clearDisconnectTimeout(session);

        // 복귀 시 타이머 취소
        this.cancelStallCheck(session);

        session.isTemporarilyAway = false;
        session.isBackground = false;
        session.isConnected = true;
        session.isAwaitingReturn = false;
        session.awayReason = null;
        session.pendingStallTurn = null;
        session.hasDisconnectPenaltyOnCurrentAway = false;

        this.broadcast({
            type: "OPPONENT_RECONNECTED",
            playerId: session.playerId
        });

        if (this.isGamePaused && !this.isGameOver && this.isStarted) {
            this.isGamePaused = false;
            this.startTurnTimer(this.turn, this.pausedRemainingTurnTime ?? this.turnTimeLimit);
            this.pausedRemainingTurnTime = null;
        }
    }

    handleDisconnectDuringVote(session, reason) {
        // 1) 게임 시작 전 무르기 옵션 투표
        if (this.isUndoVoting && this.state.phase !== "UNDO_VOTING" && this.state.phase !== "PLAYING") {
            this.undoVotes.set(session.playerId, false);

            this.broadcast({
                type: "UNDO_VOTE",
                playerId: session.playerId,
                agree: false
            });

            const votes = [...this.undoVotes.values()];
            if (votes.every(v => v !== null)) {
                this.isUndoVoting = false;
                this.undoEnabled = votes.every(v => v === true);

                this.broadcast({
                    type: "UNDO_OPTION_RESULT",
                    enabled: this.undoEnabled
                });

                setTimeout(() => this.startCountdown(), 3000);
            }
            return true;
        }

        // 2) 게임 중 무르기 투표
        if (this.state.phase === "UNDO_VOTING") {
            const requester = this.state.undo.requester;

            // 요청자가 끊김 -> 요청 취소
            if (requester === session.playerId) {
                clearTimeout(this.undoTimer);

                this.isUndoVoting = false;
                this.isGamePaused = false;
                this.state.phase = "PLAYING";
                this.state.undo.isVoting = false;
                this.state.undo.requester = null;
                this.state.undo.startTime = null;
                this.undoVotes.clear();

                this.broadcast({ type: "UNDO_CANCEL" });
                this.startTurnTimer(this.turn);
                return true;
            }

            // 응답자가 끊김 -> 자동 반대
            this.undoVotes.set(session.playerId, false);

            const votes = [...this.undoVotes.values()];
            if (votes.every(v => v !== null)) {
                clearTimeout(this.undoTimer);

                this.isUndoVoting = false;
                this.isGamePaused = false;
                this.state.phase = "PLAYING";
                this.state.undo.isVoting = false;
                this.state.undo.requester = null;
                this.state.undo.startTime = null;

                this.broadcast({
                    type: "UNDO_RESULT",
                    enabled: false
                });

                this.startTurnTimer(this.turn);
            }

            return true;
        }

        return false;
    }

    // 백그라운드 처리
    // 🔥 ws ❌ → session 사용
    handleBackground(session) {
        if (!this.isStarted || this.isGameOver) return;

        // 투표 예외처리
        if (this.handleDisconnectDuringVote(session, "BACKGROUND")) return;

        session.isBackground = true;
        this.markPlayerAway(session, "BACKGROUND");

        // 내 턴이면 즉시 x, 5초 후 진행 방해로 간주
        if (this.shouldCountAsStallNow(session)) {
            this.startStallCheck(session, "BACKGROUND");
        }
    }

    handleForeground(session) {
        // 🔥 혹시라도 타이머 돌고 있으면 무조건 끔
        this.cancelStallCheck(session);

        if (!session.isTemporarilyAway) return;
        this.resumeFromAway(session);
    }

    forceLose(player, reason) {
        const opponent = this.players.find(p => p !== player);

        if (!opponent) return;

        console.log(`💀 ${player.uid} 패배 (${reason})`);

        // 데이터 저장
        const UserService = require('../services/UserService');

        const loser = player;
        const winner = this.players.find(p => p !== player);

        if (winner) {
            // 중복 END / reconnect / disconnect 상황 방어
            if (this.currentMatch?.endedAt != null) return;

            UserService.applyMatchResult(winner, loser);
        }

        // 상태 변화
        this.isGameOver = true;
        this.state.phase = "GAME_OVER";
        this.state.game.isOver = true;
        this.state.game.winner = opponent.playerId;

        const endMatchId = this.lastMatchId ?? this.currentMatch?.matchId ?? null;

        this.broadcast({
            type: "END",
            winner: opponent.playerId,
            reason: reason,
            winLine: [],
            matchId: endMatchId
        });

        if (this.currentMatch) {
            this.currentMatch.winner = opponent.playerId;
            this.currentMatch.endedAt = Date.now();

            // 대국 저장
            this.finalizeGame(opponent, player, [], reason);
        }
    }

    handleMove(session, x, y) {
        console.log(`🎯 MOVE 요청: P${session.playerId} (${x}, ${y})`);
        
        // 🔥 게임 끝났으면 무시
        if (this.isGameOver) {
            console.log("❌ 이미 게임 종료됨");
            return;
        }

        // 🔥 맨 위에 넣어라
        if (this.state.phase !== "PLAYING") {
            console.log("⚠️ 비정상 MOVE 차단:", this.state.phase);
            return;
        }

        // 무르기 중 입력 무시
        if (this.isGamePaused) {
            console.log("❌ Undo 중에는 플레이 불가");
            return;
        }

        // 🔥 턴 체크
        if (session.playerId !== this.turn) {
            console.log("❌ 턴 아님");
            this.sendInvalid(session, "turn");
            return;
        }

        // 🔥 범위 체크
        if (x < 0 || x >= 19 || y < 0 || y >= 19) {
            console.log("❌ 범위 벗어남");
            this.sendInvalid(session, "range");
            return;
        }

        // 🔥 중복 체크
        if (this.board[x][y] !== 0) {
            console.log("❌ 이미 돌 있음");
            this.sendInvalid(session, "occupied");
            return;
        }

        // 🔥 렌주 검사 (🔥 여기 핵심 위치)
        const result = this.rule.isValidMove(this.board, x, y, session.playerId);

        if (!result.valid) {
            console.log("❌ 금수:", result.reason);
            this.sendInvalid(session, result.reason);
            return;
        }

        // 🔥 적용
        this.board[x][y] = session.playerId;

        this.moveHistory.push({
            x: x,
            y: y,
            player: session.playerId
        });

        if (this.currentMatch) {
            this.currentMatch.moves.push({
                x: x,
                y: y,
                player: session.playerId
            });
        }

        // 🔥 정상 착수 성공 → 해당 플레이어 missCount 초기화
        if ((this.missCount.get(session.playerId) || 0) > 0) {
            this.missCount.set(session.playerId, 0);

            this.broadcast({
                type: PacketType.MISS_COUNT,
                playerId: session.playerId,
                missCount: 0
            });
        }

        // 🔥 먼저 MOVE 브로드캐스트 (클라 렌더용)
        this.broadcast({
            type: PacketType.MOVE,
            x,
            y,
            player: session.playerId
        });

        // 🔥 승리 체크
        if (this.rule.checkWin(this.board, x, y, session.playerId)) {
            console.log(`🏆 P${session.playerId} 승리`);

            const winnerSession = session;
            const loserSession = this.players.find(p => p !== session);

            const winLine = this.rule.getWinLine(this.board, x, y, session.playerId)
                .map(p => ({
                    x: p[0],
                    y: p[1]
                }));

            // 🔥 핵심: 여기 한 줄로 끝
            this.finalizeGame(winnerSession, loserSession, winLine);

            return;
        }

        // 🔥 턴 변경
        this.turn = this.turn === 1 ? 2 : 1;
        this.state.turn = this.turn;
        this.state.turnStartTime = Date.now();

        const nextPlayer = this.players.find(p => p.playerId === this.turn);

        /*
            상대 턴에 백그라운드로 갔다가
            상대가 수를 둬서 내 턴이 되었는데
            아직도 안 돌아와 있으면
            그때 1회로 친다
        */

        // 다음 턴 플레이어가 아직 away 상태면
        if (nextPlayer && nextPlayer.isTemporarilyAway) {
            if (this.shouldCountAsStallNow(nextPlayer)) {

                // 🔥 기존 즉시 제재 제거
                // this.applyStallCount(nextPlayer, nextPlayer.awayReason || "DISCONNECT");

                // 🔥 5초 유예 시작
                this.startStallCheck(nextPlayer, nextPlayer.awayReason || "TURN_STALL");

                //return; // 기존 그대로 유지
            }
        }

        // 🔥 턴 브로드캐스트
        this.broadcast({
            type: PacketType.TURN,
            turn: this.turn,
            turnStartTime: this.state.turnStartTime
        });

        // 🔥 턴 시작 시 background 상태면 5초 체크
        if (nextPlayer && (nextPlayer.isBackground || !nextPlayer.isConnected)) {
            this.startStallCheck(nextPlayer, "TURN_STALL");
        }

        // 🔥 타이머 시작(상대방에게 타이머 넘기기)
        this.startTurnTimer(this.turn);
    }

    finalizeGame(winnerSession, loserSession, winLine = [], reason = null) {
        // 🔥 중복 방지 (핵심)
        if (this.currentMatch?.endedAt != null) return;

        console.log("🏁 finalizeGame 호출");

        // 🔥 승패 반영
        if (winnerSession && loserSession) {
            UserService.applyMatchResult(winnerSession, loserSession);
        }

        // 🔥 상태 변경
        this.isGameOver = true;
        this.state.phase = "GAME_OVER";
        this.state.game.isOver = true;
        this.state.game.winner = winnerSession.playerId;

        const endMatchId = this.lastMatchId ?? this.currentMatch?.matchId ?? null;

        // 🔥 결과 브로드캐스트
        this.broadcast({
            type: "END",
            winner: winnerSession.playerId,
            reason: reason,
            winLine: winLine,
            matchId: endMatchId

        });

        // 🔥 Match 저장
        if (this.currentMatch) {
            this.currentMatch.winner = winnerSession.playerId;
            this.currentMatch.winLine = winLine;
            this.currentMatch.endedAt = Date.now();

            // 대국 저장
            MatchService.saveMatch(this.currentMatch);
            this.lastMatchId = this.currentMatch.matchId;
        }

        // 🔥 최신 유저 데이터 다시 로드
        const updatedWinner = UserService.loadUser(winnerSession.uid);
        const updatedLoser = UserService.loadUser(loserSession.uid);

        // 🔥 클라 갱신
        winnerSession.send({
            type: "MY_PROFILE",
            ...updatedWinner
        });

        loserSession.send({
            type: "MY_PROFILE",
            ...updatedLoser
        });
    }

    sendRoomInfo() {
        const data = {
            type: "ROOM_INFO",
            roomId: this.roomId,
            playerCount: this.players.length,
            maxPlayers: this.maxPlayers
        };

        // 🔥 이 방에 있는 사람들에게만
        this.broadcast(data);
    }

    handleRestartRequest(player) {

        // 이미 요청 중이면 무시
        if (this.restartRequester !== null) return;

        if (this.state.phase !== "PLAYING") {
            console.log("⚠️ 비정상 RESTART 차단:", this.state.phase);
            return;
        }

        this.state.phase = "RESTART_PENDING";
        this.state.restart.isPending = true;
        this.state.restart.requester = player.playerId;

        console.log(`🔄 P${player.playerId} 재시작 요청`);

        // 상대에게 요청 전달
        this.players.forEach(p => {
            if (p !== player) {
                p.send({
                    type: "RESTART_REQUEST"
                });
            }
        });
    }

    handleRestartAccept(player) {

        if (this.restartRequester === null) return;

        console.log(`✅ P${player.playerId} 요청 수락`);

        this.broadcast({
            type: "RESTART_ACCEPT"
        });

        this.restartRequester = null;

        this.state.phase = "WAITING";
        this.state.restart.isPending = false;
        this.state.restart.requester = null;

        // 🔥 게임 리셋 후 다시 시작
        this.resetGame();
        this.startCountdown();
    }

    handleRestartReject(player) {

        if (this.restartRequester === null) return;

        console.log(`❌ P${player.playerId} 요청 거절`);

        this.restartRequester.send({
            type: "RESTART_REJECT"
        });

        this.restartRequester = null;
    }

    handleRestartCancel(player) {

        if (this.restartRequester !== player) return;

        console.log(`🚫 P${player.playerId} 요청 취소`);

        this.broadcast({
            type: "RESTART_CANCEL"
        });

        this.restartRequester = null;
    }

    applyUndo() {

        if (!this.moveHistory || this.moveHistory.length === 0) {
            console.log("❌ moveHistory 없음");
            return;
        }

        // 🔥 1수만 제거
        const last = this.moveHistory.pop();

        this.board[last.x][last.y] = 0;

        // 🔥 턴 복구 (마지막 둔 사람이 다시 둔다)
        this.turn = last.player;
        this.state.turn = this.turn;
        this.state.turnStartTime = Date.now();

        this.broadcast({
            type: "UNDO_APPLY",
            moves: last,   // 🔥 제거된 것만 보냄
            nextTurn: this.turn,
            turnTimeLimit: this.turnTimeLimit
        });

        console.log("현재 히스토리:", this.moveHistory);
    }

    handleUndoCancel(player) {

        // 🔥 투표 중 아니면 무시
        if (!this.isUndoVoting) return;

        // 🔥 요청자만 취소 가능
        if (this.undoRequester !== player.playerId) return;

        clearTimeout(this.undoTimer);

        console.log(`❌ P${player.playerId} 무르기 요청 취소`);

        this.isUndoVoting = false;
        this.isGamePaused = false;

        this.state.phase = "PLAYING";
        this.state.undo.isVoting = false;
        this.state.undo.requester = null;
        this.state.undo.startTime = null;
        this.undoVotes.clear();
        this.undoRequester = null;

        // 🔥 모든 클라에게 취소 알림
        this.broadcast({
            type: "UNDO_CANCEL"
        });

         // 🔥 게임 재개
        this.startTurnTimer(this.turn);
    }
}

module.exports = GameRoom;
class RenjuRule {
    constructor(size) {
        this.size = size;
        this.EMPTY = 0;
        this.BLACK = 1;
        this.WHITE = 2;
    }

    isValidMove(board, x, y, player) {
        // 🔥 백은 금수 없음
        if (player === this.WHITE) return { valid: true };

        // 🔥 가상 착수
        board[x][y] = player;

        // 장목
        if (this.isOverline(board, x, y, player)) {
            board[x][y] = this.EMPTY;
            return { valid: false, reason: "overline" };
        }

        // 4-4
        if (this.countOpenFours(board, x, y, player) >= 2) {
            board[x][y] = this.EMPTY;
            return { valid: false, reason: "double_four" };
        }

        // 3-3
        if (this.countOpenThrees(board, x, y, player) >= 2) {
            board[x][y] = this.EMPTY;
            return { valid: false, reason: "double_three" };
        }

        board[x][y] = this.EMPTY;
        return { valid: true };
    }

    checkWin(board, x, y, player) {
        const count = this.getMaxLine(board, x, y, player);

        if (player === this.WHITE) return count >= 5;
        return count === 5;
    }

    getMaxLine(board, x, y, player) {
        return Math.max(
            this.countLine(board, x, y, player, 1, 0),
            this.countLine(board, x, y, player, 0, 1),
            this.countLine(board, x, y, player, 1, 1),
            this.countLine(board, x, y, player, 1, -1)
        );
    }

    countLine(board, x, y, player, dx, dy) {
        return (
            1 +
            this.count(board, x, y, player, dx, dy) +
            this.count(board, x, y, player, -dx, -dy)
        );
    }

    count(board, x, y, player, dx, dy) {
        let cnt = 0;
        let nx = x + dx;
        let ny = y + dy;

        while (
            nx >= 0 && nx < this.size &&
            ny >= 0 && ny < this.size &&
            board[nx][ny] === player
        ) {
            cnt++;
            nx += dx;
            ny += dy;
        }

        return cnt;
    }

    isOverline(board, x, y, player) {
        return (
            this.countLine(board, x, y, player, 1, 0) > 5 ||
            this.countLine(board, x, y, player, 0, 1) > 5 ||
            this.countLine(board, x, y, player, 1, 1) > 5 ||
            this.countLine(board, x, y, player, 1, -1) > 5
        );
    }

    countOpenFours(board, x, y, player) {
        let count = 0;
        const dirs = [[1,0],[0,1],[1,1],[1,-1]];

        for (const [dx, dy] of dirs) {
            const line = this.getLine(board, x, y, player, dx, dy, 5);

            if (
                line.includes("011110") ||
                line.includes("0110110") ||
                line.includes("0101110") ||
                line.includes("0111010")
            ) {
                count++;
            }
        }

        return count;
    }

    countOpenThrees(board, x, y, player) {
        let count = 0;
        const dirs = [[1,0],[0,1],[1,1],[1,-1]];

        const patterns = [
            "0011100",
            "0011010",
            "0010110",
            "0101100",
            "0110100"
        ];

        for (const [dx, dy] of dirs) {
            const line = this.getLine(board, x, y, player, dx, dy, 4);

            if (patterns.some(p => line.includes(p)) && !line.includes("011110")) {
                count++;
            }
        }

        return count;
    }

    getLine(board, x, y, player, dx, dy, radius) {
        let result = "";

        for (let i = -radius; i <= radius; i++) {
            const nx = x + dx * i;
            const ny = y + dy * i;

            if (nx < 0 || ny < 0 || nx >= this.size || ny >= this.size) {
                result += "X";
                continue;
            }

            const cell = board[nx][ny];

            if (cell === 0) result += "0";
            else if (cell === player) result += "1";
            else result += "X";
        }

        return result;
    }

    getWinLine(board, x, y, player) {
        const dirs = [
            [1, 0],
            [0, 1],
            [1, 1],
            [1, -1]
        ];

        for (const [dx, dy] of dirs) {
            let line = [[x, y]];

            line = line.concat(this.collect(board, x, y, player, dx, dy));
            line = line.concat(this.collect(board, x, y, player, -dx, -dy));

            if (line.length >= 5) {
                return this.getExactFive(line, dx, dy);
            }
        }

        return [];
    }

    collect(board, x, y, player, dx, dy) {
        let result = [];
        let nx = x + dx;
        let ny = y + dy;

        while (
            nx >= 0 && nx < this.size &&
            ny >= 0 && ny < this.size &&
            board[nx][ny] === player
        ) {
            result.push([nx, ny]);
            nx += dx;
            ny += dy;
        }

        return result;
    }

    getExactFive(line, dx, dy) {
        line.sort((a, b) => {
            if (dx !== 0) return a[0] - b[0];
            return a[1] - b[1];
        });

        return line.slice(0, 5);
    }
}

module.exports = RenjuRule;
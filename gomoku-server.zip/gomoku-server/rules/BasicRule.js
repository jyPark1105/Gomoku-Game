class BasicRule {
    constructor(size) {
        this.size = size;
    }

    checkWin(board, x, y, player) {
        return (
            this.checkDirection(board, x, y, player, 1, 0) ||
            this.checkDirection(board, x, y, player, 0, 1) ||
            this.checkDirection(board, x, y, player, 1, 1) ||
            this.checkDirection(board, x, y, player, 1, -1)
        );
    }

    checkDirection(board, x, y, player, dx, dy) {
        let count = 1;

        count += this.count(board, x, y, player, dx, dy);
        count += this.count(board, x, y, player, -dx, -dy);

        return count >= 5;
    }

    count(board, x, y, player, dx, dy) {
        let count = 0;
        let nx = x + dx;
        let ny = y + dy;

        while (
            nx >= 0 && nx < this.size &&
            ny >= 0 && ny < this.size &&
            board[nx][ny] === player
        ) {
            count++;
            nx += dx;
            ny += dy;
        }

        return count;
    }
}

module.exports = BasicRule;
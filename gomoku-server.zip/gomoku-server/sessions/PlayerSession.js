const UserService = require('../services/UserService');

class PlayerSession {
    constructor(ws) {
        this.ws = ws;

        this.playerId = null;

        // 🔥 기본값 세팅
        this.uid = null;
        this.nickname = null;
        this.avatarIndex = null;
        this.win = 0;
        this.lose = 0;
        this.tier = 10;

        this.isConnected = true;
        this.isBackground = false;

        this.disconnectCount = 0;
        this.backgroundCount = 0;

        this.timeoutTimer = null;

        // 🔥 추가
        this.isTemporarilyAway = false;      // 백그라운드/네트워크 끊김 상태
        this.awayReason = null;              // "BACKGROUND" | "NETWORK"
        this.awayStartedAt = 0;

        this.stallCount = 0;                 // 실제 턴 방해 카운트
        this.pendingStallTurn = null;        // 상대 턴에 나갔다가 내 턴이 되면 카운트할 용도
        this.isAwaitingReturn = false;       // 현재 30초 복귀 대기중인지
        this.pausedRemainingTurnTime = null; // 일시정지 직전 남은 시간
        this.hasDisconnectPenaltyOnCurrentAway = false; // 이번 이탈에서 이미 카운트 반영했는지

        this.warnCount = 0;
        this.blockUntil = 0;
        this.permaBlocked = false;
        this.chatHistory = [];
    }

    initFromUser(user) {
        if (!user) return;

        this.nickname = user.nickname;
        this.avatarIndex = user.avatarIndex;
        this.win = user.win;
        this.lose = user.lose;
        this.tier = user.tier;
    }

    send(data) {
        if (!this.ws) return;

        const WebSocket = require('ws');

        if (this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(data));
        }
    }

    attachSocket(ws) {
        this.ws = ws;
        this.isConnected = true;
    }
}

module.exports = PlayerSession;
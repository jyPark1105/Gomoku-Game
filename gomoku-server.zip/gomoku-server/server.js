const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 3000 });

const RoomManager = require('./managers/RoomManager');
const roomManager = new RoomManager(wss);
const MatchService = require('./services/MatchService');
const PlayerSession = require('./sessions/PlayerSession');
const UserService = require('./services/UserService');
const NicknameCacheService = require('./services/NicknameCacheService');
const BadWordService = require('./services/BadWordService');

// 방 필요 없음
const noRoomRequired = [
    "CHECK_NICKNAME",
    "CANCEL_NICKNAME_RESERVE",
    "REQUEST_NICKNAME_SUGGEST",
    "SET_PROFILE",
    "GET_RANKING",
    "JOIN_ROOM",
    "REQUEST_ROOM_LIST",
    "GET_MATCH",
    "GET_MATCH_LIST"
];

console.log("✅ Server started on port 3000");

// 🔥 욕설 필터 초기화
BadWordService.init();

function safeRoomCall(session, fn) {
    if (!session || !session.room) return;
    fn(session.room);
}

// -----------------------------
// 🔥 임시 프로필 생성 유틸
// -----------------------------
function generateUID() {
    return "U_" + Math.random().toString(36).slice(2, 10);
}

function generateNickname() {
    const baseList = [
        "초보", "연습", "고수", "도전자",
        "오목왕", "돌쟁이", "바둑신", "플레이어",
        "한수", "승부사", "집중모드"
    ];

    const suffixList = [
        "탈출", "중", "계정", "연습용",
        "도전중", "유저", "고고", "시작"
    ];

    const base = baseList[Math.floor(Math.random() * baseList.length)];
    const suffix = suffixList[Math.floor(Math.random() * suffixList.length)];

    const number = Math.floor(Math.random() * 9999);

    const patterns = [
        `${base}${suffix}${number}`,
        `${base}${number}`,
        `${suffix}${number}`,
        `${base}${suffix}`,
        `${base}${number}${randomChar()}`,
        `${base}${randomChar()}${number}`
    ];

    return patterns[Math.floor(Math.random() * patterns.length)];
}

function validateNickname(name) {

    let weight = 0;
    let hangulCount = 0;
    let englishCount = 0;

    for (let c of name) {

        // 공백
        if (c === ' ') {
            weight += 1;
            continue;
        }

        // 완성형 한글
        if (/[가-힣]/.test(c)) {
            weight += 2;
            hangulCount++;
            continue;
        }

        // 영어
        if (/[a-zA-Z]/.test(c)) {
            weight += (/[A-Z]/.test(c)) ? 2 : 1;
            englishCount++;
            continue;
        }

        // 자음/모음 or 특수문자
        return false;
    }

    // 길이 제한
    if (weight > 12) return false;

    // 한글 only
    if (hangulCount > 0 && englishCount === 0) {
        if (hangulCount < 2) return false;
    }

    // 영어 only
    if (englishCount > 0 && hangulCount === 0) {
        if (englishCount < 3) return false;
    }

    // 혼합
    if (hangulCount > 0 && englishCount > 0) {
        if (weight < 4) return false;
    }

    return true;
}

async function generateValidNickname(uid) {
    for (let i = 0; i < 20; i++) {

        const nickname = generateNickname();

        // 🔥 1. 유효성 검사
        const isValid = validateNickname(nickname);
        if (!isValid) continue;

        // 🔥 2. 중복 검사
        const duplicate = await NicknameCacheService.isDuplicate(nickname);
        if (duplicate) continue;

        // 🔥 성공
        return nickname;
    }

    return null; // 실패
}

function randomChar() {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    return chars[Math.floor(Math.random() * chars.length)];
}

function getNameWeight(name) {
    let weight = 0;

    for (let c of name) {
        if (c === ' ') weight += 1;
        else if (/[가-힣]/.test(c)) weight += 2;
        else if (/[A-Z]/.test(c)) weight += 2;
        else weight += 1;
    }

    return weight;
}

// Redis 초기화 코드
const path = require('path');
(async () => {
    try {
        await NicknameCacheService.connectAndWarmup(
            path.resolve(__dirname, './users')
        );

        console.log("🔥 Redis warmup 완료");
    } catch (err) {
        console.error("❌ Redis init 실패:", err);
    }
})();

async function handleCheckNickname(session, data) {
    const nickname = data.nickname;

    if (!nickname) {
        session.send({ type: "NICKNAME_INVALID" });
        return;
    }

    // 🔥 기존 예약 해제
    if (session.pendingNickname) {
        await NicknameCacheService.cancelReservation(session.pendingNickname);
        console.log("🧹 이전 예약 해제:", session.pendingNickname);
        session.pendingNickname = null;
    }

    const duplicate = await NicknameCacheService.isDuplicate(nickname);

    if (duplicate) {
        session.send({ type: "NICKNAME_DUPLICATE" });
        return;
    }

    const reserved = await NicknameCacheService.reserve(nickname, session.uid);

    if (!reserved) {
        session.send({ type: "NICKNAME_DUPLICATE" });
        return;
    }

    session.pendingNickname = nickname;

    session.send({
        type: "NICKNAME_AVAILABLE"
    });
}

async function handleCancelNickname(session, data) {
    const nickname = data.nickname;

    await NicknameCacheService.cancelReservation(nickname);

    console.log(`🧹 예약 취소: ${nickname}`);

    if (session.pendingNickname === nickname) {
        session.pendingNickname = null;
    }
}

async function handleNicknameSuggest(session) {
    console.log("🔥 닉네임 추천 요청 들어옴");

    // 🔥 기존 예약 해제
    if (session.pendingNickname) {
        await NicknameCacheService.cancelReservation(session.pendingNickname);
        console.log("🧹 이전 예약 해제:", session.pendingNickname);
        session.pendingNickname = null;
    }

    const nickname = await generateValidNickname(session.uid);


    if (!nickname) {
        session.send({
            type: "NICKNAME_INVALID",
            message: "추천 닉네임 생성 실패"
        });
        return;
    }

    // 🔥 닉네임 예약
    const reserved = await NicknameCacheService.reserve(nickname, session.uid);

    if (!reserved) {
        // 이론상 거의 없음 (generate에서 걸러서)
        session.send({
            type: "NICKNAME_DUPLICATE"
        });
        return;
    }

    session.pendingNickname = nickname;

    session.send({
        type: "NICKNAME_SUGGEST",
        name: nickname
    });

    console.log("📤 추천 닉네임:", nickname);
}

async function handleSetProfile(session, data) {
    const nickname = data.nickname;
    const avatarIndex = data.avatarIndex;

    const reserved = await NicknameCacheService.isReservedByMe(
        nickname,
        session.uid
    );

    if (!reserved) {
        session.send({ type: "NICKNAME_DUPLICATE" });
        return;
    }

    session.nickname = nickname;
    session.avatarIndex = avatarIndex;
    session.profileReady = true;

    const user = UserService.updateProfile(
        session.uid,
        nickname,
        avatarIndex
    );

    await NicknameCacheService.confirm(nickname);

    session.send({
        type: "MY_PROFILE",
        ...user
    });
}

function handleJoinRoom(session, data)
{
    if (!session.profileReady)
    {
        session.send({
            type: "ERROR",
            message: "PROFILE_REQUIRED"
        });
        return;
    }

    handleJoinRoomWithReconnect(session, data);
}

// --------------------------------------------------
// 🔥 재접속 처리
// 핵심 : 재접속 성공 = 서버 타이머를 리셋하지 않는다, 클라에게 현재 남은 시간만 정확히 알려준다
// startTurnTimer 재호출 절대 금지
// --------------------------------------------------
function handleJoinRoomWithReconnect(session, data) {

    // 🔥 방 찾기
    const room = roomManager.getRoom(data.roomId);

    // 🔥 방 없으면 그냥 입장
    if (!room) {
        roomManager.joinRoom(data.roomId, session, data.turnTime);
        return;
    }

    // 🔥 같은 UID 찾기 (session 기준)
    const existing = room.players.find(p => p.uid === session.uid);

    if (existing) {
        console.log("🔁 재접속 감지:", session.uid);

        // 하나의 session은 하나의 ws만 가짐
        // 🔥 이미 연결된 세션이면 무시
        if (existing.ws && existing.ws.readyState === 1) {
            console.log("⚠️ 이미 연결된 세션 - 중복 reconnect 무시");
            return;
        }

        // 🔥 여기다 넣는다 (attachSocket 전에!)
        if (room.state.phase === "GAME_OVER") {
            const endMatchId = room.lastMatchId ?? room.currentMatch?.matchId ?? null;

            session.send({
                type: "END",
                winner: room.state.game.winner,
                reason: "RECONNECT_AFTER_END",
                matchId: endMatchId
            });
            return;
        }

        // 🔥 기존 소켓 제거 후 교체
        existing.attachSocket(session.ws); // 플레이어(session)의 네트워크(ws) 연결
        session.ws.session = existing;

        // 🔥 reconnect는 네트워크 문제 → 카운트 초기화
        existing.backgroundCount = 0;
        existing.disconnectCount = 0;
        existing.isBackground = false;
        existing.isConnected = true;

        // 🔥 새로운 session에도 room 정보 연결
        session.room = room;
        session.playerId = existing.playerId;

        // 🔥 disconnect 타이머 취소
        room.clearDisconnectTimeout(existing);

        // 🔥 클라 상태 복구
        existing.send({
            type: "JOINED",
            playerId: existing.playerId,
            roomId: room.roomId
        });

        existing.send({
            type: "RECONNECT_SUCCESS",

            // 기본 정보
            turn: room.state.turn,
            turnTimeLimit: room.state.turnTimeLimit,
            turnStartTime: room.state.turnStartTime,

            moves: room.moveHistory,

            players: room.players.map(p => ({
                playerId: p.playerId,
                uid: p.uid,
                nickname: p.nickname,
                avatarIndex: p.avatarIndex
            })),

            // 🔥 핵심: 상태 통째로 전달
            gameState: room.state
        });

        // 🔥 상대에게 재접속 알림
        room.broadcast({
            type: "PLAYER_RECONNECTED",
            playerId: existing.playerId
        });

        
        // 🔥 상대에게도 TURN 강제 동기화
        room.broadcast({
            type: "TURN",
            turn: room.state.turn,
            turnStartTime: room.state.turnStartTime
        });

        return;
    }

    // 🔥 기존 유저 아니면 일반 입장
    roomManager.joinRoom(data.roomId, session, data.turnTime);
}

// --------------------------------------------------
// 🔥 클라이언트 접속
// --------------------------------------------------
wss.on('connection', (ws) => {

    const session = new PlayerSession(ws);

    console.log("🔌 Player connected");

    session.selectedTurnTime = 60;

    // 🔥 uid 먼저 생성
    session.uid = generateUID();

    console.log(`👤 uid=${session.uid}`);

    // 🔥 유저 로드
    const user = UserService.loadUser(session.uid);
    session.initFromUser(user);

    // 🔥 user → session 연결
    if (user) {
        session.nickname = user.nickname ?? null;
        session.avatarIndex = user.avatarIndex ?? null;
        session.win = user.win ?? 0;
        session.lose = user.lose ?? 0;
        session.tier = user.tier ?? 10;
    }

    // 🔥 연결
    ws.session = session;

    roomManager.broadcastRoomListByTime(session.selectedTurnTime);

    // --------------------------------------------------
    // 🔥 메시지 수신
    // --------------------------------------------------
    ws.on('message', (message) => {

        // 서버 디버깅 로그
        // console.log("📩 RAW:", message.toString());

        // 🔥 항상 session 기준으로 처리
        const session = ws.session;

        const data = JSON.parse(message.toString());

        // 🔥 새 패킷 추가 시 중요: 방 없는 상태에서 못 하는 요청 필터
        if (!session.room && !noRoomRequired.includes(data.type)) {
            // 🔥 예외 처리
            if (data.type === "APP_BACKGROUND" || data.type === "APP_FOREGROUND") {
                // 그냥 통과
            } else {
                console.log(`🚫 필터됨: ${data.type}`);
                return;
            }
        }

        switch (data.type) {
            case "GET_RANKING":
                console.log("GET_RANKING 패킷 전달됨");
                MatchService.handleGetRanking(session);
                break;

            case "CHECK_NICKNAME":
                handleCheckNickname(session, data);
                break;

            case "CANCEL_NICKNAME_RESERVE":
                handleCancelNickname(session, data);
                break;

            case "REQUEST_NICKNAME_SUGGEST":
                handleNicknameSuggest(session);
                break;

            case "SET_PROFILE":
                handleSetProfile(session, data);
                break;

            case "JOIN_ROOM":
                handleJoinRoom(session, data);
                break;

            case "REQUEST_ROOM_LIST":
                // 🔥 ws는 네트워크 필터링용으로만 사용
                session.selectedTurnTime = data.turnTime;
                roomManager.sendRoomList(session, data.turnTime);
                break;

            // 🔥 여기부터 전부 session 기반
            case "READY":
                session.room.setReady(session, true);
                break;

            case "READY_CANCEL":
                session.room.setReady(session, false);
                break;
            
            case "UNDO_OPTION_VOTE":
                session.room.handleUndoOption(session, data.agree);
                break;

            case "UNDO_VOTE":
                session.room.handleUndoVote(session, data.agree);
                break;

            case "UNDO_REQUEST":
                session.room.handleUndoRequest(session);
                break;

            case "UNDO_CANCEL":
                session.room.handleUndoCancel(session);
                break;
            
            case "CHAT":
                session.room.handleChat(session, data.message);
                break;

            case "TYPING_START":
                session.room?.handleTyping(session, true);
                break;

            case "TYPING_STOP":
                session.room?.handleTyping(session, false);
                break;

            case "APP_BACKGROUND":
                safeRoomCall(session, (room) => room.handleBackground(session));
                break;

            case "APP_FOREGROUND":
                safeRoomCall(session, (room) => room.handleForeground(session));
                break;
            
            case "PICK_COLOR":
                session.room.handlePickColor(session, data.slotIndex);
                break;

            case "MOVE":
                session.room.handleMove(session, data.x, data.y);
                break;

            case "REPLAY":
                session.room.setReplay(session);
                break;

            case "RESTART_REQUEST":
                session.room.handleRestartRequest(session);
                break;

            case "RESTART_ACCEPT":
                session.room.handleRestartAccept(session);
                break;

            case "RESTART_REJECT":
                session.room.handleRestartReject(session);
                break;

            case "RESTART_CANCEL":
                session.room.handleRestartCancel(session);
                break;

            case "GET_MATCH":
                // 🔥 MatchService는 ws 필요 (네트워크 전송)
                MatchService.handleGetMatch(session, data);
                break;

            case "GET_MATCH_LIST":
                MatchService.handleGetMatchList(session);
                break;

            case "LEAVE":
                session.room?.removePlayer(session);
                break;
        }
    });

    // --------------------------------------------------
    // 🔥 연결 종료
    // --------------------------------------------------
    ws.on('close', async () => {
        const session = ws.session;

        // 🔥 닉네임 예약 중이었으면 해제
        if (session?.pendingNickname) {
            await NicknameCacheService.cancelReservation(session.pendingNickname);
            console.log("🧹 disconnect 예약 해제:", session.pendingNickname);
            session.pendingNickname = null;
        }

        const room = session.room;
        if (!room) return;

        // 투표 예외처리
        if (room.handleDisconnectDuringVote &&
            room.handleDisconnectDuringVote(session, "NETWORK"))
            return;

        session.isConnected = false;
        room.markPlayerAway(session, "NETWORK");

        if (room.shouldCountAsStallNow(session)) {
            room.startStallCheck(session, "NETWORK");
        }
    });
});
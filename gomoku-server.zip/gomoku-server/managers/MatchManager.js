const GameRoom = require('../rooms/GameRoom');

class MatchManager {
    constructor() {
        this.waitingPlayer = null;
    }

    addPlayer(session) {

        if (this.waitingPlayer === null) {
            this.waitingPlayer = session;

            session.send({
                type: "WAIT"
            });

        } else {
            new GameRoom(this.waitingPlayer, session);
            this.waitingPlayer = null;
        }
    }
}

module.exports = MatchManager;
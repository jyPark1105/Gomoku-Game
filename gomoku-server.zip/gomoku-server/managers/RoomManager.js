const GameRoom = require('../rooms/GameRoom');

class RoomManager {
    constructor(wss) {
        this.wss = wss;

        // 🔥 턴 시간별 방
        this.rooms = {
            30: new Map(),
            60: new Map(),
            90: new Map(),
            120: new Map()
        };

        // 🔥 초기 방 생성 (각 시간별 2개)
        [30, 60, 90, 120].forEach(time => {
            this.createRoom(time, 1);
            this.createRoom(time, 2);
        });
    }

    // 🔥 수정됨
    createRoom(turnTime, roomId) {
        this.rooms[turnTime].set(
            roomId,
            new GameRoom(roomId, this, turnTime)
        );

        console.log(`🧩 ${turnTime}초 Room ${roomId} 생성`);
    }

    // 🔥 roomId로 방 찾기
    getRoom(roomId) {
        for (const turnTime of Object.keys(this.rooms)) {
            const room = this.rooms[turnTime].get(roomId);
            if (room) {
                return room;
            }
        }

        return null;
    }

    // 🔥 입장
    joinRoom(roomId, session, turnTime) {

        const timeRooms = this.rooms[turnTime];

        // 게임 메시지
        if (!timeRooms) {
            session.send({
                type: "ERROR",
                message: "Invalid time"
            });
            return;
        }

        const room = timeRooms.get(roomId);

        if (!room) {
            session.send({
                type: "ERROR",
                message: "Room not found"
            });
            return;
        }

        // 🔥 클라이언트에 시간 저장 (핵심)
        session.selectedTurnTime = turnTime;

        room.addPlayer(session);

        // 🔥 해당 시간대만 업데이트
        this.broadcastRoomListByTime(turnTime);
    }

    // 🔥 클라가 요청할 때
    sendRoomList(session, turnTime) {

        console.log("🔥 REQUEST_ROOM_LIST 요청");

        const rooms = this.rooms[turnTime];
        if (!rooms) return;

        const list = [];

        rooms.forEach((room, roomId) => {
            list.push({
                roomId: roomId,
                playerCount: room.players.length,
                maxPlayers: room.maxPlayers
            });
        });

        session.send({
            type: "ROOM_LIST",
            turnTime: turnTime,
            rooms: list
        });

        console.log("🔥 REQUEST_ROOM_LIST 요청 응답 성공!");
    }

    // 🔥 해당 시간대만 전체 갱신
    broadcastRoomListByTime(turnTime) {

        const rooms = this.rooms[turnTime];
        if (!rooms) return;

        const list = [];

        rooms.forEach((room, roomId) => {
            list.push({
                roomId: roomId,
                playerCount: room.players.length,
                maxPlayers: room.maxPlayers
            });
        });

        const data = {
            type: "ROOM_LIST",
            turnTime: turnTime,
            rooms: list
        };

        this.wss.clients.forEach(client => {

            const session = client.session; // 🔥 연결된 session 가져오기

            if (client.readyState === 1 &&
                session?.selectedTurnTime === turnTime) {
                    
                // 🔥 session.send로 통일
                session.send(data);
            }
        });
    }
}

module.exports = RoomManager;
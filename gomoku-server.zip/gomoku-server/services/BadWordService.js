const fs = require('fs');
const path = require('path');

class BadWordService {
    constructor() {
        this.words = new Set();
        this.patterns = [];
    }

    init() {
        const filePath = path.resolve(__dirname, '../data/badwords.txt');

        if (!fs.existsSync(filePath)) {
            console.error("❌ badwords.txt 없음");
            return;
        }

        const data = fs.readFileSync(filePath, 'utf8');

        data.split('\n')
            .map(v => v.trim())
            .filter(v => v.length > 0)
            .forEach(word => {
                this.words.add(this.normalize(word));
            });

        // 🔥 패턴 추가 (핵심)
        this.patterns = [
            /ㅅ.*ㅂ/,
            /시.*발/,
            /tlqkf/,
            /fuck/,
            /shit/
        ];

        console.log(`🔥 욕설 필터 로드 완료: ${this.words.size}개`);
    }

    // 🔥 normalize (핵심)
    normalize(text) {
        return String(text)
            .toLowerCase()
            .replace(/\s+/g, '') // 공백 제거
            .replace(/[^a-z0-9가-힣]/g, ''); // 특수문자 제거
    }

    // 🔥 유사 문자 치환
    replaceSimilar(text) {
        return text
            .replace(/ㅅ/g, '시')
            .replace(/ㅂ/g, '발')
            .replace(/tlqkf/g, '씨발');
    }

    // 🔥 리스트 검사
    contains(text) {
        const normalized = this.normalize(text);
        const replaced = this.replaceSimilar(normalized);

        for (const word of this.words) {
            if (replaced.includes(word)) {
                return true;
            }
        }

        return false;
    }

    // 🔥 패턴 검사
    checkPattern(text) {
        const normalized = this.normalize(text);

        return this.patterns.some(p => p.test(normalized));
    }

    // 🔥 최종 검사
    isBad(text) {
        if (!text) return false;

        if (this.contains(text)) return true;
        if (this.checkPattern(text)) return true;

        return false;
    }
}

module.exports = new BadWordService();
const fs = require('fs');
const path = require('path');

class UserService {
    constructor() {
        this.savePath = path.resolve(__dirname, '../users');

        if (!fs.existsSync(this.savePath)) {
            fs.mkdirSync(this.savePath, { recursive: true });
        }
    }

    getFilePath(uid) {
        return path.join(this.savePath, `${uid}.json`);
    }

    isNicknameDuplicate(nickname) {
        const target = this.normalize(nickname);

        const files = fs.readdirSync(this.savePath);

        for (const file of files) {
            const user = JSON.parse(
                fs.readFileSync(path.join(this.savePath, file), 'utf8')
            );

            if (!user.nickname) continue;

            const saved = this.normalize(user.nickname);

            if (saved === target) {
                return true;
            }
        }

        return false;
    }
    
    loadUser(uid) {
        const filePath = this.getFilePath(uid);

        // 🔥 없으면 신규 생성
        if (!fs.existsSync(filePath)) {
            const newUser = {
                uid: uid,

                // ❌ 삭제 (초기값 강제 금지)
                // nickname: "Player",
                // avatarIndex: 0,

                win: 0,
                lose: 0,
                tier: 10    // 10급 시작
            };

            this.saveUser(newUser);
            return newUser;
        }

        const raw = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(raw);
    }

    normalize(nickname) {
        return String(nickname || '')
            .trim()
            .toLowerCase()
            .replace(/\s+/g, ''); // 공백 제거 (중간 공백까지)
    }

    updateProfile(uid, nickname, avatarIndex) {
        const user = this.loadUser(uid);

        if (nickname != null)
            user.nickname = nickname.trim(); // 🔥 원본 유지

        if (avatarIndex != null)
            user.avatarIndex = avatarIndex;

        this.saveUser(user);
        return user;
    }

    // 🔥 PlayerSession -> 순수 저장용 객체로 변환
    toUserData(userLike) {
        return {
            uid: userLike.uid,
            nickname: userLike.nickname ?? null,
            avatarIndex: userLike.avatarIndex ?? null,
            win: userLike.win || 0,
            lose: userLike.lose || 0,
            tier: userLike.tier || 10
        };
    }

    saveUser(user) {
        // 서버 방어 코드
        if (!user.uid) {
            console.error("❌ uid undefined → 저장 차단");
            return;
        }

        const safeUser = this.toUserData(user);
        const filePath = this.getFilePath(safeUser.uid);

        fs.writeFileSync(
            filePath,
            JSON.stringify(safeUser, null, 2),
            'utf8'
        );
    }

    // 🔥 승패 반영 + 티어 계산
    applyMatchResult(winner, loser) {

        winner.win = (winner.win || 0) + 1;
        loser.lose = (loser.lose || 0) + 1;

        // 🔥 티어 계산 (간단 버전)
        winner.tier = this.calculateTier(winner.win, winner.lose);
        loser.tier = this.calculateTier(loser.win, loser.lose);

        this.saveUser(winner);
        this.saveUser(loser);
    }

    // 🔥 티어 계산 로직
    calculateTier(win, lose) {
        const score = win - lose;

        // 급 → 단 변환 기준
        if (score <= -10) return 10;
        if (score <= -5) return 9;
        if (score <= 0) return 8;
        if (score <= 5) return 7;
        if (score <= 10) return 6;
        if (score <= 15) return 5;
        if (score <= 20) return 4;
        if (score <= 25) return 3;
        if (score <= 30) return 2;
        if (score <= 35) return 1;

        // 단 시작
        return 11 + Math.floor((score - 36) / 5);
    }

    // 🔥 랭킹 TOP 10
    getTopUsers(limit = 10)
    {
        const files = fs.readdirSync(this.savePath);

        console.log("🔥 USERS 로딩: ", files);

        const users = files
            .map(file => JSON.parse(fs.readFileSync(path.join(this.savePath, file), 'utf8')))
            .filter(u => u.win > 0)
            .sort((a, b) => {
                const rateA = a.win / (a.win + a.lose);
                const rateB = b.win / (b.win + b.lose);

                if (rateB !== rateA)
                    return rateB - rateA;

                return b.tier - a.tier;
            })
            .slice(0, limit)
            .map(user => ({
                uid: user.uid,
                nickname: user.nickname,
                avatarIndex: user.avatarIndex,
                win: user.win,
                lose: user.lose,
                tier: user.tier
            }));

        return users;
    }
}

module.exports = new UserService();
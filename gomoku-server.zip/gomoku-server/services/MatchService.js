const UserService = require('../services/UserService');

const fs = require('fs');
const path = require('path');

class MatchService {
    constructor() {
        this.savePath = path.resolve(__dirname, '../matches');

        // 폴더 없으면 생성
        if (!fs.existsSync(this.savePath)) {
            fs.mkdirSync(this.savePath, { recursive: true });
        }
    }

    generateMatchId() {
        const now = new Date();

        const yyyy = now.getFullYear();
        const MM = String(now.getMonth() + 1).padStart(2, '0');
        const dd = String(now.getDate()).padStart(2, '0');

        const hh = String(now.getHours()).padStart(2, '0');
        const mm = String(now.getMinutes()).padStart(2, '0');
        const ss = String(now.getSeconds()).padStart(2, '0');

        const timePart = `${yyyy}${MM}${dd}_${hh}${mm}${ss}`;
        const random = Math.random().toString(36).slice(2, 5);

        return `M_${timePart}_${random}`;
    }

    createMatch(room) {
        return {
            matchId: this.generateMatchId(),

            players: room.players.map(p => ({
                playerId: p.playerId,
                uid: p.uid,
                nickname: p.nickname,
                avatarIndex: p.avatarIndex
            })),

            moves: [],

            startedAt: Date.now(),
            endedAt: null,

            winner: null,
            winLine: [],

            turnTime: room.turnTimeLimit,
            roomId: room.roomId
        };
    }

    saveMatch(match) {
        const filePath = path.join(this.savePath, `${match.matchId}.json`);

        fs.writeFileSync(filePath, JSON.stringify(match, null, 2), 'utf8');

        console.log(`💾 Match 저장 완료: ${match.matchId}`);
        console.log(`📂 저장 경로: ${filePath}`);
    }

    loadMatch(matchId) {
        const filePath = path.join(this.savePath, `${matchId}.json`);

        console.log(`📂 찾는 경로: ${filePath}`);
        console.log(`📂 존재 여부: ${fs.existsSync(filePath)}`);

        if (!fs.existsSync(filePath)) {
            return null;
        }

        const raw = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(raw);
    }

    getMatchListByUser(uid, limit = 20) {
        const files = fs.readdirSync(this.savePath);

        const matches = files
            .filter(file => file.endsWith('.json'))
            .map(file => {
                const raw = fs.readFileSync(path.join(this.savePath, file), 'utf8');
                return JSON.parse(raw);
            })
            // 🔥 여기 추가
            .filter(match => 
                match.players.some(p => p.uid === uid)
            )
            .sort((a, b) => b.startedAt - a.startedAt)
            .slice(0, limit)
            .map(match => ({
                matchId: match.matchId,
                players: match.players,
                winner: match.winner,
                startedAt: match.startedAt,
                endedAt: match.endedAt,
                turnTime: match.turnTime,
                roomId: match.roomId,
                moveCount: match.moves?.length || 0
            }));

        return matches;
    }

    // 🔥 ws ❌ → session 받도록 변경
    handleGetMatch(session, data) {

        const matchId = data?.matchId;

        console.log(`📩 GET_MATCH 요청: ${matchId}`);

        if (!matchId) {
            session.send({
                type: "MATCH_NOT_FOUND"
            });
            return;
        }

        const match = this.loadMatch(matchId);

        if (!match) {
            session.send({
                type: "MATCH_NOT_FOUND"
            });
            return;
        }

        session.send({
            type: "MATCH_DATA",
            matchId: match.matchId,
            players: match.players,
            moves: match.moves,
            winner: match.winner,
            winLine: match.winLine,
            startedAt: match.startedAt,
            endedAt: match.endedAt,
            turnTime: match.turnTime,
            roomId: match.roomId
        });
    }

    handleGetMatchList(session, limit = 20) {

        const matches = this.getMatchListByUser(session.uid, limit);

        session.send({
            type: "MATCH_LIST",
            matches: matches
        });
    }

    handleGetRanking(session) {
        const users = UserService.getTopUsers(10);

        console.log(users);

        session.send({
            type: "RANKING",
            users: users
        });

        console.log("RANKING 패킷 전달 완료: 서버 → 클라");
    }
}

module.exports = new MatchService();
const { createClient } = require('redis');
const fs = require('fs');
const path = require('path');

class NicknameCacheService {
    constructor() {
        this.client = createClient({
            url: process.env.REDIS_URL || 'redis://127.0.0.1:6379'
        });

        this.client.on('error', (err) => {
            console.error('❌ Redis Error:', err);
        });

        this.connected = false;

        this.USERS_KEY = 'gomoku:nicknames';
        this.RESERVE_PREFIX = 'gomoku:nickname:reserve:';
        this.RESERVE_TTL_SEC = 60;
    }

    async connectAndWarmup(usersPath) {
        if (!this.connected) {
            await this.client.connect();
            this.connected = true;
            console.log('✅ Redis connected');
        }

        await this.warmupFromUserFiles(usersPath);
    }

    normalize(nickname) {
        return String(nickname || '').trim().toLowerCase();
    }

    async warmupFromUserFiles(usersPath) {
        if (!fs.existsSync(usersPath)) return;

        const files = fs.readdirSync(usersPath);
        let count = 0;

        for (const file of files) {
            if (!file.endsWith('.json')) continue;

            const user = JSON.parse(
                fs.readFileSync(path.join(usersPath, file), 'utf8')
            );

            if (user.nickname) {
                await this.client.sAdd(this.USERS_KEY, this.normalize(user.nickname));
                count++;
            }
        }

        console.log(`🔥 Nickname Redis cache warmup 완료: ${count}개`);
    }

    async isDuplicate(nickname) {
        const keyName = this.normalize(nickname);

        const existsInConfirmed = await this.client.sIsMember(this.USERS_KEY, keyName);
        if (existsInConfirmed) return true;

        const reserved = await this.client.exists(this.RESERVE_PREFIX + keyName);
        return reserved === 1;
    }

    async reserve(nickname, uid) {
        const keyName = this.normalize(nickname);
        const lockKey = this.RESERVE_PREFIX + keyName;

        const result = await this.client.set(
            lockKey,
            uid,
            {
                NX: true,
                EX: this.RESERVE_TTL_SEC
            }
        );

        return result === 'OK';
    }

    async isReservedByMe(nickname, uid) {
        const keyName = this.normalize(nickname);
        const lockKey = this.RESERVE_PREFIX + keyName;

        const ownerUid = await this.client.get(lockKey);
        return ownerUid === uid;
    }

    async confirm(nickname) {
        const keyName = this.normalize(nickname);

        await this.client.sAdd(this.USERS_KEY, keyName);
        await this.client.del(this.RESERVE_PREFIX + keyName);
    }

    async cancelReservation(nickname) {
        const keyName = this.normalize(nickname);
        await this.client.del(this.RESERVE_PREFIX + keyName);
    }
}

module.exports = new NicknameCacheService();
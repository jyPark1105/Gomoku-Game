﻿using System.Collections.Generic;
using UnityEngine;

public enum AIDifficulty
{
    Beginner,
    Advanced
}

public class GomokuAI
{
    IGomokuRule rule;
    int size;

    public GomokuAI(IGomokuRule rule, int size)
    {
        this.rule = rule;
        this.size = size;
    }

    public Vector2Int GetMove(int[,] board, int aiPlayer, AIDifficulty difficulty)
    {
        int opponent = (aiPlayer == 1) ? 2 : 1;

        // 입문자 AI
        if (difficulty == AIDifficulty.Beginner)
        {
            // 1️⃣ 상대 5 막기
            var block = FindWinningMove(board, opponent);
            if (block.HasValue) return block.Value;

            // 🔥 2️⃣ 상대 4 막기 (추가)
            var block4 = FindOpenFourMove(board, opponent);
            if (block4.HasValue) return block4.Value;

            // 3️⃣ 가끔 공격
            if (Random.value < 0.3f)
            {
                var win = FindWinningMove(board, aiPlayer);
                if (win.HasValue) return win.Value;
            }

            return GetSmartRandom(board, aiPlayer);
        }

        // 숙련자 AI
        // 1️. 내가 이김
        var winMove = FindWinningMove(board, aiPlayer);
        if (winMove.HasValue) return winMove.Value;

        // 2️. 상대 이김 막기
        var blockMove = FindWinningMove(board, opponent);
        if (blockMove.HasValue) return blockMove.Value;

        // 🔥 3️. 상대 4 막기
        // 아래는 이름 바꾸기
        var block4_2 = FindOpenFourMove(board, opponent);
        if (block4_2.HasValue) return block4_2.Value;

        // 🔥 4️. 내가 4 만들기
        var make4 = FindOpenFourMove(board, aiPlayer);
        if (make4.HasValue) return make4.Value;

        return GetSmartRandom(board, aiPlayer);
    }

    Vector2Int? FindOpenFourMove(int[,] board, int player)
    {
        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                if (board[x, y] != 0) continue;

                Vector2Int pos = new Vector2Int(x, y);

                if (!rule.IsValidMove(board, pos, player, out _))
                    continue;

                // 🔥 가상 착수
                board[x, y] = player;

                int line = rule.GetLineCount(board, pos, player);

                board[x, y] = 0;

                // 🔥 4 이상이면 위험
                if (line >= 4)
                    return pos;
            }
        }

        return null;
    }

    // 🔥 승리 수 찾기
    Vector2Int? FindWinningMove(int[,] board, int player)
    {
        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                if (board[x, y] != 0) continue;

                Vector2Int pos = new Vector2Int(x, y);

                if (!rule.IsValidMove(board, pos, player, out _))
                    continue;

                board[x, y] = player;

                bool win = rule.CheckWin(board, pos, player);

                board[x, y] = 0;

                if (win)
                    return pos;
            }
        }

        return null;
    }

    // 🔥 기존 랜덤 (fallback용)
    Vector2Int GetRandomMove(int[,] board, int player)
    {
        List<Vector2Int> candidates = new List<Vector2Int>();

        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                if (board[x, y] != 0) continue;

                Vector2Int pos = new Vector2Int(x, y);

                if (!rule.IsValidMove(board, pos, player, out _))
                    continue;

                candidates.Add(pos);
            }
        }

        if (candidates.Count == 0)
            return new Vector2Int(size / 2, size / 2);

        return candidates[Random.Range(0, candidates.Count)];
    }

    // 🔥 핵심 추가 (주변 기반 랜덤)
    Vector2Int GetSmartRandom(int[,] board, int player)
    {
        List<Vector2Int> candidates = new List<Vector2Int>();

        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                if (board[x, y] != 0) continue;

                // 🔥 주변에 돌 있는 위치만 선택
                if (!HasNeighbor(board, x, y))
                    continue;

                Vector2Int pos = new Vector2Int(x, y);

                if (!rule.IsValidMove(board, pos, player, out _))
                    continue;

                candidates.Add(pos);
            }
        }

        // 🔥 주변 후보 없으면 fallback
        if (candidates.Count == 0)
            return GetRandomMove(board, player);

        return candidates[Random.Range(0, candidates.Count)];
    }

    // 🔥 주변 체크
    bool HasNeighbor(int[,] board, int x, int y)
    {
        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                if (dx == 0 && dy == 0) continue;

                int nx = x + dx;
                int ny = y + dy;

                if (nx < 0 || ny < 0 || nx >= size || ny >= size)
                    continue;

                if (board[nx, ny] != 0)
                    return true;
            }
        }

        return false;
    }
}
﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 룰 인터페이스
/// </summary>
public interface IGomokuRule
{
    bool CheckWin(int[,] board, Vector2Int pos, int player);
    bool IsValidMove(int[,] board, Vector2Int pos, int player, out string message);

    int GetLineCount(int[,] board, Vector2Int pos, int player);

    // 어느 방향에서 5가 만들어졌는지 + 좌표 5개 추출
    bool TryGetWinLine(int[,] board, Vector2Int pos, int player, out List<Vector2Int> winLine);
}
﻿using System.Collections.Generic;
using UnityEngine;

public class RenjuRule : IGomokuRule
{
    private readonly int size;

    // 1 = 흑, 2 = 백, 0 = 빈칸
    private const int EMPTY = 0;
    private const int BLACK = 1;
    private const int WHITE = 2;

    // C 코드의 의도를 Unity에서 안전하게 가져온 패턴 집합
    // X = 상대 돌 또는 경계
    // 0 = 빈칸
    // 1 = 내 돌
    //
    // 열린 3(실전에서 자주 필요한 형태)
    private static readonly string[] OpenThreePatterns =
    {
        "0011100", // . . O O O . .
        "0011010", // . . O O . O .
        "0010110", // . . O . O O .
        "0101100", // . O . O O . .
        "0110100", // . O O . O . .
    };

    // 열린 4 / 4 후보
    private static readonly string[] OpenFourPatterns =
    {
        "011110",   // . O O O O .
        "1011101",  // O . O O O . O 같은 복합형 방지용 아님, 참고용
        "0110110",  // . O O . O O .
        "0101110",  // . O . O O O .
        "0111010",  // . O O O . O .
    };

    public RenjuRule(int boardSize)
    {
        size = boardSize;
    }

    public bool IsValidMove(int[,] board, Vector2Int pos, int player, out string message)
    {
        message = "";

        // 이미 돌 있으면 여기서도 막아도 되지만, 네 Manager에서 이미 처리 중
        if (!IsInside(pos))
        {
            message = "보드 범위를 벗어났습니다.";
            return false;
        }

        if (board[pos.x, pos.y] != EMPTY)
        {
            message = "타깃 위치에 돌이 존재합니다.";
            return false;
        }

        // 백은 금수 없음
        if (player == WHITE)
            return true;

        // 흑 가상 착수
        board[pos.x, pos.y] = player;

        if (IsOverline(board, pos, player))
        {
            board[pos.x, pos.y] = EMPTY;
            message = "장목 금수입니다!";
            return false;
        }

        int openFourCount = CountOpenFours(board, pos, player);
        if (openFourCount >= 2)
        {
            board[pos.x, pos.y] = EMPTY;
            message = "4-4 금수입니다!";
            return false;
        }

        int openThreeCount = CountOpenThrees(board, pos, player);
        if (openThreeCount >= 2)
        {
            board[pos.x, pos.y] = EMPTY;
            message = "3-3 금수입니다!";
            return false;
        }

        board[pos.x, pos.y] = EMPTY;
        return true;
    }

    public bool CheckWin(int[,] board, Vector2Int pos, int player)
    {
        int maxCount = GetMaxLineCount(board, pos, player);

        // 백은 5 이상이면 승리
        if (player == WHITE)
            return maxCount >= 5;

        // 흑은 정확히 5만 승리
        return maxCount == 5;
    }

    public int GetLineCount(int[,] board, Vector2Int pos, int player)
    {
        return GetMaxLineCount(board, pos, player);
    }

    private int GetMaxLineCount(int[,] board, Vector2Int pos, int player)
    {
        return Mathf.Max(
            CountLine(board, pos, player, Vector2Int.right),
            CountLine(board, pos, player, Vector2Int.up),
            CountLine(board, pos, player, new Vector2Int(1, 1)),
            CountLine(board, pos, player, new Vector2Int(1, -1))
        );
    }

    private int CountLine(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        return 1
             + Count(board, pos, player, dir)
             + Count(board, pos, player, -dir);
    }

    private int Count(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        int count = 0;
        Vector2Int current = pos + dir;

        while (IsInside(current) && board[current.x, current.y] == player)
        {
            count++;
            current += dir;
        }

        return count;
    }

    private bool IsOverline(int[,] board, Vector2Int pos, int player)
    {
        return CountLine(board, pos, player, Vector2Int.right) > 5
            || CountLine(board, pos, player, Vector2Int.up) > 5
            || CountLine(board, pos, player, new Vector2Int(1, 1)) > 5
            || CountLine(board, pos, player, new Vector2Int(1, -1)) > 5;
    }

    private int CountOpenThrees(int[,] board, Vector2Int pos, int player)
    {
        int count = 0;

        Vector2Int[] dirs =
        {
            Vector2Int.right,
            Vector2Int.up,
            new Vector2Int(1, 1),
            new Vector2Int(1, -1)
        };

        foreach (var dir in dirs)
        {
            string line = GetLine(board, pos, player, dir, 4);

            if (ContainsAny(line, OpenThreePatterns) && !CreatesOpenFourImmediately(line))
                count++;
        }

        return count;
    }

    private int CountOpenFours(int[,] board, Vector2Int pos, int player)
    {
        int count = 0;

        Vector2Int[] dirs =
        {
            Vector2Int.right,
            Vector2Int.up,
            new Vector2Int(1, 1),
            new Vector2Int(1, -1)
        };

        foreach (var dir in dirs)
        {
            string line = GetLine(board, pos, player, dir, 5);

            if (IsFourLike(line))
                count++;
        }

        return count;
    }

    private bool IsFourLike(string line)
    {
        // 가장 핵심
        if (line.Contains("011110"))
            return true;

        // 끊어진 4 패턴
        if (line.Contains("0110110")) return true;
        if (line.Contains("0101110")) return true;
        if (line.Contains("0111010")) return true;

        return false;
    }

    private bool CreatesOpenFourImmediately(string line)
    {
        // 3-3과 4-4 중복 오판 감소용
        return line.Contains("011110");
    }

    private string GetLine(int[,] board, Vector2Int center, int player, Vector2Int dir, int radius)
    {
        // 내 돌 = 1, 빈칸 = 0, 상대/경계 = X
        System.Text.StringBuilder sb = new();

        for (int i = -radius; i <= radius; i++)
        {
            Vector2Int p = center + dir * i;
            sb.Append(CellToChar(board, p, player));
        }

        return sb.ToString();
    }

    private char CellToChar(int[,] board, Vector2Int p, int player)
    {
        if (!IsInside(p))
            return 'X';

        int cell = board[p.x, p.y];
        if (cell == EMPTY) return '0';
        if (cell == player) return '1';
        return 'X';
    }

    private bool ContainsAny(string line, IEnumerable<string> patterns)
    {
        foreach (var pattern in patterns)
        {
            if (line.Contains(pattern))
                return true;
        }
        return false;
    }

    private bool IsInside(Vector2Int p)
    {
        return p.x >= 0 && p.x < size && p.y >= 0 && p.y < size;
    }

    public bool TryGetWinLine(int[,] board, Vector2Int pos, int player, out List<Vector2Int> winLine)
    {
        winLine = new List<Vector2Int>();

        Vector2Int[] dirs =
        {
        Vector2Int.right,
        Vector2Int.up,
        new Vector2Int(1,1),
        new Vector2Int(1,-1)
    };

        foreach (var dir in dirs)
        {
            List<Vector2Int> line = new List<Vector2Int>();
            line.Add(pos);

            // 정방향
            line.AddRange(Collect(board, pos, player, dir));

            // 역방향
            line.AddRange(Collect(board, pos, player, -dir));

            if (line.Count >= 5)
            {
                // 정확히 5개만 추림 (중심 기준)
                winLine = GetExactFive(line, pos, dir);
                return true;
            }
        }

        return false;
    }

    List<Vector2Int> Collect(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        List<Vector2Int> result = new List<Vector2Int>();

        Vector2Int cur = pos + dir;

        while (IsInside(cur) && board[cur.x, cur.y] == player)
        {
            result.Add(cur);
            cur += dir;
        }

        return result;
    }

    List<Vector2Int> GetExactFive(List<Vector2Int> line, Vector2Int center, Vector2Int dir)
    {
        line.Sort((a, b) =>
        {
            if (dir.x != 0)
                return a.x.CompareTo(b.x);
            return a.y.CompareTo(b.y);
        });

        // 그냥 앞에서 5개
        return line.GetRange(0, 5);
    }
}
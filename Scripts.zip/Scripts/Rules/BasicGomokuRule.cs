﻿using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 5목 판정 클래스
/// </summary>
public class BasicGomokuRule : IGomokuRule
{
    int size;

    public BasicGomokuRule(int boardSize)
    {
        size = boardSize;
    }

    public bool CheckWin(int[,] board, Vector2Int pos, int player)
    {
        return CheckDirection(board, pos, player, Vector2Int.right) ||
               CheckDirection(board, pos, player, Vector2Int.up) ||
               CheckDirection(board, pos, player, new Vector2Int(1, 1)) ||
               CheckDirection(board, pos, player, new Vector2Int(1, -1));
    }

    public bool IsValidMove(int[,] board, Vector2Int pos, int player, out string message)
    {
        message = "";
        return true;
    }

    public int GetLineCount(int[,] board, Vector2Int pos, int player)
    {
        return Mathf.Max(
            CountLine(board, pos, player, Vector2Int.right),
            CountLine(board, pos, player, Vector2Int.up),
            CountLine(board, pos, player, new Vector2Int(1, 1)),
            CountLine(board, pos, player, new Vector2Int(1, -1))
        );
    }

    // 🔥 여기 추가 (핵심)
    public bool TryGetWinLine(int[,] board, Vector2Int pos, int player, out List<Vector2Int> winLine)
    {
        winLine = new List<Vector2Int>();

        Vector2Int[] dirs =
        {
            Vector2Int.right,
            Vector2Int.up,
            new Vector2Int(1,1),
            new Vector2Int(1,-1)
        };

        foreach (var dir in dirs)
        {
            List<Vector2Int> line = new List<Vector2Int>();
            line.Add(pos);

            line.AddRange(Collect(board, pos, player, dir));
            line.AddRange(Collect(board, pos, player, -dir));

            if (line.Count >= 5)
            {
                winLine = GetExactFive(line, dir);
                return true;
            }
        }

        return false;
    }

    // 🔥 보조 함수
    List<Vector2Int> Collect(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        List<Vector2Int> result = new List<Vector2Int>();

        Vector2Int cur = pos + dir;

        while (IsValid(cur) && board[cur.x, cur.y] == player)
        {
            result.Add(cur);
            cur += dir;
        }

        return result;
    }

    // 🔥 5개만 추출
    List<Vector2Int> GetExactFive(List<Vector2Int> line, Vector2Int dir)
    {
        line.Sort((a, b) =>
        {
            if (dir.x != 0)
                return a.x.CompareTo(b.x);
            return a.y.CompareTo(b.y);
        });

        return line.GetRange(0, 5);
    }

    bool CheckDirection(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        int count = 1;
        count += Count(board, pos, player, dir);
        count += Count(board, pos, player, -dir);
        return count >= 5;
    }

    int Count(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        int count = 0;
        Vector2Int current = pos + dir;

        while (IsValid(current) && board[current.x, current.y] == player)
        {
            count++;
            current += dir;
        }

        return count;
    }

    int CountLine(int[,] board, Vector2Int pos, int player, Vector2Int dir)
    {
        return 1 + Count(board, pos, player, dir)
                 + Count(board, pos, player, -dir);
    }

    bool IsValid(Vector2Int pos)
    {
        return pos.x >= 0 && pos.x < size &&
               pos.y >= 0 && pos.y < size;
    }
}
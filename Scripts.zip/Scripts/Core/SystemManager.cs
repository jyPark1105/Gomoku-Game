﻿using System.Collections;
using UnityEngine;
using TMPro;

public class SystemManager : MonoBehaviour
{
    public TMP_Text systemText;

    Coroutine currentRoutine;

    public void ShowMessage(string message)
    {
        // 👉 기존 코루틴 중지
        if (currentRoutine != null)
        {
            StopCoroutine(currentRoutine);
        }

        currentRoutine = StartCoroutine(AnimateMessage(message));
    }

    IEnumerator AnimateMessage(string message)
    {
        systemText.text = message;

        Color color = systemText.color;

        // 🔥 Fade In
        float t = 0;
        while (t < 1f)
        {
            t += Time.deltaTime * 4f;
            color.a = Mathf.Lerp(0, 1, t);
            systemText.color = color;
            yield return null;
        }

        // 🔥 유지
        yield return new WaitForSeconds(1.5f);

        // 🔥 Fade Out
        t = 0;
        while (t < 1f)
        {
            t += Time.deltaTime * 2f;
            color.a = Mathf.Lerp(1, 0, t);
            systemText.color = color;
            yield return null;
        }

        currentRoutine = null;
    }
}
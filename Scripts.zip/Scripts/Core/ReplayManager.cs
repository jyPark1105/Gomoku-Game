﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

// 🔥 [Replay 최적화]
// 기존:
// - JumpTo 시 ResetGame + 전체 재생성 → O(n)
// - 슬라이더 이동 시 프레임 드랍 발생 (특히 모바일)
//
// 개선:
// - 현재 상태 기준 "차이만 처리"
// - 앞으로 이동 → 돌 추가
// - 뒤로 이동 → 마지막 돌 제거
//
// 추가 최적화:
// - Replay에서는 애니메이션 제거 (Destroy 즉시 실행)
//
// 결과:
// - 시간복잡도 O(n) → O(k)
// - CPU 사용량 감소
// - 모바일 환경에서도 부드러운 리플레이 UX 확보
public class ReplayManager : MonoBehaviour
{
    private GomokuManager gomoku;
    private ReplayUI replayUI;

    private float replaySpeed = 1.0f;
    private bool isPaused = false;
    private int replayIndex = 0;
    private Coroutine replayCoroutine;

    private MatchDataPacket currentData;

    public void Init(GomokuManager gomokuManager, ReplayUI ui)
    {
        gomoku = gomokuManager;
        replayUI = ui;
    }

    // 🔥 Replay 시작
    public void StartReplay(MatchDataPacket data)
    {
        Debug.Log("🎬 Replay 시작");

        currentData = data;
        replayIndex = 0;
        isPaused = false;

        gomoku.ResetGame();

        gomoku.SetReplayModeState();

        replayUI.PrepareReplayView();

        gomoku.SetGameplayUIPublic(false);
        
        gomoku.EnableMoveHistoryView();

        replayUI.SetupReplayUI(currentData.moves.Length);

        if (replayCoroutine != null)
            StopCoroutine(replayCoroutine);

        replayCoroutine = StartCoroutine(ReplayRoutine());
    }

    private IEnumerator ReplayRoutine()
    {
        yield return new WaitForSeconds(0.5f);

        while (replayIndex < currentData.moves.Length)
        {
            if (isPaused)
            {
                yield return null;
                continue;
            }

            var move = currentData.moves[replayIndex];

            gomoku.PlaceReplayStonePublic(
                new Vector2Int(move.x, move.y),
                move.player
            );

            replayIndex++;

            replayUI.UpdateMoveText(replayIndex, currentData.moves.Length);
            replayUI.UpdateSlider();

            float delay = 0.7f / replaySpeed;
            float t = 0f;

            while (t < delay)
            {
                if (!isPaused)
                    t += Time.deltaTime;

                yield return null;
            }
        }

        // 🔥 winLine 변환
        List<Vector2Int> winLineList = new List<Vector2Int>();

        foreach (var p in currentData.winLine)
        {
            winLineList.Add(new Vector2Int(p.x, p.y));
        }

        gomoku.ShowWinLinePublic(winLineList);

        gomoku.EnableMoveHistoryView();

        Debug.Log("🎬 Replay 완료");
    }

    // ⏸ Pause
    public void TogglePause()
    {
        isPaused = !isPaused;
    }

    public void SetPaused(bool pause)
    {
        isPaused = pause;
    }

    // ⏩ Speed
    public void SetSpeed(float speed)
    {
        replaySpeed = speed;
    }

    // ⬅ Back
    public void StepBack()
    {
        if (replayIndex <= 0) return;

        replayIndex--;

        gomoku.ResetGame();

        for (int i = 0; i < replayIndex; i++)
        {
            var move = currentData.moves[i];

            gomoku.PlaceReplayStonePublic(
                new Vector2Int(move.x, move.y),
                move.player
            );
        }

        replayUI.UpdateMoveText(replayIndex, currentData.moves.Length);
        replayUI.UpdateSlider();
    }

    // ➡ Forward
    public void StepForward()
    {
        if (replayIndex >= currentData.moves.Length) return;

        var move = currentData.moves[replayIndex];

        gomoku.PlaceReplayStonePublic(
            new Vector2Int(move.x, move.y),
            move.player
        );

        replayIndex++;

        replayUI.UpdateMoveText(replayIndex, currentData.moves.Length);
        replayUI.UpdateSlider();
    }

    public int GetCurrentIndex()
    {
        return replayIndex;
    }

    public void JumpTo(int index)
    {
        if (currentData == null) return;

        index = Mathf.Clamp(index, 0, currentData.moves.Length);

        // 🔥 앞으로 이동 (추가만)
        if (index > replayIndex)
        {
            for (int i = replayIndex; i < index; i++)
            {
                var move = currentData.moves[i];

                gomoku.PlaceReplayStonePublic(
                    new Vector2Int(move.x, move.y),
                    move.player
                );
            }
        }
        // 🔥 뒤로 이동 (삭제만)
        else if (index < replayIndex)
        {
            for (int i = replayIndex - 1; i >= index; i--)
            {
                gomoku.RemoveLastStoneReplay(); // 🔥 핵심
            }
        }

        replayIndex = index;

        replayUI.UpdateMoveText(replayIndex, currentData.moves.Length);
        replayUI.UpdateSlider();
    }

    public void StopReplay()
    {
        if (replayCoroutine != null)
        {
            StopCoroutine(replayCoroutine);
            replayCoroutine = null;
        }
    }
}
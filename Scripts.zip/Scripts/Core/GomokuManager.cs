﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using TMPro;
using System.Collections.Generic;
using System;

public struct Move
{
    public int x;
    public int y;
    public int player;

    public Move(int x, int y, int player)
    {
        this.x = x;
        this.y = y;
        this.player = player;
    }
}

public class GomokuManager : MonoBehaviour
{
    [Header("Script References")]
    public LobbyUIManager lobbyUI;
    public SystemManager systemManager;
    public GameStartUI gameStartPanelUI;
    public RoomUIManager roomUI;
    public PlayerUIManager playerUI;
    public ReplayUI replayUI;
    public WinReasonUI winReasonUI;
    public ChatUIManager chatUI;
    public ReplayManager replayManager;
    public MatchHistoryUI matchHistoryUI;
    public RankingUI rankingUI;
    public ColorPickUI colorPickUI;

    [Header("Extra Managers")]
    public UndoUIManager undoUI;

    private GomokuGameState state = new GomokuGameState();
    private NetworkMessageRouter messageRouter;

    [Header("Board")]
    public int size = 19;
    public int[,] board;
    public RectTransform boardRect; // BoardImage 넣어라

    [Header("Stone")]
    public GameObject blackStonePrefab;
    public GameObject whiteStonePrefab;

    [Header("InGameUI Buttons")]
    public GameObject confirmPlaceButton;
    public GameObject undoButton;
    public GameObject moveUpButton;
    public GameObject moveDownButton;
    public GameObject moveLeftButton;
    public GameObject moveRightButton;

    public TMP_Text targetText; // Crosshair

    private IGomokuRule rule;

    private float cellSize;

    private int currentPlayer = 1;

    private Vector2Int currentTarget;
    private bool hasTarget = false;

    public GameObject targetMarkerPrefab;
    private GameObject currentMarker;

    public GameObject winMarkerPrefab;
    private List<GameObject> winMarkers = new List<GameObject>();

    // 게임 모드 설정
    private GameMode gameMode = GameMode.Practice;
    private bool isReplayMode = false;

    /// <summary>
    /// AI 필드
    /// </summary>
    private GomokuAI ai;
    public bool vsAI = true;
    public int aiPlayer = 2; // 백
    private AIDifficulty difficulty = AIDifficulty.Beginner;

    /// <summary>
    /// 수 기록
    /// </summary>
    public TMP_Text moveText;
    private List<Move> moveHistory = new List<Move>();
    // 🔥 돌 StoneUI 같이 관리
    private List<StoneUI> stoneHistory = new List<StoneUI>();
    private bool showAllMoves = false;

    // Turn 관련
    public TurnTimerUI[] turnTimers; // [0] = Player1, [1] = Player2

    public GameObject inGameUI;
    public GameObject inReplayUI;

    private string lastMatchId;
    private void Awake()
    {
        board = new int[size, size];

        ai = new GomokuAI(rule, size);

        cellSize = boardRect.rect.width / (size - 1);

        Debug.Log("Cell Size: " + cellSize);
    }

    private void Start()
    {
        messageRouter = new NetworkMessageRouter(
            lobbyUI,
            this,
            state,
            gameStartPanelUI,
            roomUI,
            playerUI,
            replayUI,
            undoUI,
            systemManager,
            turnTimers,
            winReasonUI,
            chatUI,
            matchHistoryUI,
            rankingUI,
            colorPickUI
        );

        replayManager.Init(this, replayUI);

        ConnectToServer(); // 🔥 게임 시작 시 자동 연결

        if (lobbyUI != null)
            lobbyUI.EnterOnlineLobby();
    }

    private void Update()
    {
        if (!state.gameStarted || state.isGameOver) return;

        if (!state.isGameStarted) return;

        // 🔥 입력 분리
        HandleInput();

        // 🔥 Undo 버튼 상태 갱신
        UpdateUndoButton();
    }

    private void HandleInput()
    {
#if UNITY_EDITOR || UNITY_STANDALONE
        HandleMouseInput();
#elif UNITY_ANDROID || UNITY_IOS
        HandleTouchInput();
#endif
    }

    /// <summary>
    /// Editor + Build
    /// </summary>
    private void HandleMouseInput()
    {
        if (Input.GetMouseButtonDown(0))
        {
            TryPlaceStone(Input.mousePosition);
        }
    }

    /// <summary>
    /// Only Mobile
    /// </summary>
    private void HandleTouchInput()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                TryPlaceStone(touch.position);
            }
        }
    }

    private void TryPlaceStone(Vector2 screenPos)
    {
        Debug.Log("🎯 클릭됨: " + screenPos);

        Vector2 localPoint;

        RectTransformUtility.ScreenPointToLocalPointInRectangle(
            boardRect,
            screenPos,
            null,
            out localPoint
        );

        Vector2Int grid = LocalToGrid(localPoint);

        if (!IsValid(grid)) return;

        // 👉 돌 놓는 대신 타겟 설정
        SetTarget(grid);
    }

    private void SetTarget(Vector2Int grid)
    {
        currentTarget = grid;
        hasTarget = true;

        float half = boardRect.rect.width / 2f;

        Vector2 localPos = new Vector2(
            -half + grid.x * cellSize,
            -half + grid.y * cellSize
        );

        if (currentMarker == null)
        {
            currentMarker = Instantiate(targetMarkerPrefab, boardRect);
        }
        else
        {
            currentMarker.SetActive(true); // 🔥 다시 보이게
        }

        currentMarker.GetComponent<RectTransform>().anchoredPosition = localPos;

        // 🔥 추가 (핵심)
        UpdateTargetText(grid);
    }

    private Vector2Int LocalToGrid(Vector2 localPos)
    {
        // 👉 Board 기준 좌측 하단 = (-width/2, -height/2)
        float half = boardRect.rect.width / 2f;

        int x = Mathf.RoundToInt((localPos.x + half) / cellSize);
        int y = Mathf.RoundToInt((localPos.y + half) / cellSize);

        return new Vector2Int(x, y);
    }

    private bool IsValid(Vector2Int pos)
    {
        return pos.x >= 0 && pos.x < size &&
               pos.y >= 0 && pos.y < size;
    }

    private void SpawnStone(Vector2Int grid, int player)
    {
        AudioManager.Instance.PlayClick();

        float half = boardRect.rect.width / 2f;

        Vector2 localPos = new Vector2(
            -half + grid.x * cellSize,
            -half + grid.y * cellSize
        );

        GameObject prefab = (player == 1) ? blackStonePrefab : whiteStonePrefab;

        GameObject stone = Instantiate(prefab, boardRect);

        RectTransform rt = stone.GetComponent<RectTransform>();
        rt.anchoredPosition = localPos;

        StoneUI stoneUI = stone.GetComponent<StoneUI>();
        stoneHistory.Add(stoneUI);

        UpdateMoveNumberDisplay();
    }

    private void SwitchTurn()
    {
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
        state.currentPlayer = currentPlayer;
    }

    public void ConfirmPlace()
    {
        Debug.Log("🔥 ConfirmPlace 호출됨");

        // 무르기 요청으로 인한 돌 놓기 금지
        if (state.isUndoPending)
        {
            Debug.Log("❌ Undo 진행 중에는 돌을 놓을 수 없음");
            return;
        }

        // 재시작 요청으로 인한 돌 놓기 금지
        if (state.isRestartPending)
        {
            Debug.Log("❌ 재시작 요청 중에는 플레이 불가");
            return;
        }

        // 🔥 온라인에서만 내 턴 체크
        if (gameMode == GameMode.Online && !state.isMyTurn)
        {
            Debug.Log("❌ 내 턴 아님");
            return;
        }

        if (!hasTarget) return;

        if (board[currentTarget.x, currentTarget.y] != 0)
        {
            systemManager.ShowMessage("타깃 위치에 돌이 존재합니다.");
            AudioManager.Instance.PlayInvalid();
            return;
        }

        Debug.Log("🎯 서버로 보냄");

        // 👉 이제 안전하게 놓는다
        if (gameMode == GameMode.Online)
        {
            SendMoveToServer(currentTarget);
        }
        else
        {
            PlaceStone(currentTarget, currentPlayer);
        }
    }

    private void PlaceStone(Vector2Int pos, int player)
    {
        board[pos.x, pos.y] = player;

        moveHistory.Add(new Move(pos.x, pos.y, player));

        SpawnStone(pos, player);

        UpdateMoveText();

        // 🔥 플레이어 턴 끝났으면 Undo 초기화
        if (gameMode == GameMode.VS_AI && player != aiPlayer)
        {
            state.undoUsedThisTurn = false;
        }

        SwitchTurn();

        hasTarget = false;

        if (currentMarker != null)
            currentMarker.SetActive(false);

        if (targetText != null)
            targetText.text = "";

        // 🔥 턴 끝났으면 초기화
        if (gameMode == GameMode.Online)
        {
            state.undoUsedThisTurn = false;

            return;
        }

        if (gameMode == GameMode.VS_AI && currentPlayer == aiPlayer)
        {
            StartCoroutine(AITurn());
        }
    }

    private IEnumerator AITurn()
    {
        yield return new WaitForSeconds(0.3f); // 약간 텀

        Vector2Int move = ai.GetMove(board, aiPlayer, difficulty);

        PlaceStone(move, aiPlayer);
    }

    public void SetDifficulty(AIDifficulty diff)
    {
        difficulty = diff;
        state.gameStarted = true;
    }

    public void Undo()
    {
        // 🔥 1. Online
        if (gameMode == GameMode.Online)
        {
            UndoOnline();
            return;
        }

        // 🔥 2. 기존 로컬 로직 유지
        UndoLocal();
    }

    private void UndoOnline()
    {
        // 게임 종료
        if (state.isGameOver || !state.isGameStarted)
        {
            systemManager.ShowMessage("현재는 무르기를 요청할 수 없습니다.");
            return;
        }

        // 이미 사용
        if (state.undoUsedThisTurn)
        {
            systemManager.ShowMessage("이번 턴에는 이미 사용했습니다.");
            return;
        }

        // 이미 요청 중
        if (state.isUndoPending)
        {
            systemManager.ShowMessage("이미 무르기 요청 중입니다.");
            return;
        }

        // 🔥 내 턴이면 금지
        if (state.isMyTurn)
        {
            systemManager.ShowMessage("상대 턴에서만 무르기를 요청할 수 있습니다.");
            return;
        }

        // 재시작 요청 중
        if (state.isRestartPending)
        {
            systemManager.ShowMessage("재시작 요청 중에는 무르기를 사용할 수 없습니다.");
            return;
        }

        NetworkController.Instance.SendUndoRequest();

        state.isUndoPending = true;
        state.undoUsedThisTurn = true;  // 현재 턴 '무르기 사용'

        undoUI.ShowRequestingPanel();

        systemManager.ShowMessage("상대에게 무르기를 요청했습니다.");
    }

    public void UndoLocal()
    {
        // 무르기 비활성화 상태
        if (!state.undoEnabled)
        {
            systemManager.ShowMessage("무르기 비활성화 상태입니다.");
            return;
        }

        // 🔥 공통: 기록 없으면 불가
        if (moveHistory.Count == 0)
            return;

        // =========================
        // 🟢 Practice 모드
        // =========================
        if (gameMode == GameMode.Practice)
        {
            // 쿨타임
            if (Time.time - state.lastUndoTime < 0.5f)
                return;

            state.lastUndoTime = Time.time;

            UndoSingle();
            return;
        }

        // =========================
        // 🔴 AI 모드
        // =========================
        if (gameMode == GameMode.VS_AI)
        {
            // 1️⃣ 플레이어 턴인지 체크
            if (currentPlayer != aiPlayer) // 플레이어 턴만 Undo 가능
            {
                // 2️⃣ 턴당 1회 제한
                if (state.undoUsedThisTurn)
                {
                    systemManager.ShowMessage("이번 턴에서는 이미 무르기를 사용했습니다.");
                    return;
                }

                // 3️⃣ 횟수 제한
                int maxUndo = (difficulty == AIDifficulty.Beginner) ? 10 : 3;

                if (state.undoCount >= maxUndo)
                {
                    systemManager.ShowMessage("무르기 횟수를 모두 사용했습니다.");
                    return;
                }

                // 🔥 실행
                UndoSingle(); // 플레이어
                UndoSingle(); // AI

                state.undoCount++;
                state.undoUsedThisTurn = true;

                systemManager.ShowMessage($"무르기 ({state.undoCount}/{maxUndo})");
            }

            return;
        }
    }

    private void UndoSingle()
    {
        if (moveHistory.Count == 0)
            return;

        Move lastMove = moveHistory[moveHistory.Count - 1];
        moveHistory.RemoveAt(moveHistory.Count - 1);

        // 보드 복구
        board[lastMove.x, lastMove.y] = 0;

        // 돌 제거
        if (stoneHistory.Count > 0)
        {
            StoneUI stone = stoneHistory[stoneHistory.Count - 1];
            stoneHistory.RemoveAt(stoneHistory.Count - 1);

            if (stone != null)
                StartCoroutine(RemoveStoneWithAnimation(stone));
        }

        // 턴 되돌림
        SwitchTurn();

        UpdateMoveText();
    }

    public void MoveUp()
    {
        MoveTarget(Vector2Int.up);
    }

    public void MoveDown()
    {
        MoveTarget(Vector2Int.down);
    }

    public void MoveLeft()
    {
        MoveTarget(Vector2Int.left);
    }

    public void MoveRight()
    {
        MoveTarget(Vector2Int.right);
    }

    private void MoveTarget(Vector2Int dir)
    {
        AudioManager.Instance.PlayClick();

        if (!hasTarget) return;

        Vector2Int newPos = currentTarget + dir;

        if (!IsValid(newPos)) return;

        SetTarget(newPos);
    }

    private void UpdateTargetText(Vector2Int grid)
    {
        if (targetText == null) return;

        // 👉 0-based → 사람이 보기 쉽게 +1
        int x = grid.x + 1;
        int y = grid.y + 1;

        targetText.text = $"({x}, {y})";
    }

    public void SetGameMode(GameMode mode)
    {
        gameMode = mode;
        state.gameStarted = true;
    }

    private void UpdateMoveText()
    {
        if (moveText == null) return;

        int current = moveHistory.Count;
        int max = size * size;

        moveText.text = $"수 현황: {current}/{max}";
    }

    public void ResetGame()
    {
        StopAllCoroutines();

        state.ResetBoardRelatedState();

        // 🔥 보드 초기화
        for (int x = 0; x < size; x++)
        {
            for (int y = 0; y < size; y++)
            {
                board[x, y] = 0;
            }
        }

        // 🔥 1️⃣ stoneHistory 기반 제거
        foreach (var stone in stoneHistory)
        {
            if (stone != null)
                Destroy(stone);
        }
        stoneHistory.Clear();

        // 🔥 2️⃣ 혹시 누락된 돌까지 강제 제거 (보험)
        List<Transform> children = new List<Transform>();
        foreach (Transform child in boardRect)
        {
            children.Add(child);
        }

        foreach (Transform child in children)
        {
            if (child == null) continue;

            if (currentMarker != null && child.gameObject == currentMarker)
                continue;

            Destroy(child.gameObject);
        }

        // 🔥 기록 초기화
        moveHistory.Clear();

        currentPlayer = 1;
        state.currentPlayer = 1;
        hasTarget = false;

        if (currentMarker != null)
            currentMarker.SetActive(false);

        if (targetText != null)
            targetText.text = "";

        UpdateMoveText();

        // 🔥 승리 마커 제거
        foreach (var marker in winMarkers)
        {
            if (marker != null)
                Destroy(marker);
        }
        winMarkers.Clear();

        // 양쪽 턴 타이머 표시 초기화
        for (int i = 0; i < turnTimers.Length; i++)
        {
            if (turnTimers[i] != null)
            {
                turnTimers[i].Init(state.currentTurnTimeLimit);
                turnTimers[i].SetMissCount(0);
                turnTimers[i].HideTimer();
            }
        }

        systemManager.ShowMessage("초기화 완료");
    }

    private void ShowWinLine(List<Vector2Int> winLine)
    {
        float half = boardRect.rect.width / 2f;

        Debug.Log("winLine count: " + winLine.Count);

        foreach (var pos in winLine)
        {
            Debug.Log($"pos: {pos}");

            Vector2 localPos = new Vector2(
                -half + pos.x * cellSize,
                -half + pos.y * cellSize
            );

            GameObject marker = Instantiate(winMarkerPrefab, boardRect);

            RectTransform rt = marker.GetComponent<RectTransform>();
            rt.anchoredPosition = localPos;

            winMarkers.Add(marker);

            // 🔥 애니메이션 실행
            StartCoroutine(AnimateWinMarker(marker));
        }
    }

    private IEnumerator AnimateWinMarker(GameObject marker)
    {
        RectTransform rt = marker.GetComponent<RectTransform>();
        CanvasGroup cg = marker.GetComponent<CanvasGroup>();

        // 초기 상태
        if (rt != null)
            rt.localScale = Vector3.zero;

        if (cg != null)
            cg.alpha = 0f;

        float duration = 0.2f;
        float t = 0;

        while (t < 1f)
        {
            t += Time.deltaTime / duration;

            // 🔥 Scale (부드럽게)
            float scale = Mathf.Lerp(0f, 1.2f, t);
            if (rt != null)
                rt.localScale = new Vector3(scale, scale, scale);

            // 🔥 Fade In
            if (cg != null)
                cg.alpha = Mathf.Lerp(0f, 1f, t);

            yield return null;
        }

        // 최종 보정
        if (rt != null)
            rt.localScale = Vector3.one;

        if (cg != null)
            cg.alpha = 1f;
    }

    /// <summary>
    /// 서버 연결 함수
    /// </summary>
    public void ConnectToServer()
    {
        if (NetworkController.Instance != null && state.isConnected)
            return;

        Debug.Log("🔥 서버 연결 시도");

        if (NetworkController.Instance == null)
            gameObject.AddComponent<NetworkController>();

        NetworkController.Instance.OnMessageReceived -= OnReceiveMessage;
        NetworkController.Instance.OnMessageReceived += OnReceiveMessage;

        NetworkController.Instance.OnConnected -= HandleConnected;
        NetworkController.Instance.OnConnected += HandleConnected;

        NetworkController.Instance.Connect();
    }

    private void HandleConnected()
    {
        state.isConnected = true;

        Debug.Log("🔥 서버 연결 완료");

        if (gameStartPanelUI != null)
        {
            gameStartPanelUI.SetRoomButtons(true);
        }
    }

    /// <summary>
    /// 서버 메시지 처리
    /// </summary>
    /// <param name="msg"></param>
    private void OnReceiveMessage(string msg)
    {
        if (messageRouter == null)
            return;

        messageRouter.Handle(msg);
    }

    public void SetGameplayUIPublic(bool enable)
    {
        SetGameplayUI(enable);
    }

    public void PlaceStonePublic(Vector2Int pos, int player)
    {
        PlaceStone(pos, player);
    }

    public void ShowWinLinePublic(List<Vector2Int> winLine)
    {
        ShowWinLine(winLine);
    }

    public void OnGameEndPublic(int winner, string reason = "")
    {
        OnGameEnd(winner, reason);
    }

    public IEnumerator ShowReplayPanelAfterDelayPublic()
    {
        yield return ShowReplayPanelAfterDelay();
    }

    public void HideReplayPanelsPublic()
    {
        replayUI.HideReplayPanels();
    }

    public void ShowGameEndPanelPublic(bool show)
    {
        replayUI.ShowGameEndPanel();
    }

    public void ShowReplayRequestPanelPublic(bool show)
    {
        replayUI.ShowReplayRequestPanel(show);
    }

    public void ShowReplayRequestingPanelPublic(bool show)
    {
        replayUI.ShowReplayRequestingPanel(show);
    }

    public int GetOtherIdPublic(int myId)
    {
        return GetOtherId(myId);
    }

    private int GetOtherId(int myId)
    {
        if (myId == 1) return 2;
        if (myId == 2) return 1;
        return 0;
    }

    public Coroutine StartCoroutinePublic(IEnumerator routine)
    {
        return StartCoroutine(routine);
    }

    public bool IsGameOverPublic()
    {
        return state.isGameOver;
    }

    public bool IsMyTurnPublic()
    {
        return state.isMyTurn;
    }

    public int GetMyPlayerIdPublic()
    {
        return state.myPlayerId;
    }

    public int GetCurrentRoomIdPublic()
    {
        return state.currentRoomId;
    }

    public int GetCurrentTurnTimeLimitPublic()
    {
        return state.currentTurnTimeLimit;
    }

    public bool IsUndoEnabledPublic()
    {
        return state.undoEnabled;
    }

    public void SetUndoEnabledPublic(bool enabled)
    {
        state.undoEnabled = enabled;
    }

    public void SetConnectedPublic(bool connected)
    {
        state.isConnected = connected;
    }

    public void SetMyTurnPublic(bool myTurn)
    {
        state.isMyTurn = myTurn;
    }

    public void SetMyPlayerIdPublic(int playerId)
    {
        state.myPlayerId = playerId;
    }

    public void SetCurrentRoomIdPublic(int roomId)
    {
        state.currentRoomId = roomId;
    }

    public void SetRestartPendingPublic(bool pending)
    {
        state.isRestartPending = pending;
    }

    public void SetRequesterPublic(bool requester)
    {
        state.isRequester = requester;
    }

    /// <summary>
    /// UI 통제: 게임 시작 전 & 후
    /// </summary>
    /// <param name="enable"></param>
    private void SetGameplayUI(bool enable)
    {
        // 돌 놓기
        if (confirmPlaceButton != null)
            confirmPlaceButton.SetActive(enable);

        // 무르기
        if (undoButton != null)
            undoButton.SetActive(enable);

        // 채팅창 버튼
        if (chatUI.chatOpenButton != null)
            chatUI.chatOpenButton.SetActive(enable);

        // 상하좌우로 타깃 옮기기
        if (moveUpButton != null)
            moveUpButton.SetActive(enable);
        if (moveDownButton != null)
            moveDownButton.SetActive(enable);
        if (moveLeftButton != null)
            moveLeftButton.SetActive(enable);
        if (moveRightButton != null)
            moveRightButton.SetActive(enable);
    }

    private void SendMoveToServer(Vector2Int pos)
    {
        Debug.Log($"📤 서버로 MOVE 전송: {pos}");

        MovePacket packet = new MovePacket
        {
            type = "MOVE",
            x = pos.x,
            y = pos.y
        };

        string json = JsonUtility.ToJson(packet);

        NetworkController.Instance.Send(json);
    }

    /// <summary>
    /// 클라이언트에서 앱 백그라운드/포그라운드 보내기
    /// </summary>
    /// <param name="pause"></param>
    private void OnApplicationPause(bool pause)
    {
        if (NetworkController.Instance == null)
            return;

        if (!IsNetworkConnected())
            return;

        var packet = new BasePacket
        {
            type = pause ? "APP_BACKGROUND" : "APP_FOREGROUND"
        };

        string json = JsonUtility.ToJson(packet);

        NetworkController.Instance.Send(json);
    }

    private void OnGameEnd(int winner, string reason = "")
    {
        state.isGameOver = true;
        state.isGameStarted = false;
        state.isMyTurn = false;

        AudioManager.Instance.PlayWin();

        // 전체 수 보여주기
        EnableMoveHistoryView();

        // 🔥 하이라이트 전부 끄기
        playerUI.p1Highlight.gameObject.SetActive(false);
        playerUI.p2Highlight.gameObject.SetActive(false);

        if (reason == "DISCONNECT")
        {
            if (winner == state.myPlayerId)
                systemManager.ShowMessage("상대가 연결을 끊어 승리했습니다.");
            else
                systemManager.ShowMessage("연결이 종료되어 패배했습니다.");
        }
        else if (reason == "TIMEOUT")
        {
            if (winner == state.myPlayerId)
                systemManager.ShowMessage("상대가 3회 연속 착수하지 않아 승리했습니다.");
            else
                systemManager.ShowMessage("3회 연속 미착수로 인해 패배했습니다.");
        }
        else
        {
            systemManager.ShowMessage($"플레이어 {winner} 승리!");
        }

        // 턴 타이머 종료
        for (int i = 0; i < turnTimers.Length; i++)
        {
            if (turnTimers[i] != null)
                turnTimers[i].HideTimer();
        }
    }

    public bool IsNetworkConnected()
    {
        return state.isConnected;
    }

    public void RequestJoinRoom(int roomId)
    {
        state.pendingRoomId = roomId;
        state.hasPendingJoin = true;
    }

    public int GetPendingRoomId()
    {
        return state.pendingRoomId;
    }

    public bool HasPendingJoin()
    {
        return state.hasPendingJoin;
    }

    public void ClearPendingJoin()
    {
        state.pendingRoomId = -1;
        state.hasPendingJoin = false;
    }

    public void EnterRoomState(int roomId)
    {
        Debug.Log("방 입장하기");

        state.currentRoomId = roomId;

        // 🔥 Room UI 표시
        if (roomUI != null)
            roomUI.ShowRoomUI(roomId);

        // 🔥 게임 버튼 전부 OFF
        SetGameplayUI(false);

        // 🔥 Ready 버튼은 아직 숨김 (ROOM_FULL 때 활성화)
        if (roomUI != null && roomUI.readyButton != null)
            roomUI.readyButton.gameObject.SetActive(false);
    }

    public void LeaveRoom()
    {
        Debug.Log("🚪 방 나가기");

        // 🔥 서버에 방 나가기 요청
        if (NetworkController.Instance != null)
        {
            NetworkController.Instance.LeaveRoom();
        }

        // 🔥 상태 초기화 (방 관련만)
        state.ResetRoomState();

        // 🔥 게임 초기화
        ResetGame();

        // 🔥 Undo UI 초기화
        if (undoUI != null)
            undoUI.ResetUI();

        // 🔥 배경 페이드 (로비 느낌)
        if (gameStartPanelUI != null)
            StartCoroutine(gameStartPanelUI.FadeBackground());

        if (roomUI != null)
        {
            // 준비 완료 버튼 초기화
            if (roomUI != null)
                roomUI.SetReadyButton(false);
            // 준비 완료 버튼 끄기
            roomUI.readyButton.gameObject.SetActive(false);

            // 🔥 Room UI 초기화
            roomUI.roomInfoText.text = "";
            roomUI.statusText.text = "";
            
            // 게임 버튼들 끄기
            inGameUI.SetActive(false);

            // 🔥 게임방 패널 비활성화
            roomUI.roomUIRoot.SetActive(false);
        }

        // 🔥 시작 패널 활성화
        if (gameStartPanelUI != null)
            gameStartPanelUI.startPanel.SetActive(true);

        // 🔥 UI 모드 강제 복귀
        SetPlayMode();

        // 🔥 Replay 상태 OFF
        isReplayMode = false;
    }

    public void ExitReplayMode()
    {
        Debug.Log("🎬 복기 종료");

        // 🔥 Replay 상태만 초기화
        state.ResetReplayState();

        // 🔥 보드 초기화
        ResetGame();

        // 🔥 UI 전환
        SetPlayMode();

        // 🔥 ReplayManager 정지
        if (replayManager != null)
            replayManager.StopReplay();

        isReplayMode = false;
    }

    public bool IsReplayMode()
    {
        return isReplayMode;
    }

    public void SetReplayMode()
    {
        isReplayMode = true;

        inGameUI.SetActive(false);
        inReplayUI.SetActive(true);
    }

    public void SetPlayMode()
    {
        isReplayMode = false;

        inGameUI.SetActive(true);
        inReplayUI.SetActive(false);
    }

    // 준비 완료 버튼
    public void OnClickReady()
    {
        if (NetworkController.Instance == null)
            return;

        // 🔥 이미 ready면 무시
        if (state.isReady)
            return;

        state.isReady = true;

        NetworkController.Instance.SendReady(true);

        if (roomUI != null)
            roomUI.SetReadyButton(true);

        systemManager.ShowMessage("준비 완료");
    }

    // 재시작 요청 버튼
    public void RequestRestart()
    {
        NetworkController.Instance.SendRestartRequest();

        replayUI.ShowRequestingUI();

        state.isRequester = true;         // 요청자
        state.isRestartPending = true;    // 돌 놓기 금지

        systemManager.ShowMessage("상대에게 요청 중...");
    }

    // 재시작 '요청 → 취소' 버튼
    public void CancelRestart()
    {
        NetworkController.Instance.SendRestartCancel();

        if (replayUI.replayRequestingPanel != null)
            replayUI.replayRequestingPanel.SetActive(false);

        if (replayUI.replayRequestPanel != null)
            replayUI.replayRequestPanel.SetActive(false);

        state.isRequester = false;         // 요청자 원복
        state.isRestartPending = false;    // 돌 놓기 금지

        systemManager.ShowMessage("재시작 요청을 취소했습니다");
    }

    private IEnumerator ShowReplayPanelAfterDelay()
    {
        yield return new WaitForSeconds(2f);

        if (replayUI != null)
            replayUI.ShowGameEndUI();
    }

    // 상대의 재시작 요청 승낙 버튼
    public void AcceptRestart()
    {
        NetworkController.Instance.SendRestartAccept();

        if (replayUI.replayRequestPanel != null)
            replayUI.replayRequestPanel.SetActive(false);
    }

    // 상대의 재시작 요청 거절 버튼
    public void RejectRestart()
    {
        NetworkController.Instance.SendRestartReject();

        if (replayUI.replayRequestPanel != null)
            replayUI.replayRequestPanel.SetActive(false);
    }

    public void OnClickUndoOptionYes()
    {
        NetworkController.Instance.SendUndoOption(true);
    }

    public void OnClickUndoOptionNo()
    {
        NetworkController.Instance.SendUndoOption(false);
    }

    public void OnClickUndoCancel()
    {
        NetworkController.Instance.SendUndoCancel();

        undoUI.HideRequestingPanel();

        state.isUndoPending = false;

        systemManager.ShowMessage("무르기 요청을 취소했습니다.");
    }

    public void OnClickUndoYes()
    {
        NetworkController.Instance.SendUndoVote(true);

        undoUI.HideVotePanel();
    }

    public void OnClickUndoNo()
    {
        NetworkController.Instance.SendUndoVote(false);

        undoUI.HideVotePanel();
    }

    public void ApplyUndoMovesPublic(
        UndoApplyMove move,
        int nextTurn,
        int turnTimeLimit)
    {

        // 🔥 1수만 제거
        RemoveLastMove();

        currentPlayer = nextTurn;
        state.currentPlayer = nextTurn;
        state.isMyTurn = (nextTurn == state.myPlayerId);

        // 🔥 핵심
        state.undoUsedThisTurn = false;
        state.isUndoPending = false;

        state.currentTurnTimeLimit = turnTimeLimit;

        hasTarget = false;

        if (currentMarker != null)
            currentMarker.SetActive(false);

        if (targetText != null)
            targetText.text = "";

        UpdateMoveText();
    }

    private void RemoveLastMove()
    {
        if (moveHistory.Count == 0)
            return;

        Move lastMove = moveHistory[moveHistory.Count - 1];
        moveHistory.RemoveAt(moveHistory.Count - 1);

        board[lastMove.x, lastMove.y] = 0;

        // 돌 2개 제거
        if (stoneHistory.Count > 0)
        {
            StoneUI stone = stoneHistory[stoneHistory.Count - 1];
            stoneHistory.RemoveAt(stoneHistory.Count - 1);

            if (stone != null)
                StartCoroutine(RemoveStoneWithAnimation(stone));
        }

        // 다시 2개 표시
        UpdateMoveNumberDisplay();
    }

    private IEnumerator RemoveStoneWithAnimation(StoneUI stone)
    {
        yield return StartCoroutine(stone.PlayRemoveAnimation());

        Destroy(stone.gameObject);
    }

    public void EnableMoveHistoryView()
    {
        showAllMoves = true;
        UpdateMoveNumberDisplay();
    }

    private void UpdateMoveNumberDisplay()
    {
        int count = stoneHistory.Count;

        if (count == 0) return;

        if (showAllMoves)
        {
            // 🔥 전체 표시
            for (int i = 0; i < count; i++)
            {
                stoneHistory[i].SetMoveNumber(i + 1);
            }
        }
        else
        {
            // 🔥 전체 숨김
            foreach (var stone in stoneHistory)
            {
                stone.HideMoveNumber();
            }

            // 🔥 마지막 2개만
            stoneHistory[count - 1].SetMoveNumber(count);

            if (count >= 2)
            {
                stoneHistory[count - 2].SetMoveNumber(count - 1);
            }
        }
    }

    private bool CanUseUndo()
    {
        if (state.undoUsedThisTurn) return false;
        if (state.isUndoPending) return false;

        int myIndex = state.myPlayerId - 1;

        if (myIndex >= 0 && myIndex < turnTimers.Length)
        {
            var timer = turnTimers[myIndex];

            if (timer != null && timer.IsActive())
            {
                if (timer.GetRemainingTime() <= 15f)
                    return false;
            }
        }

        return true;
    }

    private void UpdateUndoButton()
    {
        if (undoButton == null) return;

        undoButton.GetComponent<Button>().interactable = CanUseUndo();
    }

    /// <summary>
    /// 대국 복기 함수
    /// </summary>
    /// <param name="data"></param>
    public void StartReplayFromMatch(MatchDataPacket data)
    {
        replayManager.StartReplay(data);
    }

    public void PlaceReplayStonePublic(Vector2Int pos, int player)
    {
        PlaceReplayStone(pos, player);
    }

    private void PlaceReplayStone(Vector2Int pos, int player)
    {
        board[pos.x, pos.y] = player;

        moveHistory.Add(new Move(pos.x, pos.y, player));

        SpawnStone(pos, player);

        // 🔥 수 번호 갱신
        UpdateMoveNumberDisplay();
    }

    public void RemoveLastStoneReplay()
    {
        // 🔥 moveHistory 먼저 제거
        if (moveHistory.Count == 0)
            return;

        Move lastMove = moveHistory[moveHistory.Count - 1];
        moveHistory.RemoveAt(moveHistory.Count - 1);

        // 🔥 보드 되돌리기
        board[lastMove.x, lastMove.y] = 0;

        // 🔥 돌 제거 (애니메이션 없이 바로)
        if (stoneHistory.Count > 0)
        {
            StoneUI stone = stoneHistory[stoneHistory.Count - 1];
            stoneHistory.RemoveAt(stoneHistory.Count - 1);

            if (stone != null)
                Destroy(stone.gameObject); // 🔥 즉시 제거 (빠름)
        }
    }

    public void SetReplayModeState()
    {
        state.isGameStarted = true;
        state.isGameOver = false;
    }

    public void SetLastMatchId(string id)
    {
        lastMatchId = id;
    }

    public string GetLastMatchId()
    {
        return lastMatchId;
    }

    public void ShowMatchHistory(MatchListItemPacket[] matches)
    {
        matchHistoryUI.Open(new List<MatchListItemPacket>(matches));
    }

    public void RestoreReconnectedGamePublic(ReconnectSuccessPacket data)
    {
        RestoreReconnectedGame(data);
    }

    void RestoreReconnectedGame(ReconnectSuccessPacket data)
    {
        Debug.Log("🔁 게임 복구 시작");

        ResetGame();

        SetGameMode(GameMode.Online);
        SetPlayMode();
        SetGameplayUIPublic(true);

        state.isGameStarted = true;
        state.isGameOver = false;

        state.currentPlayer = data.turn;
        currentPlayer = data.turn;

        // 🔥 보드 복구
        if (data.moves != null)
        {
            foreach (var move in data.moves)
            {
                Vector2Int pos = new Vector2Int(move.x, move.y);

                board[pos.x, pos.y] = move.player;
                moveHistory.Add(new Move(move.x, move.y, move.player));
                SpawnStone(pos, move.player);
            }
        }

        EnableMoveHistoryView();
        UpdateMoveText();

        SetMyTurnPublic(data.turn == GetMyPlayerIdPublic());

        // 🔥 턴 UI 복구
        if (playerUI != null)
        {
            playerUI.UpdateTurn(data.turn);
        }

        // 🔥 타이머 복구
        for (int i = 0; i < turnTimers.Length; i++)
        {
            if (turnTimers[i] != null)
                turnTimers[i].StopTurn();
        }

        int turnIndex = data.turn - 1;

        if (turnIndex >= 0 && turnIndex < turnTimers.Length)
        {
            turnTimers[turnIndex].StartTurnWithServerTime(
                data.turnTimeLimit,
                data.turnStartTime
            );
        }

        hasTarget = false;

        if (currentMarker != null)
            currentMarker.SetActive(false);

        if (targetText != null)
            targetText.text = "";

        Debug.Log("🔁 게임 복구 완료");
    }
}
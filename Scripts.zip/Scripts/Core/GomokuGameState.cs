﻿using UnityEngine;

/// <summary>
/// 🔥 오목 게임의 현재 상태값만 저장하는 컨테이너
/// 로직은 넣지 않고, 데이터만 보관하는 용도
/// </summary>
[System.Serializable]
public class GomokuGameState
{
    // -----------------------------
    // 게임 진행 상태
    // -----------------------------
    public bool gameStarted = false;      // 전체 게임 모드 진입 여부
    public bool isGameStarted = false;    // 실제 온라인/AI 게임 시작 여부
    public bool isGameOver = false;

    // -----------------------------
    // 턴 / 플레이어
    // -----------------------------
    public int currentPlayer = 1;
    public bool isMyTurn = false;
    public int myPlayerId = 0;
    public string myUid = "";
    public string myNickname = "";
    public int myAvatarIndex = 0;

    // -----------------------------
    // Undo 상태
    // -----------------------------
    public bool undoEnabled = false;
    public bool isUndoPending = false;
    public float lastUndoTime = -999f;
    public int undoCount = 0;
    public bool undoUsedThisTurn = false;

    // -----------------------------
    // 네트워크 / 방 상태
    // -----------------------------
    public int currentRoomId = -1;
    public bool isReady = false;
    public bool isConnected = false;
    public bool hasPendingJoin = false;
    public int pendingRoomId = -1;

    // -----------------------------
    // 재시작 상태
    // -----------------------------
    public bool isRequester = false;
    public bool isRestartPending = false;

    // -----------------------------
    // 턴 타이머 관련
    // -----------------------------
    public int currentTurnTimeLimit = 60;
    public int myMissCount = 0;

    /// <summary>
    /// 🔥 게임판 초기화 시 같이 리셋할 값들
    /// </summary>
    public void ResetBoardRelatedState()
    {
        isGameOver = false;
        isGameStarted = false;

        currentPlayer = 1;

        undoCount = 0;
        undoUsedThisTurn = false;
        myMissCount = 0;

        isRequester = false;
        isRestartPending = false;
    }

    /// <summary>
    /// 🔥 방에서 나갈 때 상태 리셋
    /// </summary>
    public void ResetRoomState()
    {
        currentRoomId = -1;
        isGameStarted = false;
        isMyTurn = false;
        isReady = false;

        isRequester = false;
        isRestartPending = false;
        undoEnabled = false;

        myUid = "";
        myNickname = "";
        myAvatarIndex = 0;
    }

    /// <summary>
    /// 🔥 복기 종료 시 최소한으로 초기화
    /// </summary>
    public void ResetReplayState()
    {
        isGameOver = false;
        isGameStarted = false;

        currentPlayer = 1;

        undoUsedThisTurn = false;

        // 🔥 중요한 포인트
        // 방 정보는 건드리지 않는다
        // 네트워크 상태 유지
    }
}
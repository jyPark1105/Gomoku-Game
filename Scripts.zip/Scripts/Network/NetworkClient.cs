﻿using System;
using UnityEngine;
using NativeWebSocket;
using System.Collections.Generic;

/// <summary>
/// 🔥 서버와 통신 담당 클래스
/// </summary>
public class NetworkClient : MonoBehaviour
{
    private WebSocket websocket;

    // 🔥 받은 메시지 큐 (메인 스레드에서 처리)
    private Queue<string> messageQueue = new Queue<string>();

    // 방 입장을 바로 이어서 보내야 하니까 연결 직후 join 요청을 날릴 타이밍
    public Action OnConnected;

    /// <summary>
    /// 🔥 서버 연결
    /// </summary>
    public async void Connect(string url)
    {
        websocket = new WebSocket(url);

        // 🔥 연결 성공 시
        websocket.OnOpen += () =>
        {
            Debug.Log("✅ Connected to server");
            OnConnected?.Invoke();  // OnOpen 콜백을 NetworkClient에서 만들고 NetworkController로 올리기
        };

        // 🔥 메시지 수신 시 (⚠️ 별도 스레드)
        websocket.OnMessage += (bytes) =>
        {
            string msg = System.Text.Encoding.UTF8.GetString(bytes);

            // 🔥 바로 처리하면 위험 → 큐에 넣는다
            lock (messageQueue)
            {
                messageQueue.Enqueue(msg);
            }
        };

        // 🔥 연결 종료
        websocket.OnClose += (e) =>
        {
            Debug.Log("❌ Connection closed");
        };

        // 🔥 에러 발생
        websocket.OnError += (e) =>
        {
            Debug.LogError("❌ Error: " + e);
        };

        // 🔥 실제 연결 실행
        await websocket.Connect();
    }

    /// <summary>
    /// 🔥 서버로 메시지 보내기
    /// </summary>
    public async void Send(string message)
    {
        if (websocket.State == WebSocketState.Open)
        {
            await websocket.SendText(message);
        }
    }

    /// <summary>
    /// 🔥 매 프레임 호출 (Unity Update에서 실행)
    /// </summary>
    public void ProcessMessages(Action<string> onMessage)
    {
        lock (messageQueue)
        {
            while (messageQueue.Count > 0)
            {
                string msg = messageQueue.Dequeue();
                onMessage?.Invoke(msg);
            }
        }
    }

    private void Update()
    {
#if !UNITY_WEBGL || UNITY_EDITOR
        websocket?.DispatchMessageQueue();
#endif
    }
}
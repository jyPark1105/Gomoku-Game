﻿using UnityEngine;
using System;

/// <summary>
/// 🔥 네트워크 전담 클래스
/// </summary>
public class NetworkController : MonoBehaviour
{
    public static NetworkController Instance;

    NetworkClient client;

    public Action<string> OnMessageReceived;
    public Action OnConnected;

    bool isConnecting = false;

    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        DontDestroyOnLoad(gameObject); // 🔥 핵심
    }

    public void Connect()
    {
        if (isConnecting) return;

        isConnecting = true;

        Debug.Log("🔥 Connect 호출됨");

        client = gameObject.AddComponent<NetworkClient>();

        client.OnConnected += () =>
        {
            OnConnected?.Invoke();
        };

        // Local Server
        // client.Connect("ws://localhost:3000");

        // AWS EC2 인스턴스 → gomoku-server 실행 → Connect 함수 인자: "퍼블릭 IPv4 주소 IP 값" 입력
        // Elastic IP(탄력적 IP) 할당 후 EC2 Instance와 연결 → Instance 재시작하더라도 항상 "고정된 IP" 사용 가능
        // 인스턴스 재생성 시 항상 Key Pair 권한 올바르게 설정 후
        // → 인스턴스의 생성 시 Key Pair와 (내용이) 항상 동일해야 함
        client.Connect("ws://43.202.206.137:3000");
    }

    void Update()
    {
        if (client != null)
        {
            client.ProcessMessages((msg) =>
            {
                OnMessageReceived?.Invoke(msg);
            });
        }
    }

    public void Send(string json)
    {
        Debug.Log("📤 보내는 데이터: " + json);
        client.Send(json);
    }

    public void SendCheckNickname(string nickname)
    {
        var packet = new CheckNicknamePacket
        {
            type = "CHECK_NICKNAME",
            nickname = nickname
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void JoinRoom(int roomId, int turnTime)
    {
        JoinRoomPacket packet = new JoinRoomPacket
        {
            type = "JOIN_ROOM",
            roomId = roomId,
            turnTime = turnTime
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void LeaveRoom()
    {
        var packet = new BasePacket
        {
            type = "LEAVE"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendCancelNickname(string nickname)
    {
        var packet = new CancelNicknamePacket
        {
            type = "CANCEL_NICKNAME_RESERVE",
            nickname = nickname
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendRequestNicknameSuggest()
    {
        var packet = new NicknameSuggestRequestPacket
        {
            type = "REQUEST_NICKNAME_SUGGEST"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendProfile(string nickname, int avatarIndex)
    {
        var packet = new ProfilePacket
        {
            type = "SET_PROFILE",
            nickname = nickname,
            avatarIndex = avatarIndex
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendReady(bool isReady)
    {
        var packet = new ReadyRequestPacket
        {
            type = isReady ? "READY" : "READY_CANCEL"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendReplay()
    {
        var packet = new BasePacket
        {
            type = "REPLAY"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendRestartRequest()
    {
        var packet = new BasePacket
        {
            type = "RESTART_REQUEST"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendRestartCancel()
    {
        var packet = new BasePacket
        {
            type = "RESTART_CANCEL"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendRestartAccept()
    {
        var packet = new BasePacket
        {
            type = "RESTART_ACCEPT"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendRestartReject()
    {
        var packet = new BasePacket
        {
            type = "RESTART_REJECT"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void RequestRoomList(int turnTime)
    {
        RequestRoomListPacket packet = new RequestRoomListPacket
        {
            type = "REQUEST_ROOM_LIST",
            turnTime = turnTime
        };

        string json = JsonUtility.ToJson(packet);

        Debug.Log("📤 보내는 데이터: " + json);

        Send(json);
    }

    public void SendUndoOption(bool agree)
    {
        UndoOptionVotePacket packet = new UndoOptionVotePacket
        {
            type = "UNDO_OPTION_VOTE",
            agree = agree
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendUndoVote(bool agree)
    {
        UndoVotePacket packet = new UndoVotePacket
        {
            type = "UNDO_VOTE",
            agree = agree
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendUndoCancel()
    {
        UndoCancelPacket packet = new UndoCancelPacket
        {
            type = "UNDO_CANCEL"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendUndoRequest()
    {
        UndoRequestPacket packet = new UndoRequestPacket
        {
            type = "UNDO_REQUEST"
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void SendChat(string message)
    {
        ChatPacket packet = new ChatPacket
        {
            type = "CHAT",
            message = message
        };

        string json = JsonUtility.ToJson(packet);
        Send(json);
    }

    public void SendPickColor(int index)
    {
        var packet = new PickColorPacket
        {
            type = "PICK_COLOR",
            slotIndex = index
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void RequestMatchData(string matchId)
    {
        var packet = new GetMatchPacket
        {
            type = "GET_MATCH",
            matchId = matchId
        };

        Send(JsonUtility.ToJson(packet));
    }

    public void RequestMatchList()
    {
        var packet = new BasePacket
        {
            type = "GET_MATCH_LIST"
        };

        Send(JsonUtility.ToJson(packet));
    }

}

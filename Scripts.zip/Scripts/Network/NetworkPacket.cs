﻿using System;

[Serializable]
public class BasePacket
{
    public string type;
}

[Serializable]
public class CheckNicknamePacket
{
    public string type;
    public string nickname;
}

[Serializable]
public class CancelNicknamePacket
{
    public string type;
    public string nickname;
}

[Serializable]
public class NicknameSuggestRequestPacket   // Send
{
    public string type;
}

[Serializable]
public class NicknameSuggestPacket  // Receive
{
    public string type;
    public string name; // 🔥 list → name
}

// 내 프로필 (방 상관 없음)
[Serializable]
public class ProfilePacket
{
    public string type;
    public string uid;
    public string nickname;
    public int avatarIndex;

    public int win;
    public int lose;
    public int tier;
}

// 방 내부 플레이어 리스트용 패킷
[Serializable]
public class PlayerProfilePacket
{
    public int playerId;
    public string uid;
    public string nickname;
    public int avatarIndex;

    public int win;
    public int lose;
    public int tier;
}

[Serializable]
public class RankingPacket
{
    public string type;
    public RankingUser[] users;
}

[Serializable]
public class RankingUser
{
    public string uid;
    public string nickname;
    public int avatarIndex;
    public int win;
    public int lose;
    public int tier;
}

[Serializable]
public class RoomInfoPacket
{
    public string type;
    public int roomId;
    public int playerCount;
    public int maxPlayers;
}

[Serializable]
public class RoomListPacket
{
    public string type;
    public int turnTime;
    public RoomInfoPacket[] rooms;
}

[Serializable]
public class RequestRoomListPacket
{
    public string type;
    public int turnTime;
}

[Serializable]
public class StartPacket
{
    public string type;
    public int turn;
    public int playerId;
    public string uid;
    public string nickname;
    public int avatarIndex;
    public int turnTimeLimit;
    public PlayerProfilePacket[] players;
    public int blackPlayerId;
}

[Serializable]
public class UndoOptionVotePacket
{
    public string type;
    public int playerId;
    public bool agree;
}

[Serializable]
public class UndoVoteStartPacket
{
    public string type;
    public int requester;
    public double startTime;
}

[Serializable]
public class UndoVotePacket
{
    public string type;
    public bool agree;
}

[Serializable]
public class UndoResultPacket
{
    public string type;
    public bool enabled;
}

[Serializable]
public class UndoRequestPacket
{
    public string type;
}

[Serializable]
public class UndoCancelPacket
{
    public string type;
}

[Serializable]
public class ColorPickStartPacket
{
    public string type;
    public float timeLimit;     // 10초
    public double startTime;    // 서버 시간
}

[Serializable]
public class UndoApplyMove
{
    public int x;
    public int y;
    public int player;
}

[Serializable]
public class UndoApplyPacket
{
    public string type;
    public UndoApplyMove move;
    public int nextTurn;
    public int turnTimeLimit;
}

[Serializable]
public class PlayerListPacket
{
    public string type;
    public PlayerProfilePacket[] players;
}

[Serializable]
public class JoinRoomPacket
{
    public string type;
    public int roomId;
    public int turnTime;
}

[Serializable]
public class ReadyRequestPacket
{
    public string type;
}

[Serializable]
public class JoinedPacket
{
    public string type;
    public int playerId;
    public int roomId;
}

[Serializable]
public class ReadyPacket
{
    public string type;
    public int playerId;
    public bool isReady;
}

[Serializable]
public class RoomFullPacket
{
    public string type;
    public int roomId;
}

[Serializable]
public class CountdownPacket
{
    public string type;
    public int seconds;
}

[Serializable]
public class PickColorPacket
{
    public string type;
    public int slotIndex;
}

[System.Serializable]
public class SlotLockedPacket
{
    public string type;
    public int slotIndex;
    public int playerId;
}

[Serializable]
public class ColorPickUpdatePacket
{
    public string type;
    public int slotIndex;
    public int playerId;
    public int value;   // 서버에서 결정: 플레이어가 뽑은 랜덤 자연수 값 (1 ~ 9)
}

[Serializable]
public class MovePacket
{
    public string type;
    public int x;
    public int y;
    public int player;
}

[Serializable]
public class TurnPacket
{
    public string type;
    public int turn;
    public double turnStartTime;
}

[Serializable]
public class MissCountPacket
{
    public string type;
    public int playerId;
    public int missCount;
}

[Serializable]
public class ChatPacket
{
    public string type;
    public string message;
}

[Serializable]
public class ChatBroadcastPacket
{
    public string type;
    public int playerId;
    public string message;
    public long timestamp;
}

[Serializable]
public class ReconnectMovePacket
{
    public int x;
    public int y;
    public int player;
}

[Serializable]
public class ReconnectSuccessPacket
{
    public string type;
    public int turn;
    public int turnTimeLimit;
    public double turnStartTime;

    public PlayerProfilePacket[] players;
    public ReconnectMovePacket[] moves;

    // 🔥 핵심 추가 (이게 진짜 중요)
    public GameStatePacket gameState;
}

[Serializable]
public class OpponentDisconnectedPacket
{
    public string type;
    public int playerId;
    public string reason;
    public int timeout;
    public double startTime;

    public int disconnectCount;
}

[Serializable]
public class OpponentReconnectedPacket
{
    public string type;
    public int playerId;
}

[Serializable]
public class GameStatePacket
{
    public string phase;
    public UndoState undo;
    public RestartState restart;
    public GameResultState game;
}

[Serializable]
public class UndoState
{
    public bool isVoting;
    public int requester;
    public double startTime;
}

[Serializable]
public class RestartState
{
    public bool isPending;
    public int requester;
}

[Serializable]
public class GameResultState
{
    public bool isOver;
    public int winner;
}

[Serializable]
public class WinPoint
{
    public int x;
    public int y;
}

[Serializable]
public class EndPacket
{
    public string type;
    public int winner;
    public string reason;
    public WinPoint[] winLine;
    public string matchId;
}

[Serializable]
public class TypingPacket
{
    public string type;
}

[Serializable]
public class TypingBroadcastPacket
{
    public string type;
    public int playerId;
}

[Serializable]
public class BlockPacket
{
    public string type;
    public string message;
}

[Serializable]
public class PermaBlockPacket
{
    public string type;
    public string message;
}

[Serializable]
public class ReplayMovePacket
{
    public int x;
    public int y;
    public int player;
}

[Serializable]
public class ReplayPlayerPacket
{
    public int playerId;
    public string uid;
    public string nickname;
    public int avatarIndex;
}

[Serializable]
public class MatchDataPacket
{
    public string type;
    public string matchId;
    public ReplayPlayerPacket[] players;
    public ReplayMovePacket[] moves;
    public int winner;
    public WinPoint[] winLine;
    public long startedAt;
    public long endedAt;
    public int turnTime;
    public int roomId;
}

[Serializable]
public class MatchNotFoundPacket
{
    public string type;
}

[Serializable]
public class GetMatchPacket
{
    public string type;
    public string matchId;
}

[Serializable]
public class MatchListItemPacket
{
    public string matchId;
    public ReplayPlayerPacket[] players;
    public int winner;
    public long startedAt;
    public long endedAt;
    public int turnTime;
    public int roomId;
    public int moveCount;
}

[Serializable]
public class MatchListPacket
{
    public string type;
    public MatchListItemPacket[] matches;
}
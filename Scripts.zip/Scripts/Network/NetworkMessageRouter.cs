﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// 🔥 네트워크 메시지 분배 전담
/// GomokuManager의 OnReceiveMessage가 너무 커지는 문제를 해결하기 위한 라우터
/// </summary>
public class NetworkMessageRouter
{
    private readonly LobbyUIManager lobbyUI;
    private readonly GomokuManager gomoku;
    private readonly GomokuGameState state;
    private readonly GameStartUI gameStartUI;
    private readonly RoomUIManager roomUI;
    private readonly PlayerUIManager playerUI;
    private readonly ReplayUI replayUI;
    private readonly UndoUIManager undoUI;
    private readonly SystemManager systemManager;
    private readonly TurnTimerUI[] turnTimers;
    private readonly WinReasonUI winReasonUI;
    private readonly ChatUIManager chatUI;
    private readonly MatchHistoryUI matchHistoryUI;
    private readonly RankingUI rankingUI;
    private readonly ColorPickUI colorPickUI;

    public GameStatePacket gameState;

    public NetworkMessageRouter(
        LobbyUIManager lobbyUI,
        GomokuManager gomoku,
        GomokuGameState state,
        GameStartUI gameStartUI,
        RoomUIManager roomUI,
        PlayerUIManager playerUI,
        ReplayUI replayUI,
        UndoUIManager undoUI,
        SystemManager systemManager,
        TurnTimerUI[] turnTimers,
        WinReasonUI winReasonUI,
        ChatUIManager chatUI,
        MatchHistoryUI matchHistoryUI,
        RankingUI rankingUI,
        ColorPickUI colorPickUI)
    {
        this.lobbyUI = lobbyUI;
        this.gomoku = gomoku;
        this.state = state;
        this.gameStartUI = gameStartUI;
        this.roomUI = roomUI;
        this.playerUI = playerUI;
        this.replayUI = replayUI;
        this.undoUI = undoUI;
        this.systemManager = systemManager;
        this.turnTimers = turnTimers;
        this.winReasonUI = winReasonUI;
        this.chatUI = chatUI;
        this.matchHistoryUI = matchHistoryUI;
        this.rankingUI = rankingUI;
        this.colorPickUI = colorPickUI;
    }

    public void Handle(string msg)
    {
        Debug.Log("받은 메시지: " + msg);

        BasePacket baseData = JsonUtility.FromJson<BasePacket>(msg);

        if (baseData == null || string.IsNullOrEmpty(baseData.type))
        {
            Debug.LogWarning("❌ Packet type 파싱 실패");
            return;
        }

        Debug.Log("📦 Packet Type: " + baseData.type);

        switch (baseData.type)
        {
            case "NICKNAME_AVAILABLE":
                HandleNicknameAvailable();
                break;

            case "NICKNAME_DUPLICATE":
                HandleNicknameDuplicate();
                break;

            case "NICKNAME_INVALID":
                HandleNicknameInvalid();
                break;

            case "NICKNAME_SUGGEST":
                HandleNicknameSuggest(msg);
                break;

            case "MY_PROFILE":
                HandleProfile(msg);
                break;

            case "RANKING":
                HandleRanking(msg);
                break;

            case "ROOM_LIST":
                HandleRoomList(msg);
                break;

            case "PLAYER_LIST":
                HandlePlayerList(msg);
                break;

            case "JOINED":
                HandleJoined(msg);
                break;

            case "WAIT":
                HandleWait();
                break;

            case "ROOM_FULL":
                HandleRoomFull();
                break;

            case "READY":
                HandleReady(msg);
                break;

            case "UNDO_OPTION_START":
                undoUI.ShowOptionPanel();
                break;

            case "UNDO_OPTION_RESULT":
                HandleUndoOptionResult(msg);
                break;

            case "UNDO_VOTE_START":
                HandleUndoVoteStart(msg);
                break;

            case "UNDO_VOTE":
                HandleUndoOptionVote(msg);
                break;

            case "UNDO_RESULT":
                HandleUndoResult(msg);
                break;

            case "UNDO_CANCEL":
                HandleUndoCancel();
                break;

            case "UNDO_APPLY":
                HandleUndoApply(msg);
                break;

            case "COUNTDOWN":
                HandleCountdown(msg);
                break;

            case "COLOR_PICK_START":
                HandleColorPickStart(msg);
                break;

            case "SLOT_LOCKED":
                HandleSlotLocked(msg);
                break;

            case "COLOR_PICK_UPDATE":
                HandleColorPickUpdate(msg);
                break;

            case "START":
                HandleStart(msg);
                break;

            case "TURN":
                HandleTurn(msg);
                break;

            case "MISS_COUNT":
                HandleMissCount(msg);
                break;

            case "CHAT":
                HandleChat(msg);
                break;

            case "TYPING_START":
                HandleTyping(msg, true);
                break;

            case "TYPING_STOP":
                HandleTyping(msg, false);
                break;

            case "BLOCK":
                HandleBlock(msg);
                break;

            case "PERMA_BLOCK":
                HandlePermaBlock(msg);
                break;

            case "RECONNECT_SUCCESS":
                HandleReconnectSuccess(msg);
                break;

            case "OPPONENT_DISCONNECTED":
                HandleOpponentDisconnected(msg);
                break;

            case "OPPONENT_RECONNECTED":
                HandleOpponentReconnected(msg);
                break;

            case "MOVE":
                HandleMove(msg);
                break;

            case "END":
                HandleEnd(msg);
                break;

            case "REPLAY":
                HandleReplay(msg);
                break;

            case "RESTART_REQUEST":
                HandleRestartRequest();
                break;

            case "RESTART_CANCEL":
                HandleRestartCancel();
                break;

            case "RESTART_ACCEPT":
                HandleRestartAccept();
                break;

            case "RESTART_REJECT":
                HandleRestartReject();
                break;

            case "MATCH_DATA":
                HandleMatchData(msg);
                break;

            case "MATCH_LIST":
                HandleMatchList(msg);
                break;

            case "MATCH_NOT_FOUND":
                HandleMatchNotFound();
                break;
        }
    }

    void HandleProfile(string msg)
    {
        ProfilePacket data = JsonUtility.FromJson<ProfilePacket>(msg);

        Debug.Log($"프로필 수신: {data.nickname} {data.win}/{data.lose} tier:{data.tier}");

        if (PlayerProfile.Instance != null)
        {
            PlayerProfile.Instance.SetProfile(
                data.uid,
                data.nickname,
                data.avatarIndex,
                data.win,
                data.lose,
                data.tier
            );
        }

        if (PlayerProfileUIManager.Instance != null)
        {
            PlayerProfileUIManager.Instance.RefreshUI();
        }

        Debug.Log("✅ MY_PROFILE 적용 완료");
    }

    void HandleNicknameDuplicate()
    {
        // 🔥 다시 입력 가능하게
        if (lobbyUI != null && lobbyUI.nameUI != null)
        {
            lobbyUI.nameUI.nameWarnText.text = "이미 사용 중인 닉네임입니다.";
            lobbyUI.nameUI.ResetConfirmState();
        }
    }

    void HandleNicknameInvalid()
    {
        if (lobbyUI != null && lobbyUI.nameUI != null)
        {
            lobbyUI.nameUI.nameWarnText.text = "사용할 수 없는 닉네임입니다.";
            lobbyUI.nameUI.ResetConfirmState();
        }
    }

    void HandleNicknameSuggest(string msg)
    {
        NicknameSuggestPacket data = JsonUtility.FromJson<NicknameSuggestPacket>(msg);

        Debug.Log("추천 닉네임 받음: " + data.name);

        var nameUI = lobbyUI.nameUI;

        nameUI.inputField.text = data.name;
        nameUI.currentInputName = data.name;

        // ❌ 추천 상태 제거
        nameUI.isSuggestedName = false;

        // 예약 닉네임 저장
        nameUI.reservedNickname = data.name;

        // 🔥 경고 메시지 초기화
        nameUI.nameWarnText.text = "";
    }

    /// <summary>
    /// 사용 가능한 닉네임일 때
    /// </summary>
    void HandleNicknameAvailable()
    {
        if (lobbyUI != null)
            lobbyUI.ShowConfirmNicknamePanel();
    }

    void HandleRanking(string msg)
    {
        RankingPacket data = JsonUtility.FromJson<RankingPacket>(msg);

        Debug.Log($"📊 RANKING 수신: {data.users.Length}");

        for (int i = 0; i < data.users.Length; i++)
        {
            var u = data.users[i];
            Debug.Log($"[{i}] {u.nickname} / {u.win}승 {u.lose}패 / tier:{u.tier}");
        }

        // 🔥 RankingUI로 전달
        if (rankingUI != null)
        {
            rankingUI.SetRanking(data.users);
        }
        else
        {
            Debug.LogWarning("❌ RankingUI 연결 안 됨");
        }
    }

    void HandleRoomList(string msg)
    {
        RoomListPacket data = JsonUtility.FromJson<RoomListPacket>(msg);

        bool isValid = data.turnTime == gameStartUI.selectedTurnTime;

        if (isValid)
        {
            gameStartUI.UpdateRoomList(data.rooms);
        }

        gameStartUI.OnRoomInfoReceived();
    }

    void HandlePlayerList(string msg)
    {
        PlayerListPacket data = JsonUtility.FromJson<PlayerListPacket>(msg);

        // 🔥 전체 초기화
        playerUI.SetName(1, "");
        playerUI.SetName(2, "");

        playerUI.ShowJoinPanel(1, true);
        playerUI.ShowJoinPanel(2, true);

        foreach (var p in data.players)
        {
            // Room 내부 플레이어 UI 표시
            playerUI.SetName(p.playerId, p.nickname);
            playerUI.SetAvatar(p.playerId, p.avatarIndex);
            playerUI.SetWinLose(p.playerId, p.win, p.lose);
            playerUI.SetTier(p.playerId, p.tier);

            playerUI.ShowJoinPanel(p.playerId, false);

            chatUI.SetPlayerInfo(p.playerId, p.nickname, p.avatarIndex);
        }
    }

    void HandleJoined(string msg)
    {
        JoinedPacket data = JsonUtility.FromJson<JoinedPacket>(msg);

        state.currentRoomId = data.roomId;
        state.myPlayerId = data.playerId;

        gomoku.EnterRoomState(data.roomId);

        systemManager.ShowMessage($"Room {data.roomId} 입장 완료");

        playerUI.SetState(data.playerId, "입장 중");
    }

    void HandleWait()
    {
        systemManager.ShowMessage("상대 기다리는 중...");

        if (state.myPlayerId != 0)
            playerUI.SetState(state.myPlayerId, "대기 중");

        int other = gomoku.GetOtherIdPublic(state.myPlayerId);
        if (other != 0)
        {
            playerUI.SetState(other, "입장 중");
            playerUI.ShowJoinPanel(other, true);
        }
    }

    void HandleRoomFull()
    {
        systemManager.ShowMessage("상대가 입장했습니다. 준비하세요.");
        roomUI.EnableReadyButton();
    }

    void HandleReady(string msg)
    {
        ReadyPacket data = JsonUtility.FromJson<ReadyPacket>(msg);

        playerUI.SetReadyState(data.playerId, data.isReady);
        playerUI.SetState(data.playerId, data.isReady ? "준비 완료" : "대기 중");
    }

    void HandleUndoVoteStart(string msg)
    {
        UndoVoteStartPacket data = JsonUtility.FromJson<UndoVoteStartPacket>(msg);

        int myId = gomoku.GetMyPlayerIdPublic();

        // 요청자인가?
        if (data.requester == myId)
        {
            // 🔥 요청자
            undoUI.ShowRequestingPanel(data.startTime);
        }
        else
        {
            // 🔥 상대가 요청
            undoUI.ShowVotePanel(data.startTime);
            systemManager.ShowMessage("상대가 무르기를 요청했습니다.");
        }
    }

    void HandleUndoOptionVote(string msg)
    {
        UndoOptionVotePacket data = JsonUtility.FromJson<UndoOptionVotePacket>(msg);

        // 🔥 UI 반영
        undoUI.UpdateOptionState(data.playerId, data.agree);
    }

    void HandleUndoResult(string msg)
    {
        UndoResultPacket data = JsonUtility.FromJson<UndoResultPacket>(msg);

        state.undoEnabled = data.enabled;
        state.isUndoPending = false;
        state.undoUsedThisTurn = false;

        undoUI.HideVotePanel();
        undoUI.HideRequestingPanel();

        undoUI.ShowResult(data.enabled);
    }

    void HandleUndoApply(string msg)
    {
        UndoApplyPacket data = JsonUtility.FromJson<UndoApplyPacket>(msg);

        // 🔥 이거 추가해야 안전
        undoUI.HideVotePanel();
        undoUI.HideRequestingPanel();

        state.isUndoPending = false;
        state.undoUsedThisTurn = false;

        gomoku.ApplyUndoMovesPublic(
            data.move,
            data.nextTurn,
            data.turnTimeLimit
        );
    }

    void HandleCountdown(string msg)
    {
        CountdownPacket data = JsonUtility.FromJson<CountdownPacket>(msg);

        roomUI.ShowCountdown(data.seconds);
    }

    void HandleColorPickStart(string msg)
    {
        ColorPickStartPacket data = JsonUtility.FromJson<ColorPickStartPacket>(msg);

        Debug.Log("🔥 COLOR_PICK_START 수신: " + msg);

        colorPickUI.Show();

        Debug.Log($"⏱ timeLimit={data.timeLimit}, startTime={data.startTime}");

        colorPickUI.StartColorPickTimer(data.timeLimit, data.startTime);
    }

    void HandleSlotLocked(string msg)
    {
        SlotLockedPacket data = JsonUtility.FromJson<SlotLockedPacket>(msg);

        colorPickUI.LockSlot(data.slotIndex, data.playerId);
    }

    void HandleColorPickUpdate(string msg)
    {
        ColorPickUpdatePacket data = JsonUtility.FromJson<ColorPickUpdatePacket>(msg);

        if (colorPickUI != null)
        {
            colorPickUI.ApplySelection(
                data.slotIndex,
                data.playerId,
                state.myPlayerId,
                data.value
            );
        }
    }

    /// <summary>
    /// 게임 시작
    /// </summary>
    /// <param name="msg"></param>
    void HandleStart(string msg)
    {
        StartPacket data = JsonUtility.FromJson<StartPacket>(msg);

        state.isGameStarted = true;
        state.isGameOver = false;
        state.myPlayerId = data.playerId;
        state.isMyTurn = (data.turn == state.myPlayerId);
        state.currentTurnTimeLimit = data.turnTimeLimit;

        playerUI.SetStoneType(data.blackPlayerId);

        chatUI.myPlayerId = data.playerId;

        for (int i = 0; i < turnTimers.Length; i++)
        {
            if (turnTimers[i] != null)
            {
                turnTimers[i].Init(state.currentTurnTimeLimit);
                turnTimers[i].SetMissCount(0);
                turnTimers[i].HideTimer();
            }
        }

        int startIndex = data.turn - 1;
        if (startIndex >= 0 && startIndex < turnTimers.Length)
        {
            turnTimers[startIndex].StartTurn(state.currentTurnTimeLimit);
        }

        if (roomUI.countdownCoroutine != null)
        {
            roomUI.StopCoroutine(roomUI.countdownCoroutine);
            roomUI.countdownCoroutine = null;
        }

        roomUI.readyButton.gameObject.SetActive(false);

        // 모든 통제된 방 내부 UI 켜기
        gomoku.SetGameplayUIPublic(true);

        playerUI.Init(state.myPlayerId);
        playerUI.UpdateTurn(data.turn);
        playerUI.SetState(1, "");
        playerUI.SetState(2, "");

        gomoku.HideReplayPanelsPublic();

        state.isRequester = false;
        state.isRestartPending = false;

        winReasonUI.Init(state.myPlayerId);

        lobbyUI.EnterInGame();
    }

    void HandleTurn(string msg)
    {
        if (state.isGameOver)
            return;

        TurnPacket data = JsonUtility.FromJson<TurnPacket>(msg);

        if (state.currentTurnTimeLimit <= 0)
        {
            Debug.LogError("❌ turnTimeLimit 아직 안 들어옴");
            return;
        }

        state.isMyTurn = (data.turn == state.myPlayerId);
        playerUI.UpdateTurn(data.turn);

        for (int i = 0; i < turnTimers.Length; i++)
        {
            if (turnTimers[i] != null)
                turnTimers[i].HideTimer();
        }

        int index = data.turn - 1;
        if (index >= 0 && index < turnTimers.Length)
        {
            turnTimers[index].StartTurnWithServerTime(
                state.currentTurnTimeLimit,
                data.turnStartTime
            );
        }
    }

    void HandleMissCount(string msg)
    {
        MissCountPacket data = JsonUtility.FromJson<MissCountPacket>(msg);

        int index = data.playerId - 1;
        if (index >= 0 && index < turnTimers.Length)
        {
            turnTimers[index].SetMissCount(data.missCount);
        }
    }

    void HandleChat(string msg)
    {
        ChatBroadcastPacket data = JsonUtility.FromJson<ChatBroadcastPacket>(msg);

        chatUI.AddMessage(
            data.playerId, 
            data.message, 
            data.timestamp
        );
    }

    void HandleTyping(string msg, bool isTyping)
    {
        TypingBroadcastPacket data = JsonUtility.FromJson<TypingBroadcastPacket>(msg);

        chatUI.SetTypingState(data.playerId, isTyping);
    }

    void HandleBlock(string msg)
    {
        BlockPacket data = JsonUtility.FromJson<BlockPacket>(msg);

        chatUI.OnBlock(data.message);
    }

    void HandlePermaBlock(string msg)
    {
        PermaBlockPacket data = JsonUtility.FromJson<PermaBlockPacket>(msg);

        chatUI.OnPermaBlock(data.message);
    }

    void HandleReconnectSuccess(string msg)
    {
        ReconnectSuccessPacket data = JsonUtility.FromJson<ReconnectSuccessPacket>(msg);

        Debug.Log("🔁 RECONNECT_SUCCESS 수신");
        Debug.Log("복구할 수 수: " + (data.moves != null ? data.moves.Length : 0));

        state.isConnected = true;
        state.isGameStarted = true;
        state.isGameOver = false;
        state.currentTurnTimeLimit = data.turnTimeLimit;
        state.isMyTurn = (data.turn == state.myPlayerId);

        // =========================
        // 🔥 1. 플레이어 UI 복구
        // =========================
        if (data.players != null)
        {
            playerUI.Init(state.myPlayerId);

            foreach (var p in data.players)
            {
                playerUI.SetName(p.playerId, p.nickname);
                playerUI.SetAvatar(p.playerId, p.avatarIndex);
                playerUI.SetName(p.playerId, p.nickname);
                playerUI.SetAvatar(p.playerId, p.avatarIndex);

                playerUI.ShowJoinPanel(p.playerId, false);

                chatUI.SetPlayerInfo(p.playerId, p.nickname, p.avatarIndex);
            }
        }

        playerUI.UpdateTurn(data.turn);
        playerUI.SetState(1, "");
        playerUI.SetState(2, "");

        // =========================
        // 🔥 2. 게임 상태 복구
        // =========================
        gomoku.RestoreReconnectedGamePublic(data);

        // =========================
        // 🔥 3. 상태 기반 UI 복구 (🔥 핵심)
        // =========================
        var gameState = data.gameState;

        if (gameState != null)
        {
            switch (gameState.phase)
            {
                case "PLAYING":
                    // 아무것도 안 해도 됨
                    break;

                case "UNDO_VOTING":
                    {
                        int myId = state.myPlayerId;

                        if (gameState.undo.requester == myId)
                        {
                            undoUI.ShowRequestingPanel(gameState.undo.startTime);
                        }
                        else
                        {
                            undoUI.ShowVotePanel(gameState.undo.startTime);
                            systemManager.ShowMessage("상대가 무르기를 요청했습니다.");
                        }

                        state.isUndoPending = true;
                        break;
                    }

                case "RESTART_PENDING":
                    {
                        int myId = state.myPlayerId;

                        if (gameState.restart.requester == myId)
                        {
                            gomoku.ShowReplayRequestingPanelPublic(true);
                        }
                        else
                        {
                            gomoku.ShowReplayRequestPanelPublic(true);
                            systemManager.ShowMessage("상대가 재시작을 요청했습니다.");
                        }

                        state.isRestartPending = true;
                        break;
                    }

                case "GAME_OVER":
                    {
                        Debug.Log("🔚 이미 종료된 게임 상태로 복구");

                        // 이미 END 패킷에서 처리되지만
                        // reconnect 시 안전하게 한 번 더 처리
                        gomoku.OnGameEndPublic(
                            gameState.game.winner,
                            "RECONNECT"
                        );

                        break;
                    }
            }
        }

        // =========================
        // 🔥 4. 기존 Undo UI 정리 (혹시 남아있으면)
        // =========================
        if (gameState == null || gameState.phase != "UNDO_VOTING")
        {
            undoUI.HideVotePanel();
            undoUI.HideRequestingPanel();
            state.isUndoPending = false;
        }

        systemManager.ShowMessage("대국에 재접속했습니다.");
    }

    void HandleOpponentDisconnected(string msg)
    {
        OpponentDisconnectedPacket data = JsonUtility.FromJson<OpponentDisconnectedPacket>(msg);

        // 턴 타이머 정지
        for (int i = 0; i < turnTimers.Length; i++)
        {
            if (turnTimers[i] != null)
                turnTimers[i].StopTurn();
        }

        int otherId = data.playerId;
        playerUI.SetState(otherId, "재접속 대기 중");

        systemManager.ShowMessage("상대 복귀를 기다리는 중입니다.");

        // 🔥 핵심 추가
        if (roomUI != null)
        {
            // 서버에서 count도 내려줘야 함
            roomUI.ShowOpponentDisconnected(
                data.disconnectCount,   // 서버에서 추가 필요
                GetReasonText(data.reason)
            );

            // 30초 타이머 UI
            roomUI.StartDisconnectTimer(
                data.timeout,
                data.startTime
            );
        }
    }

    void HandleOpponentReconnected(string msg)
    {
        OpponentReconnectedPacket data = JsonUtility.FromJson<OpponentReconnectedPacket>(msg);

        playerUI.SetState(data.playerId, "");
        systemManager.ShowMessage("상대가 복귀했습니다.");

        // 🔥 패널 닫기
        if (roomUI != null)
        {
            roomUI.HideOpponentDisconnected();
            roomUI.StopDisconnectTimer();
        }

        // 🔥 핵심 1: 입력 다시 풀기
        if (gomoku != null)
            gomoku.SetGameplayUIPublic(true);

        // 🔥 핵심 2: 상태 초기화
        state.isUndoPending = false;
    }

    /// <summary>
    /// 상대방 접속 끊김 횟수 → 상대방 연결 재시도 1/2 ...로 바꾸기
    /// </summary>
    /// <param name="reason"></param>
    /// <returns></returns>
    string GetReasonText(string reason)
    {
        switch (reason)
        {
            case "NETWORK":
                return "네트워크 불안정";  // text 줄이기
            case "BACKGROUND":
                return "연결 지연";
            case "TURN_STALL":
                return "응답 없음";
            default:
                return "알 수 없음";
        }
    }

    void HandleMove(string msg)
    {
        MovePacket data = JsonUtility.FromJson<MovePacket>(msg);
        gomoku.PlaceStonePublic(new Vector2Int(data.x, data.y), data.player);
    }

    void HandleEnd(string msg)
    {
        EndPacket data = JsonUtility.FromJson<EndPacket>(msg);

        // 🔥 winLine 처리
        if (data.winLine != null && data.winLine.Length > 0)
        {
            List<Vector2Int> winLine = new List<Vector2Int>();

            foreach (var p in data.winLine)
            {
                winLine.Add(new Vector2Int(p.x, p.y));
            }

            gomoku.ShowWinLinePublic(winLine);
        }

        // 🔥 matchId 저장 (핵심)
        if (!string.IsNullOrEmpty(data.matchId))
        {
            Debug.Log("📦 matchId 저장: " + data.matchId);
            gomoku.SetLastMatchId(data.matchId);
        }
        else
        {
            Debug.LogWarning("❌ matchId 없음");
        }

        // 🔥 게임 종료 처리
        gomoku.OnGameEndPublic(data.winner, data.reason);

        // 🔥 UI 정리
        undoUI.ResetUI();
        state.isUndoPending = false;
        state.undoUsedThisTurn = false;

        // 🔥 결과 UI
        winReasonUI.Show(data.winner, data.reason);
    }

    void HandleReplay(string msg)
    {
        ReadyPacket data = JsonUtility.FromJson<ReadyPacket>(msg);
        playerUI.SetState(data.playerId, "다시하기 선택");
    }

    void HandleRestartRequest()
    {
        gomoku.ShowReplayRequestPanelPublic(true);

        state.isRequester = false;
        state.isRestartPending = true;

        systemManager.ShowMessage("상대가 재시작을 요청했습니다");
    }

    void HandleRestartCancel()
    {
        gomoku.ShowReplayRequestPanelPublic(false);
        gomoku.ShowReplayRequestingPanelPublic(false);

        if (!state.isRequester)
            systemManager.ShowMessage("상대가 요청을 끊었습니다");

        state.isRestartPending = false;
    }

    void HandleRestartAccept()
    {
        gomoku.ResetGame();

        gomoku.ShowReplayRequestingPanelPublic(false);
        gomoku.ShowReplayRequestPanelPublic(false);

        state.isRequester = false;
        state.isRestartPending = false;
    }

    void HandleRestartReject()
    {
        gomoku.ShowReplayRequestingPanelPublic(false);

        state.isRequester = false;
        state.isRestartPending = false;

        systemManager.ShowMessage("상대가 거절했습니다");
    }

    void HandleMatchData(string msg)
    {
        MatchDataPacket data = JsonUtility.FromJson<MatchDataPacket>(msg);

        // ID 설정
        gomoku.SetLastMatchId(data.matchId);

        gomoku.StartReplayFromMatch(data);
    }

    void HandleMatchList(string msg)
    {
        MatchListPacket data = JsonUtility.FromJson<MatchListPacket>(msg);

        Debug.Log("📚 MATCH_LIST 수신: " + data.matches.Length);

        matchHistoryUI.SetData(data.matches.ToList());
        matchHistoryUI.Open(data.matches.ToList());
        matchHistoryUI.RefreshUI();
    }

    void HandleUndoOptionResult(string msg)
    {
        UndoResultPacket data = JsonUtility.FromJson<UndoResultPacket>(msg);

        state.undoEnabled = data.enabled;

        undoUI.HideOptionPanel();
        undoUI.ShowResult(state.undoEnabled);

        systemManager.ShowMessage(
            data.enabled ? "무르기 기능이 활성화되었습니다." : "무르기 기능이 비활성화되었습니다."
        );
    }

    void HandleUndoCancel()
    {
        undoUI.HideVotePanel();         // 피요청자 패널
        undoUI.HideRequestingPanel();   // 요청자 패널

        state.undoUsedThisTurn = false;
        state.isUndoPending = false;

        systemManager.ShowMessage("무르기 요청이 취소되었습니다.");
    }

    void HandleMatchNotFound()
    {
        Debug.LogWarning("❌ MATCH_NOT_FOUND");

        systemManager.ShowMessage("복기 데이터를 찾을 수 없습니다.");
    }
}
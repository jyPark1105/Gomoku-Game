﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class ChatUIManager : MonoBehaviour
{
    public TypingIndicatorUI typingIndicator;

    [Header("Input")]
    public TMP_InputField inputField;

    [Header("Chat")]
    public GameObject chatOpenButton;
    public GameObject chatPanel;
    public Transform content;
    public ScrollRect scrollRect;

    [Header("Send Button")]
    public Button chatSendButton;

    [Header("Prefabs")]
    public GameObject myMessagePrefab;
    public GameObject otherMessagePrefab;

    [Header("Warning UI")]
    public GameObject warningPanel;
    public TMP_Text warningText;

    public int myPlayerId;

    Dictionary<int, string> playerNames = new Dictionary<int, string>();
    Dictionary<int, int> playerAvatars = new Dictionary<int, int>();

    bool isTyping = false;
    Coroutine typingRoutine;

    // 도배 체크
    Queue<float> sendTimes = new Queue<float>();
    bool isChatBlocked = false;

    // 욕설 체크
    int badWordCount = 0;
    bool isPermanentBlocked = false;

    Coroutine warningRoutine;

    void Start()
    {
        inputField.onSubmit.AddListener(_ => TrySend());
    }

    /// <summary>
    /// 입력 필드 값이 변경될 때 호출됨
    /// 타이핑 시작/종료 패킷을 서버로 전송
    /// </summary>
    public void OnValueChanged(string text)
    {
        if (!isTyping && !string.IsNullOrEmpty(text))
        {
            isTyping = true;
            SendTyping(true);
        }

        if (typingRoutine != null)
            StopCoroutine(typingRoutine);

        typingRoutine = StartCoroutine(TypingTimeout());
    }

    /// <summary>
    /// 일정 시간 입력이 없으면 타이핑 상태를 종료
    /// </summary>
    IEnumerator TypingTimeout()
    {
        yield return new WaitForSeconds(1.2f);

        if (isTyping)
        {
            isTyping = false;
            SendTyping(false);
        }
    }

    /// <summary>
    /// 타이핑 시작/종료 패킷을 서버로 전송
    /// </summary>
    void SendTyping(bool start)
    {
        TypingPacket packet = new TypingPacket
        {
            type = start ? "TYPING_START" : "TYPING_STOP"
        };

        NetworkController.Instance.Send(JsonUtility.ToJson(packet));
    }

    /// <summary>
    /// UI 버튼 클릭 시 호출되는 채팅 전송 함수
    /// </summary>
    public void OnClickSend()
    {
        TrySend();
    }

    /// <summary>
    /// 채팅 전송 시도
    /// - 영구 차단 체크
    /// - 임시 차단 체크
    /// - 욕설 및 도배 검사
    /// - 정상일 경우 서버로 전송
    /// </summary>
    void TrySend()
    {
        if (isPermanentBlocked) return;

        if (isChatBlocked)
        {
            ShowWarning("채팅이 제한되었습니다.", 36);
            return;
        }

        string text = inputField.text.Trim();

        if (string.IsNullOrWhiteSpace(text))
            return;

        // 🔥 욕설 체크
        if (ContainsBadWord(text))
        {
            badWordCount++;

            if (badWordCount >= 3)
            {
                PermanentBlock();
                return;
            }
        }

        // 🔥 도배 체크
        float now = Time.time;
        sendTimes.Enqueue(now);

        while (sendTimes.Count > 0 && now - sendTimes.Peek() > 10f)
            sendTimes.Dequeue();

        if (sendTimes.Count >= 6)
        {
            StartCoroutine(BlockChatTemporarily());
            return;
        }

        // 🔥 전송
        NetworkController.Instance.SendChat(text);

        StopTyping();

        inputField.text = "";
    }

    /// <summary>
    /// 도배로 인한 일정 시간 채팅 차단
    /// </summary>
    IEnumerator BlockChatTemporarily()
    {
        isChatBlocked = true;

        ShowWarning("채팅 도배로 인해 30초 동안 채팅이 제한됩니다", 36);

        SetChatInteractable(false);

        yield return new WaitForSeconds(30f);

        isChatBlocked = false;
        SetChatInteractable(true);
    }

    /// <summary>
    /// 욕설 누적으로 인한 영구 채팅 차단
    /// </summary>
    void PermanentBlock()
    {
        isPermanentBlocked = true;

        ShowWarning("잦은 욕설로 인해 채팅이\n영구 제한되었습니다.", 40);

        SetChatInteractable(false);
    }

    /// <summary>
    /// 경고 메시지 출력
    /// Fade In / Out 코루틴 실행
    /// </summary>
    void ShowWarning(string message, int fontSize)
    {
        warningText.text = message;
        warningText.fontSize = fontSize;

        if (warningRoutine != null)
            StopCoroutine(warningRoutine);

        warningRoutine = StartCoroutine(WarningFadeRoutine());
    }

    /// <summary>
    /// 경고 UI를 부드럽게 표시 후 일정 시간 뒤 사라지게 하는 코루틴
    /// </summary>
    IEnumerator WarningFadeRoutine()
    {
        warningPanel.SetActive(true);

        CanvasGroup cg = warningPanel.GetComponent<CanvasGroup>();

        if (cg == null)
            cg = warningPanel.AddComponent<CanvasGroup>();

        float fadeInTime = 0.2f;
        float showTime = 2.0f;
        float fadeOutTime = 0.5f;

        // 🔥 Fade In
        float t = 0f;
        while (t < fadeInTime)
        {
            t += Time.deltaTime;
            cg.alpha = Mathf.Lerp(0f, 1f, t / fadeInTime);
            yield return null;
        }

        cg.alpha = 1f;

        // 🔥 유지
        yield return new WaitForSeconds(showTime);

        // 🔥 Fade Out
        t = 0f;
        while (t < fadeOutTime)
        {
            t += Time.deltaTime;
            cg.alpha = Mathf.Lerp(1f, 0f, t / fadeOutTime);
            yield return null;
        }

        cg.alpha = 0f;
        warningPanel.SetActive(false);
    }

    /// <summary>
    /// 채팅 입력 및 버튼 활성/비활성 처리
    /// </summary>
    void SetChatInteractable(bool state)
    {
        inputField.interactable = state;

        if (chatSendButton != null)
            chatSendButton.interactable = state;
    }

    /// <summary>
    /// 메시지에 욕설이 포함되어 있는지 검사
    /// </summary>
    bool ContainsBadWord(string text)
    {
        string[] badWords = { "씨발", "병신", "ㅅㅂ", "fuck" };

        foreach (var word in badWords)
        {
            if (text.ToLower().Contains(word))
                return true;
        }

        return false;
    }

    /// <summary>
    /// 타이핑 상태 종료 및 서버에 종료 패킷 전송
    /// </summary>
    void StopTyping()
    {
        if (typingRoutine != null)
            StopCoroutine(typingRoutine);

        if (isTyping)
        {
            isTyping = false;
            SendTyping(false);
        }
    }

    /// <summary>
    /// 서버에서 받은 채팅 메시지를 UI에 추가
    /// </summary>
    public void AddMessage(int playerId, string message, long timestamp)
    {
        typingIndicator.Hide(playerId);

        bool isMine = (playerId == myPlayerId);

        GameObject prefab = isMine ? myMessagePrefab : otherMessagePrefab;

        GameObject go = Instantiate(prefab, content);

        ChatMessageUI ui = go.GetComponent<ChatMessageUI>();

        ui.Set(
            message,
            GetPlayerName(playerId),
            GetPlayerAvatar(playerId),
            timestamp
        );

        StartCoroutine(ScrollToBottom());
    }

    /// <summary>
    /// 플레이어 이름 및 아바타 정보 저장
    /// </summary>
    public void SetPlayerInfo(int playerId, string name, int avatarIndex)
    {
        playerNames[playerId] = name;
        playerAvatars[playerId] = avatarIndex;
    }

    /// <summary>
    /// 플레이어 이름 반환 (없으면 UNKNOWN)
    /// </summary>
    public string GetPlayerName(int playerId)
    {
        return playerNames.ContainsKey(playerId) ? playerNames[playerId] : "UNKNOWN";
    }

    /// <summary>
    /// 플레이어 아바타 스프라이트 반환
    /// </summary>
    public Sprite GetPlayerAvatar(int playerId)
    {
        if (!playerAvatars.ContainsKey(playerId)) return null;

        return Resources.Load<Sprite>($"Avatars/avatar_{playerAvatars[playerId]}");
    }

    /// <summary>
    /// 채팅 스크롤을 맨 아래로 이동
    /// </summary>
    IEnumerator ScrollToBottom()
    {
        yield return null;

        Canvas.ForceUpdateCanvases();
        scrollRect.verticalNormalizedPosition = 0f;
    }

    /// <summary>
    /// 상대방 타이핑 상태 표시/숨김 처리
    /// </summary>
    public void SetTypingState(int playerId, bool typing)
    {
        if (playerId == myPlayerId) return;

        // 🔥 채팅창 열려 있어도 표시하게 바꿈
        if (typing)
            typingIndicator.Show(playerId);
        else
            typingIndicator.Hide(playerId);
    }

    /// <summary>
    /// 서버로부터 임시 채팅 제한(BLOCK)을 받았을 때 처리
    /// </summary>
    public void OnBlock(string message)
    {
        isChatBlocked = true;

        ShowWarning(message, 36);

        SetChatInteractable(false);

        StopAllCoroutines();
        StartCoroutine(UnblockRoutine(5f)); // 서버랑 맞춰라
    }

    /// <summary>
    /// 일정 시간 후 채팅 제한 해제
    /// </summary>
    IEnumerator UnblockRoutine(float time)
    {
        yield return new WaitForSeconds(time);

        isChatBlocked = false;
        SetChatInteractable(true);
    }

    /// <summary>
    /// 서버로부터 영구 채팅 제한(PERMA_BLOCK)을 받았을 때 처리
    /// </summary>
    public void OnPermaBlock(string message)
    {
        isPermanentBlocked = true;

        ShowWarning(message, 40);

        SetChatInteractable(false);
    }

    /// <summary>
    /// 채팅창 열기
    /// </summary>
    public void OnOpenChat()
    {
        chatPanel.SetActive(true);
        typingIndicator.HideAll();
    }

    /// <summary>
    /// 채팅창 닫기
    /// </summary>
    public void OnCloseChat()
    {
        chatPanel.SetActive(false);
    }
}
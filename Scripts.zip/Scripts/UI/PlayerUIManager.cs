﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerUIManager : MonoBehaviour
{
    [Header("Player 1")]
    public Image p1Highlight;
    public TMP_Text p1Name;
    public Image p1Avatar;

    [Header("Player 2")]
    public Image p2Highlight;
    public TMP_Text p2Name;
    public Image p2Avatar;

    [Header("State Text")]
    public TMP_Text p1StateText;
    public TMP_Text p2StateText;

    [Header("Join Panel")]
    public GameObject p1JoinPanel;
    public GameObject p2JoinPanel;

    [Header("Win / Lose")]
    public TMP_Text p1WinLoseRateText;
    public TMP_Text p2WinLoseRateText;

    [Header("Tier")]
    public Image p1TierFrame;
    public Image p2TierFrame;
    public TMP_Text p1TierText;
    public TMP_Text p2TierText;

    [Header("Stone Type")]
    public Image p1StoneType;
    public Image p2StoneType;

    Sprite gradeBronze, gradeSilver, gradeGold;
    Sprite danBronze, danSilver, danGold;

    int myPlayerId;

    void Awake()
    {
        gradeBronze = Resources.Load<Sprite>("Player/grade_bronze");
        gradeSilver = Resources.Load<Sprite>("Player/grade_silver");
        gradeGold = Resources.Load<Sprite>("Player/grade_gold");

        danBronze = Resources.Load<Sprite>("Player/dan_bronze");
        danSilver = Resources.Load<Sprite>("Player/dan_silver");
        danGold = Resources.Load<Sprite>("Player/dan_gold");
    }

    // UI 초기화
    public void Init(int playerId)
    {
        if (p1Highlight != null)
            p1Highlight.gameObject.SetActive(false);
        if (p2Highlight != null)
            p2Highlight.gameObject.SetActive(false);

        if (p1StoneType != null)
            p1StoneType.enabled = false;
        if (p2StoneType != null)
            p2StoneType.enabled = false;

        myPlayerId = playerId;
    }

    // 데이터 반영: 이름
    public void SetName(int playerId, string name)
    {
        int fontSize = CalculateFontSize(name);

        if (playerId == 1)
        {
            p1Name.text = name;
            p1Name.fontSize = fontSize;
        }
        else if (playerId == 2)
        {
            p2Name.text = name;
            p2Name.fontSize = fontSize;
        }
    }

    int CalculateFontSize(string name)
    {
        int baseSize = 26;

        int wmCount = 0;

        foreach (char c in name)
        {
            if (c == 'w' || c == 'm')
                wmCount++;
        }

        // wm 2개당 1 감소
        int reduce = wmCount / 2;

        int result = baseSize - reduce;

        // 최소 보정
        return Mathf.Max(result, 20);
    }

    // 데이터 반영: 초상화
    public void SetAvatar(int playerId, int avatarIndex)
    {
        Sprite sprite = Resources.Load<Sprite>($"Avatars/avatar_{avatarIndex}");

        if (sprite == null)
        {
            Debug.LogWarning($"avatar_{avatarIndex} 로드 실패");
            return;
        }

        if (playerId == 1 && p1Avatar != null)
            p1Avatar.sprite = sprite;
        else if (playerId == 2 && p2Avatar != null)
            p2Avatar.sprite = sprite;
    }
    public void SetState(int playerId, string state)
    {
        if (playerId == 1)
            p1StateText.text = state;
        else
            p2StateText.text = state;
    }

    public void SetWinLose(int playerId, int win, int lose)
    {
        int total = win + lose;
        float rate = total > 0 ? (win / (float)total) * 100f : 0f;

        string text = total > 0
            ? $"{win}승 {lose}패 ({rate:F1}%)"
            : $"{win}승 {lose}패 (-)";

        if (playerId == 1 && p1WinLoseRateText != null)
            p1WinLoseRateText.text = text;
        else if (playerId == 2 && p2WinLoseRateText != null)
            p2WinLoseRateText.text = text;
    }


    public void SetTier(int playerId, int tier)
    {
        string text = GetTierText(tier);
        Sprite frame = GetTierFrameSprite(tier);

        if (playerId == 1)
        {
            p1TierText.text = text;
            if (p1TierFrame != null)
                p1TierFrame.sprite = frame;
        }
        else
        {
            p2TierText.text = text;
            if (p2TierFrame != null)
                p2TierFrame.sprite = frame;
        }
    }

    Sprite GetTierFrameSprite(int score)
    {
        if (score < 1000)
        {
            int tier = Mathf.Clamp(10 - (score / 100), 1, 10);

            if (tier >= 7) return gradeBronze;
            if (tier >= 4) return gradeSilver;
            return gradeGold;
        }
        else
        {
            int dan = (score - 1000) / 100 + 1;

            if (dan <= 3) return danBronze;
            if (dan <= 6) return danSilver;
            return danGold;
        }
    }

    string GetTierText(int tier)
    {
        // 1~10 → 급
        if (tier >= 1 && tier <= 10)
            return $"{tier}급";

        // 11부터 → 단
        int dan = tier - 10;
        return $"{dan}단";
    }

    public void SetReadyState(int playerId, bool isReady)
    {
        if (playerId == 1)
            p1StateText.text = isReady ? "준비 완료" : "대기 중";
        else
            p2StateText.text = isReady ? "준비 완료" : "대기 중";
    }

    public void ShowJoinPanel(int playerId, bool show)
    {
        if (playerId == 1 && p1JoinPanel != null)
            p1JoinPanel.SetActive(show);

        if (playerId == 2 && p2JoinPanel != null)
            p2JoinPanel.SetActive(show);
    }

    public void UpdateTurn(int currentTurn)
    {
        p1Highlight.gameObject.SetActive(false);
        p2Highlight.gameObject.SetActive(false);

        if (currentTurn == 1)
            p1Highlight.gameObject.SetActive(true);
        else
            p2Highlight.gameObject.SetActive(true);
    }

    public void SetStoneType(int blackPlayerId)
    {
        Sprite black = Resources.Load<Sprite>("BlackStone");
        Sprite white = Resources.Load<Sprite>("WhiteStone");

        if (black == null || white == null)
        {
            Debug.LogError("❌ Stone sprite 로드 실패");
            return;
        }

        // Player 1
        if (p1StoneType != null)
        {
            p1StoneType.enabled = true;
            p1StoneType.sprite = (blackPlayerId == 1) ? black : white;
        }

        // Player 2
        if (p2StoneType != null)
        {
            p1StoneType.enabled = true;
            p2StoneType.sprite = (blackPlayerId == 2) ? black : white;
        }
    }
}
﻿using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.Collections;
using System;
using System.Linq;

public class MatchHistoryUI : MonoBehaviour
{
    public GomokuManager gomokuManager;
    public GameStartUI gameStartPanelUI;

    // 대국 기록 패널
    public GameObject matchHistoryPanel;

    // 현재 날짜
    public TMP_Text CurrentDateText;

    /// <summary>
    /// Scroll View Content
    /// </summary>
    public Transform content;

    // 대국 기록 프리펩
    public GameObject matchItemPrefab;
    // 날짜 표시 UI 프리펩
    public GameObject dateHeaderPrefab;

    // 🔥 Time UI
    public GameObject timeSubPanel;
    public TMP_Text timeFilterText;     // 버튼 루트에 표시될 텍스트

    // 🔥 Result UI
    public GameObject resultSubPanel;
    public TMP_Text resultFilterText;   // 버튼 루트에 표시될 텍스트

    public GameObject subBackground;

    // 🔥 Time 버튼들
    public GameObject[] timeButtons; // 0: Daily, 1: Weekly, 2: Monthly

    // 🔥 Result 버튼들
    public GameObject[] resultButtons; // 0: All, 1: Win, 2: Lose

    List<MatchListItemPacket> allMatches;
    MatchFilterOption option = new MatchFilterOption();

    // 버튼 색상용 변수
    Color normalColor = Color.white;
    Color selectedColor = new Color(1f, 0.9f, 0.6f); // 살짝 노란톤

    void Start()
    {
        option.timeFilter = TimeFilter.Daily;
        option.resultFilter = ResultFilter.All;

        UpdateFilterTexts();

        timeSubPanel.SetActive(false);
        resultSubPanel.SetActive(false); 
        subBackground.SetActive(false);

        // Outline 제어
        UpdateTimeOutline();
        UpdateResultOutline();

        // Button Animation 제어
        UpdateTimeVisual(); 
        UpdateResultVisual();

        UpdateCurrentDate();
    }

    /// <summary>
    /// 0. NetworkController.Instance.RequestMatchList 함수 호출
    /// 1. GET_MATCH_LIST 패킷 전송 (Client → Server)
    /// 2. MatchService.handleGetMatchList 호출 (Server)
    /// 3. MATCH_LIST 패킷 전송 (Server → Client)
    /// 4. HandleMatchList 함수 호출 (Router) → gomoku.ShowMatchHistory 호출
    /// 
    /// 대국 기록 패널 열람
    /// </summary>
    public void OnClickOpenMatchHistory()
    {
        Debug.Log("📡 대국 기록 요청");
        NetworkController.Instance.RequestMatchList();
    }

    void UpdateCurrentDate()
    {
        System.DateTime now = System.DateTime.Now;

        CurrentDateText.text = now.ToString("yyyy/MM/dd");
    }

    (string text, int fontSize) FormatDateHeader(long timestamp)
    {
        var date = DateTimeOffset
            .FromUnixTimeMilliseconds(timestamp)
            .ToOffset(TimeSpan.FromHours(9))
            .DateTime;

        var now = DateTime.Now;

        int days = (now.Date - date.Date).Days;

        // 🔥 오늘 / 어제
        if (days == 0)
            return ("오늘", 40);

        if (days == 1)
            return ("어제", 40);

        // 🔥 일 단위 (2~6일)
        if (days < 7)
            return ($"{days}일 전", 32);

        // 🔥 주 단위 (1~4주)
        if (days < 30)
        {
            int weeks = days / 7;
            return ($"{weeks}주 전", 32);
        }

        // 🔥 월 단위 (1~11달)
        if (days < 365)
        {
            int months = days / 30;
            return ($"{months}달 전", 32);
        }

        // 🔥 연 단위
        int years = days / 365;
        return ($"{years}년 전", 32);
    }

    /// <summary>
    /// Outline 제어 함수 (Time)
    /// </summary>
    void UpdateTimeOutline()
    {
        for (int i = 0; i < timeButtons.Length; i++)
        {
            var outline = timeButtons[i]
                .GetComponentInChildren<UIOutline>(true);

            if (outline != null)
                outline.enabled = (i == (int)option.timeFilter);
        }
    }

    /// <summary>
    /// Outline 제어 함수 (Result)
    /// </summary>
    void UpdateResultOutline()
    {
        for (int i = 0; i < resultButtons.Length; i++)
        {
            var outline = resultButtons[i]
                .GetComponentInChildren<UIOutline>(true);

            if (outline != null)
                outline.enabled = (i == (int)option.resultFilter);
        }
    }

    /// <summary>
    /// 버튼 스타일 적용 (Time)
    /// </summary>
    void UpdateTimeVisual()
    {
        for (int i = 0; i < timeButtons.Length; i++)
        {
            var img = timeButtons[i].GetComponent<UnityEngine.UI.Image>();

            if (img != null)
            {
                img.color = (i == (int)option.timeFilter)
                    ? selectedColor
                    : normalColor;
            }
        }
    }

    /// <summary>
    /// 버튼 스타일 적용 (Result)
    /// </summary>
    void UpdateResultVisual()
    {
        for (int i = 0; i < resultButtons.Length; i++)
        {
            var img = resultButtons[i].GetComponent<UnityEngine.UI.Image>();

            if (img != null)
            {
                img.color = (i == (int)option.resultFilter)
                    ? selectedColor
                    : normalColor;
            }
        }
    }

    void UpdateFilterTexts()
    {
        // Time
        switch (option.timeFilter)
        {
            case TimeFilter.Daily:
                timeFilterText.text = "일간";
                break;
            case TimeFilter.Weekly:
                timeFilterText.text = "주간";
                break;
            case TimeFilter.Monthly:
                timeFilterText.text = "월간";
                break;
        }

        // Result
        switch (option.resultFilter)
        {
            case ResultFilter.All:
                resultFilterText.text = "전체";
                break;
            case ResultFilter.Win:
                resultFilterText.text = "승리";
                break;
            case ResultFilter.Lose:
                resultFilterText.text = "패배";
                break;
        }
    }

    public void OnClickTimeFilter()
    {
        bool isActive = timeSubPanel.activeSelf;

        timeSubPanel.SetActive(!isActive);

        // 🔥 다른 패널 닫기
        resultSubPanel.SetActive(false);

        // 🔥 Background 처리
        subBackground.SetActive(!isActive);
    }

    public void OnClickResultFilter()
    {
        bool isActive = resultSubPanel.activeSelf;

        resultSubPanel.SetActive(!isActive);

        // 🔥 다른 패널 닫기
        timeSubPanel.SetActive(false);

        // 🔥 Background 처리
        subBackground.SetActive(!isActive);
    }

    /// <summary>
    /// Time
    /// </summary>
    /// <param name="index"></param>
    public void OnClickTimeOption(int index)
    {
        StartCoroutine(PressAnimation(timeButtons[index]));

        option.timeFilter = (TimeFilter)index;
        OnSelectTime();
    }

    void OnSelectTime()
    {
        timeSubPanel.SetActive(false);

        // 🔥 Background 끄기
        subBackground.SetActive(false);

        UpdateFilterTexts();
        UpdateTimeOutline();
        UpdateTimeVisual();
        RefreshUI();
    }

    /// <summary>
    /// Result
    /// </summary>
    /// <param name="index"></param>
    public void OnClickResultOption(int index)
    {
        StartCoroutine(PressAnimation(resultButtons[index]));

        option.resultFilter = (ResultFilter)index;
        OnSelectResult();
    }

    void OnSelectResult()
    {
        resultSubPanel.SetActive(false);

        // 🔥 Background 끄기
        subBackground.SetActive(false);

        UpdateFilterTexts();
        UpdateResultOutline();
        UpdateResultVisual();
        RefreshUI();
    }


    IEnumerator PressAnimation(GameObject btn)
    {
        RectTransform rt = btn.GetComponent<RectTransform>();

        Vector3 original = rt.localScale;
        Vector3 pressed = original * 0.9f;

        float t = 0f;

        // 눌림
        while (t < 1f)
        {
            t += Time.deltaTime * 15f;
            rt.localScale = Vector3.Lerp(original, pressed, t);
            yield return null;
        }

        t = 0f;

        // 복원
        while (t < 1f)
        {
            t += Time.deltaTime * 15f;
            rt.localScale = Vector3.Lerp(pressed, original, t);
            yield return null;
        }

        rt.localScale = original;
    }

    public void SetData(List<MatchListItemPacket> matches)
    {
        allMatches = matches;
    }

    public void RefreshUI()
    {
        int myId = gomokuManager.GetMyPlayerIdPublic();

        var filtered = MatchHistoryProcessor.ApplyFilter(allMatches, option, myId);
        var stats = MatchHistoryProcessor.CalculateStats(filtered, myId);
        var grouped = MatchHistoryProcessor.GroupByDate(filtered);

        UpdateStatsUI(stats);
        DrawList(grouped);
    }

    void UpdateStatsUI(MatchStats stats)
    {
        Debug.Log($"총 {stats.total}판 / {stats.win}승 {stats.lose}패 / 승률 {stats.winRate}");
    }

    void DrawList(Dictionary<string, List<MatchListItemPacket>> grouped)
    {
        foreach (Transform child in content)
            Destroy(child.gameObject);

        // 🔥 날짜 기준 정렬 (최신이 위)
        var sortedGroups = grouped
            .OrderByDescending(g => g.Value[0].startedAt);

        foreach (var group in sortedGroups)
        {
            var matches = group.Value;

            if (matches == null || matches.Count == 0)
                continue;

            // 🔥 헤더 생성 (1번만)
            var (headerText, fontSize) = FormatDateHeader(matches[0].startedAt);

            var header = Instantiate(dateHeaderPrefab, content);

            // DateHeaderUI 컴포넌트 로딩
            var headerUI = header.GetComponent<DateHeaderUI>();
            // 헤더값 할당
            headerUI.Set(headerText, fontSize);

            // 🔥 그 아래에 MatchItem들
            foreach (var match in matches)
            {
                var item = Instantiate(matchItemPrefab, content);
                item.GetComponent<MatchItemUI>().SetupFromList(match, gomokuManager);
            }
        }
    }

    public void Open(List<MatchListItemPacket> matches)
    {
        matchHistoryPanel.SetActive(true);

        foreach (Transform child in content)
            Destroy(child.gameObject);

        foreach (var match in matches)
        {
            var item = Instantiate(matchItemPrefab, content);

            item.GetComponent<MatchItemUI>().SetupFromList(match, gomokuManager);
        }
    }

    public void Close()
    {
        // 🔥 패널 비활성화
        if (matchHistoryPanel != null)
            matchHistoryPanel.SetActive(false);

        // 🔥 리스트 정리 (메모리/중복 방지)
        foreach (Transform child in content)
        {
            Destroy(child.gameObject);
        }

        Debug.Log("📕 MatchHistoryPanel 닫힘");

        // 🔥 로비 다시 켜기
        if (gameStartPanelUI != null)
            StartCoroutine(gameStartPanelUI.FadeBackground());
    }
}
﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class ChatMessageUI : MonoBehaviour
{
    public TMP_Text messageText;
    public TMP_Text nameText;
    public Image portrait;
    public TMP_Text sendTimeText;

    public void Set(string message, string name, Sprite avatar, long timestamp)
    {
        messageText.text = message;
        nameText.text = name;
        portrait.sprite = avatar;

        if (sendTimeText != null)
            sendTimeText.text = FormatTime(timestamp);
    }

    string FormatTime(long timestamp)
    {
        var date = DateTimeOffset.FromUnixTimeMilliseconds(timestamp)
                    .ToOffset(TimeSpan.FromHours(9))
                    .DateTime;

        // 🔥 오전/오후 포함
        if (date.Hour < 12)
            return date.ToString("tt hh:mm:ss"); // 오전
        else
            return date.ToString("tt hh:mm:ss"); // 오후
    }
}
﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RankingItemUI : MonoBehaviour
{
    public TMP_Text rankText;
    public TMP_Text nameText;
    public TMP_Text winLoseRateText;
    public TMP_Text tierText;

    public Image avatarImage;
    public Image tierFrame;

    public Image rootImage; // 랭킹 패널 배경 이미지(RankingItemPrefab 자체)
    public Image rankFrame; // 랭킹 순위 배경 이미지

    // 🔥 티어 프레임
    Sprite gradeBronze, gradeSilver, gradeGold;
    Sprite danBronze, danSilver, danGold;

    // 🔥 랭킹 패널 배경
    Sprite rank1Panel, rank2Panel, rank3Panel, rankPanelDefault;

    // 🔥 랭킹 순위 배경
    Sprite rank1Frame, rank2Frame, rank3Frame, rankFrameDefault;

    void Awake()
    {
        // 🔥 티어 프레임
        gradeBronze = Resources.Load<Sprite>("Player/grade_bronze");
        gradeSilver = Resources.Load<Sprite>("Player/grade_silver");
        gradeGold = Resources.Load<Sprite>("Player/grade_gold");

        danBronze = Resources.Load<Sprite>("Player/dan_bronze");
        danSilver = Resources.Load<Sprite>("Player/dan_silver");
        danGold = Resources.Load<Sprite>("Player/dan_gold");

        // 🔥 랭킹 패널 배경
        rank1Panel = Resources.Load<Sprite>("Rank/rank_panel_top_1_gold");
        rank2Panel = Resources.Load<Sprite>("Rank/rank_panel_top_2_silver");
        rank3Panel = Resources.Load<Sprite>("Rank/rank_panel_top_3_bronze");
        rankPanelDefault = Resources.Load<Sprite>("Rank/rank_panel_top_4-to-10_default");

        // 🔥 랭킹 순위 배경 (숫자용)
        rank1Frame = Resources.Load<Sprite>("Rank/rank_frame_top_1_gold");
        rank2Frame = Resources.Load<Sprite>("Rank/rank_frame_top_2_silver");
        rank3Frame = Resources.Load<Sprite>("Rank/rank_frame_top_3_bronze");
        rankFrameDefault = Resources.Load<Sprite>("Rank/rank_frame_top_4-to-10_default");
    }

    public void Set(int rank, string name, int avatarIndex, int win, int lose, int tier)
    {
        rankText.text = rank.ToString();
        nameText.text = name;

        // 🔥 아바타
        var sprite = Resources.Load<Sprite>($"Avatars/avatar_{avatarIndex}");
        if (sprite != null)
            avatarImage.sprite = sprite;

        // 🔥 승률 포함
        int total = win + lose;
        float rate = total > 0 ? (win / (float)total) * 100f : 0f;

        winLoseRateText.text = total == 0
            ? "0승 0패 (-)"
            : $"{win}승 {lose}패 ({rate:F1}%)";

        winLoseRateText.color = GetRateColor(rate);

        // 🔥 티어
        tierText.text = GetTierText(tier);

        // 🔥 티어 프레임
        if (tierFrame != null)
            tierFrame.sprite = GetTierFrameSprite(tier);

        // 🔥 랭킹별 패널 배경 적용
        if (rootImage != null)
        {
            if (rank == 1) rootImage.sprite = rank1Panel;
            else if (rank == 2) rootImage.sprite = rank2Panel;
            else if (rank == 3) rootImage.sprite = rank3Panel;
            else rootImage.sprite = rankPanelDefault;
        }

        // 🔥 랭킹별 순위 배경 적용
        if (rankFrame != null)
        {
            if (rank == 1) rankFrame.sprite = rank1Frame;
            else if (rank == 2) rankFrame.sprite = rank2Frame;
            else if (rank == 3) rankFrame.sprite = rank3Frame;
            else rankFrame.sprite = rankFrameDefault;
        }
    }

    Color GetRateColor(float rate)
    {
        if (rate >= 70f) return Color.green;
        if (rate >= 50f) return Color.yellow;
        return Color.red;
    }

    string GetTierText(int score)
    {
        int tier = Mathf.Clamp(10 - (score / 100), 1, 10);

        if (score < 1000)
            return $"{tier}급";

        int dan = (score - 1000) / 100 + 1;
        return $"{dan}단";
    }

    Sprite GetTierFrameSprite(int score)
    {
        if (score < 1000)
        {
            int tier = Mathf.Clamp(10 - (score / 100), 1, 10);

            if (tier >= 7) return gradeBronze;
            if (tier >= 4) return gradeSilver;
            return gradeGold;
        }
        else
        {
            int dan = (score - 1000) / 100 + 1;

            if (dan <= 3) return danBronze;
            if (dan <= 6) return danSilver;
            return danGold;
        }
    }
}
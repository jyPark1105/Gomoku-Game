﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System;

public class RoomUIManager : MonoBehaviour
{
    // === RoomUIRoot 룸 내부 ===
    // 방 내부 루트 패널
    public GameObject roomUIRoot;

    [Header("Room Overlay")]
    // 방 상태
    public TMP_Text statusText;
    public TMP_Text roomInfoText;
    // 준비 버튼
    public Button readyButton;
    public Image readyButtonImage;
    public TMP_Text readyButtonText;

    // 게임 중 버튼 패널(계속하기, 나가기)
    public GameObject q_PlayingGamePanel;
    // 게임 끝 버튼 패널(재시작하기, 복기하기, 나가기)
    public GameObject q_EndGamePanel;

    public Coroutine countdownCoroutine;

    [Header("Opponent Disconnect UI")]
    public GameObject opponentDisconnectPanel;

    public TMP_Text headerText;
    public TMP_Text waitingReasonText;
    public TMP_Text otherPlayerAwayCountText;
    public TMP_Text explanationText;

    [Header("Disconnect Timer")]
    public TMP_Text countdownText;

    double disconnectStartTime;
    float disconnectDuration;
    bool isDisconnectTimerRunning;

    string baseHeader = "상대방의 응답을\n기다리고 있습니다.";
    Coroutine headerAnimCoroutine;

    Sprite greenSprite;
    Sprite redSprite;

    bool isReady = false;

    void Start()
    {
        greenSprite = Resources.Load<Sprite>("btn_ready_green");
        redSprite = Resources.Load<Sprite>("btn_ready_red");

        SetReadyButton(false);
    }

    void Update()
    {
        if (!isDisconnectTimerRunning) return;

        // 🔥 서버 기준 시간으로 매 프레임 다시 계산
        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        float remaining = disconnectDuration - (float)((now - disconnectStartTime) / 1000.0);

        if (remaining < 0f)
            remaining = 0f;

        int sec = Mathf.CeilToInt(remaining);

        if (countdownText != null)
            countdownText.text = sec.ToString();

        if (remaining <= 5f)
        {
            countdownText.color = Color.red;
        }

        if (remaining <= 0f)
        {
            isDisconnectTimerRunning = false;
        }
    }

    public void ShowRoomUI(int roomId)
    {
        readyButton.gameObject.SetActive(false);

        roomInfoText.text = $"Room {roomId}";
        statusText.text = "상대 기다리는 중...";
    }

    public void EnableReadyButton()
    {
        readyButton.gameObject.SetActive(true);
        statusText.text = "준비 버튼을 누르세요";
    }

    public void SetReadyButton(bool ready)
    {
        isReady = ready;

        if (ready)
        {
            readyButtonImage.sprite = redSprite;
            readyButtonText.text = "준비 완료";
        }
        else
        {
            readyButtonImage.sprite = greenSprite;
            readyButtonText.text = "준비하기";
        }

        // 준비 완료 → 버튼 비활성화
        readyButton.interactable = !ready;
    }

    public void ShowCountdown(int seconds)
    {
        // 기존 코루틴 있으면 중지
        if (countdownCoroutine != null)
            StopCoroutine(countdownCoroutine);

        countdownCoroutine = StartCoroutine(CountdownRoutine(seconds));
    }

    IEnumerator CountdownRoutine(int seconds)
    {
        for (int i = seconds; i > 0; i--)
        {
            statusText.text = $"{i}초 후 게임 시작!";
            yield return new WaitForSeconds(1f);
        }

        statusText.text = "게임 시작!";
    }

    public void Open_Q_PlayingGamePanel()
    {
        q_PlayingGamePanel.SetActive(true);
    }

    public void Close_Q_PlayingGamePanel()
    {
        q_PlayingGamePanel.SetActive(false);
    }

    public void ShowOpponentDisconnected(int count, string reason)
    {
        if (opponentDisconnectPanel != null)
            opponentDisconnectPanel.SetActive(true);

        // 🔥 사유 (빨간색 적용)
        if (waitingReasonText != null)
        {
            waitingReasonText.text = $"사유 : <color=red>{reason}</color>";
        }

        // 🔥 횟수
        if (otherPlayerAwayCountText != null)
        {
            otherPlayerAwayCountText.text = $"상대방 접속 끊김 횟수 : {count}회 / 2회";
        }

        // 🔥 Header 애니메이션 시작
        if (headerAnimCoroutine != null)
            StopCoroutine(headerAnimCoroutine);

        headerAnimCoroutine = StartCoroutine(HeaderAnimation());
    }

    public void HideOpponentDisconnected()
    {
        if (opponentDisconnectPanel != null)
            opponentDisconnectPanel.SetActive(false);

        if (headerAnimCoroutine != null)
        {
            StopCoroutine(headerAnimCoroutine);
            headerAnimCoroutine = null;
        }
    }

    // 애니메이션: 상대방의 응답을 기다리고 있습니다. .. ...
    IEnumerator HeaderAnimation()
    {
        int dotCount = 0;

        while (true)
        {
            dotCount = (dotCount + 1) % 3; // 0~2

            string dots = "";
            for (int i = 0; i < dotCount; i++)
                dots += ".";

            headerText.text = baseHeader + dots;

            yield return new WaitForSeconds(1f);
        }
    }

    public void StartDisconnectTimer(int duration, double startTime)
    {
        disconnectDuration = duration;
        disconnectStartTime = startTime;
        isDisconnectTimerRunning = true;
    }

    public void StopDisconnectTimer()
    {
        isDisconnectTimerRunning = false;

        if (countdownText != null)
            countdownText.text = "";
    }
}
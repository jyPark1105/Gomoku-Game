﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class UndoTimerUI : MonoBehaviour
{
    public Image timerFillImage;
    public GameObject timerFrame;
    public TMP_Text timerText;

    float duration = 20f;
    float remaining;
    bool isRunning = false;
    double serverStartTime;

    public void StartTimer(float time, double startTime)
    {
        duration = time;
        serverStartTime = startTime;
        isRunning = true;

        timerFillImage.gameObject.SetActive(true);
        timerFrame.SetActive(true);
    }

    public void StopTimer()
    {
        isRunning = false;

        timerFillImage.gameObject.SetActive(false);
        timerFrame.SetActive(false);

        timerText.text = "";
    }

    void Update()
    {
        if (!isRunning) return;

        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        remaining = duration - (float)((now - serverStartTime) / 1000.0);

        if (remaining < 0f)
            remaining = 0f;

        timerFillImage.fillAmount = remaining / duration;

        int sec = Mathf.CeilToInt(remaining);
        timerText.text = sec.ToString();

        if (remaining <= 0f)
        {
            isRunning = false;
        }
    }
}
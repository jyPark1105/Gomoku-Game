﻿using UnityEngine;
using TMPro;
using System.Collections;

public class WinReasonUI : MonoBehaviour
{
    public GomokuManager gomokuManager;

    public GameObject root;
    public CanvasGroup canvasGroup;

    public TMP_Text titleText;
    public TMP_Text reasonText;

    public float showDuration = 5f;
    public float fadeDuration = 1f;

    int myPlayerId;

    public void Init(int myId)
    {
        myPlayerId = myId;
    }

    public void Show(int winner, string reason)
    {
        root.SetActive(true);
        canvasGroup.alpha = 1f;

        bool isWin = (winner == myPlayerId);

        titleText.text = isWin ? "대국 승리!" : "대국 패배...";

        switch (reason)
        {
            case "DISCONNECT":
                reasonText.text = isWin
                    ? "상대가 연결을 종료했습니다."
                    : "연결 종료로 인해 패배 처리되었습니다..";
                break;

            case "TIMEOUT":
                reasonText.text = isWin
                    ? "상대의 시간 초과로 인한 승리입니다!"
                    : "시간 초과로 패배했습니다..";
                break;

            default:
                reasonText.text = "";
                break;
        }

        StopAllCoroutines();
        StartCoroutine(ShowRoutine());
    }

    IEnumerator ShowRoutine()
    {
        // 5초 유지
        yield return new WaitForSeconds(showDuration);

        // Fade Out
        float t = 0f;

        while (t < 1f)
        {
            t += Time.deltaTime / fadeDuration;
            canvasGroup.alpha = 1f - t;
            yield return null;
        }

        root.SetActive(false);

        // GameEndPanel 켜기
        gomokuManager.ShowGameEndPanelPublic(true);
    }
}
﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class TypingIndicatorUI : MonoBehaviour
{
    [Header("Player Roots")]
    public GameObject player1Root;
    public GameObject player2Root;

    [Header("Dot Images")]
    public Image player1DotImage;
    public Image player2DotImage;

    [Header("Sprites")]
    public Sprite[] dotSprites;

    Coroutine p1Routine;
    Coroutine p2Routine;

    // 🔥 표시
    public void Show(int playerId)
    {
        if (playerId == 1)
        {
            player1Root.SetActive(true);

            if (p1Routine != null)
                StopCoroutine(p1Routine);

            p1Routine = StartCoroutine(Animate(player1DotImage));
        }
        else if (playerId == 2)
        {
            player2Root.SetActive(true);

            if (p2Routine != null)
                StopCoroutine(p2Routine);

            p2Routine = StartCoroutine(Animate(player2DotImage));
        }
    }

    // 🔥 숨김
    public void Hide(int playerId)
    {
        if (playerId == 1)
        {
            player1Root.SetActive(false);

            if (p1Routine != null)
            {
                StopCoroutine(p1Routine);
                p1Routine = null;
            }
        }
        else if (playerId == 2)
        {
            player2Root.SetActive(false);

            if (p2Routine != null)
            {
                StopCoroutine(p2Routine);
                p2Routine = null;
            }
        }
    }

    public void HideAll()
    {
        Hide(1);
        Hide(2);
    }

    IEnumerator Animate(Image target)
    {
        int i = 0;

        while (true)
        {
            if (dotSprites.Length == 0) yield break;

            target.sprite = dotSprites[i];
            i = (i + 1) % dotSprites.Length;

            yield return new WaitForSeconds(0.3f);
        }
    }
}
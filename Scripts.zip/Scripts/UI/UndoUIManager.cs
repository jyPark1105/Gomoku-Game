﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 🔥 무르기 관련 UI 전담
/// - 게임 시작 전 옵션 패널
/// - 요청 중 패널
/// - 게임 중 투표 패널
/// - 허용/비허용 결과 패널
/// - Fade 처리
/// </summary>
public class UndoUIManager : MonoBehaviour
{
    public UndoTimerUI undoTimerUI;

    [Header("Undo Panels")]
    public GameObject undoOptionPanel;
    public GameObject requestingUndoPanel;   // 🔥 추가
    public GameObject undoVotePanel;
    public GameObject confirmUndoPanel;
    public GameObject negativeUndoPanel;

    public Image p1OptionImage;
    public Image p2OptionImage;

    Sprite checkSprite;
    Sprite crossSprite;

    Coroutine currentRoutine;
    Coroutine outlineRoutine;

    void Start()
    {
        checkSprite = Resources.Load<Sprite>("check");   // 경로 맞춰
        crossSprite = Resources.Load<Sprite>("cross");
    }

    /// <summary>
    /// 게임 시작 전 무르기 기능 사용 여부 선택 패널 표시
    /// </summary>
    public void ShowOptionPanel()
    {
        StopCurrentRoutine();

        if (undoOptionPanel != null)
            undoOptionPanel.SetActive(true);

        ResetOptionUI();
    }

    /// <summary>
    /// 게임 시작 전 무르기 기능 사용 여부 선택 패널 숨김
    /// </summary>
    public void HideOptionPanel()
    {
        if (undoOptionPanel != null)
            undoOptionPanel.SetActive(false);
    }

    public void UpdateOptionState(int playerId, bool? agree)
    {
        Image target = (playerId == 1) ? p1OptionImage : p2OptionImage;

        if (target == null) return;

        if (agree == null)
        {
            target.sprite = null;
            target.enabled = false; // None 상태
            return;
        }

        target.enabled = true;

        if (agree.Value)
            target.sprite = checkSprite;
        else
            target.sprite = crossSprite;
    }

    public void ResetOptionUI()
    {
        UpdateOptionState(1, null);
        UpdateOptionState(2, null);
    }

    // 요청 직후 UI 띄우기
    public void ShowRequestingPanel()
    {
        StopCurrentRoutine();

        if (requestingUndoPanel != null)
            requestingUndoPanel.SetActive(true);

        // ❌ 타이머 시작하면 안됨
    }

    /// <summary>
    /// 서버 응답 후 → 내가 상대에게 무르기 요청 후 대기 중일 때 표시
    /// </summary>
    public void ShowRequestingPanel(double startTime)
    {
        StopCurrentRoutine();

        if (requestingUndoPanel != null)
            requestingUndoPanel.SetActive(true);

        undoTimerUI.StartTimer(20f, startTime);
    }

    /// <summary>
    /// 요청 중 패널 숨김
    /// </summary>
    public void HideRequestingPanel()
    {
        if (requestingUndoPanel != null)
            requestingUndoPanel.SetActive(false);

        undoTimerUI.StopTimer();
    }

    /// <summary>
    /// 상대가 내게 무르기 요청했을 때 투표 패널 표시
    /// </summary>
    public void ShowVotePanel(double startTime)
    {
        StopCurrentRoutine();

        if (undoVotePanel != null)
            undoVotePanel.SetActive(true);

        undoTimerUI.StartTimer(20f, startTime);
    }

    /// <summary>
    /// 무르기 허용 여부 투표 패널 숨김
    /// </summary>
    public void HideVotePanel()
    {
        if (undoVotePanel != null)
            undoVotePanel.SetActive(false);

        undoTimerUI.StopTimer();
    }

    /// <summary>
    /// 결과 패널 표시
    /// true  -> ConfirmUndoPanel
    /// false -> NegativeUndoPanel
    /// </summary>
    public void ShowResult(bool enabled)
    {
        StopCurrentRoutine();

        GameObject panel = enabled ? confirmUndoPanel : negativeUndoPanel;

        if (panel == null)
            return;

        currentRoutine = StartCoroutine(ShowResultRoutine(panel));
    }

    IEnumerator ShowResultRoutine(GameObject panel)
    {
        CanvasGroup cg = panel.GetComponent<CanvasGroup>();

        panel.SetActive(true);

        if (cg != null)
            cg.alpha = 1f;

        yield return new WaitForSeconds(2f);

        yield return StartCoroutine(FadeOut(panel, cg));

        currentRoutine = null;
    }

    IEnumerator FadeOut(GameObject panel, CanvasGroup cg)
    {
        float t = 0f;

        while (t < 1f)
        {
            t += Time.deltaTime * 2f;

            if (cg != null)
                cg.alpha = 1f - t;

            yield return null;
        }

        if (panel != null)
            panel.SetActive(false);

        if (cg != null)
            cg.alpha = 1f;
    }

    void StopCurrentRoutine()
    {
        if (currentRoutine != null)
        {
            StopCoroutine(currentRoutine);
            currentRoutine = null;
        }
    }

    /// <summary>
    /// 외부에서 강제 초기화할 때 사용
    /// </summary>
    public void ResetUI()
    {
        StopCurrentRoutine();

        if (undoOptionPanel != null)
            undoOptionPanel.SetActive(false);

        if (requestingUndoPanel != null)
            requestingUndoPanel.SetActive(false);

        if (undoVotePanel != null)
            undoVotePanel.SetActive(false);

        ResetPanel(confirmUndoPanel);
        ResetPanel(negativeUndoPanel);
    }

    void ResetPanel(GameObject panel)
    {
        if (panel == null) return;

        CanvasGroup cg = panel.GetComponent<CanvasGroup>();
        if (cg != null)
            cg.alpha = 1f;

        panel.SetActive(false);
    }
}
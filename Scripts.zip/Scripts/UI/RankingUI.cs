﻿using TMPro;
using UnityEngine;

public class RankingUI : MonoBehaviour
{
    public GameObject gameStartPanel;
    public GameObject rankingPanel;
    
    public Transform content;
    public GameObject rankingItemPrefab;

    public TMP_Text rankFilterText;

    RankingUser[] currentUsers;

    bool isRateMode = false; // 🔥 기본: 급순

    // 🔥 서버에서 받으면 호출
    public void SetRanking(RankingUser[] users)
    {
        currentUsers = users;

        Refresh();
    }

    public void OnClickOpenRanking()
    {
        gameStartPanel.SetActive(false);
        rankingPanel.SetActive(true);

        var packet = new BasePacket
        {
            type = "GET_RANKING"
        };

        Debug.Log("GET_RANKING 패킷 전달 완료: 클라 → 서버");

        string json = JsonUtility.ToJson(packet);

        NetworkController.Instance.Send(json);
    }

    // 🔥 토글 버튼
    public void OnClickToggleSort()
    {
        isRateMode = !isRateMode; // 🔥 토글

        Refresh();
    }

    public void OnClickBack()
    {
        rankingPanel.SetActive(false);
        gameStartPanel.SetActive(true);

        ResetMode(); // 🔥 상태 초기화
    }

    void ResetMode()
    {
        isRateMode = false;
    }

    void Refresh()
    {
        if (currentUsers == null) return;

        // 🔥 필터 텍스트 갱신
        if (rankFilterText != null)
        {
            rankFilterText.text = isRateMode ? "승률순" : "티어순";
        }

        // 🔥 복사해서 정렬
        var list = new System.Collections.Generic.List<RankingUser>(currentUsers);

        if (isRateMode)
        {
            // 🔥 승률순
            list.Sort((a, b) =>
            {
                float rateA = GetRate(a);
                float rateB = GetRate(b);

                return rateB.CompareTo(rateA);
            });
        }
        else
        {
            // 🔥 티어순
            list.Sort((a, b) =>
            {
                return b.tier.CompareTo(a.tier);
            });
        }

        // 🔥 UI 초기화
        foreach (Transform child in content)
            Destroy(child.gameObject);

        // 🔥 TOP 10만
        int count = Mathf.Min(10, list.Count);

        for (int i = 0; i < count; i++)
        {
            var go = Instantiate(rankingItemPrefab, content);
            var item = go.GetComponent<RankingItemUI>();

            item.Set(
                i + 1,
                list[i].nickname,
                list[i].avatarIndex,
                list[i].win,
                list[i].lose,
                list[i].tier
            );
        }
    }

    float GetRate(RankingUser u)
    {
        int total = u.win + u.lose;
        if (total == 0) return 0;
        return u.win / (float)total;
    }
}
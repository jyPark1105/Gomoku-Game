﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public enum GameMode
{
    Practice,   // 혼자
    VS_AI,      // AI 대전
    Online      // 온라인
}

public class GameStartUI : MonoBehaviour
{
    public LobbyUIManager lobbyUIManager;
    public GomokuManager gomokuManager;

    public GameObject startPanel;
    public GameObject roomUIRoot;
    public GameObject inGameUI;

    public Image backgroundPanel;

    public Button[] roomButtons;        // 버튼
    public TMP_Text[] roomCountText;    // N / 2
    public TMP_Text[] roomButtonTexts;  // "입장하기"

    public GameObject loadingPanel;
    public TMP_Text timeText;           // 턴 시간 UI 표시
    public int selectedTurnTime = 60;   // 기본값
    public Button leftButton;
    public Button rightButton;
    bool isUpdatingRoom = false;

    Coroutine currentRoutine;

    WaitForSeconds sec1_delay = new WaitForSeconds(1f);

    void Start()
    {
        SetRoomButtons(false);
    }

    public void SelectPractice()
    {
        AudioManager.Instance.PlayClick();

        gomokuManager.SetGameMode(GameMode.Practice);

        startPanel.SetActive(false);
        roomUIRoot.SetActive(true);
    }

    public void SelectBeginner()
    {
        AudioManager.Instance.PlayClick();
        StartGame(AIDifficulty.Beginner);
    }

    public void SelectAdvanced()
    {
        AudioManager.Instance.PlayClick();
        StartGame(AIDifficulty.Advanced);
    }

    public void SetRoomButtons(bool enable)
    {
        for (int i = 0; i < roomButtons.Length; i++)
        {
            roomButtons[i].interactable = enable;

            if (roomButtonTexts != null && i < roomButtonTexts.Length)
            {
                roomButtonTexts[i].text = enable ? "입장하기" : "서버 연결 중...";
            }
        }
    }

    void StartGame(AIDifficulty difficulty)
    {
        gomokuManager.SetGameMode(GameMode.VS_AI);
        gomokuManager.SetDifficulty(difficulty);

        startPanel.SetActive(false);
        roomUIRoot.SetActive(true);
    }

    public void JoinRoom(int roomNumber)
    {
        AudioManager.Instance.PlayClick();

        // 🔥 업데이트 중이면 막기
        if (isUpdatingRoom)
        {
            Debug.Log("⏳ 업데이트 중 - 입장 차단");
            return;
        }

        gomokuManager.SetGameMode(GameMode.Online);

        // 이미 연결되어 있음 → 바로 입장 시도 → room 번호 저장
        gomokuManager.RequestJoinRoom(roomNumber);

        // 실제 입장
        StartCoroutine(JoinRoomAfterProfile(roomNumber));

        StartCoroutine(FadeBackground());

        // 우선 UI 전환
        startPanel.SetActive(false);
        roomUIRoot.SetActive(true);
        inGameUI.SetActive(true);
    }

    IEnumerator JoinRoomAfterProfile(int roomId)
    {
        yield return new WaitForSeconds(0.1f); // 🔥 핵심

        NetworkController.Instance.JoinRoom(roomId, selectedTurnTime);
    }

    public void UpdateRoomList(RoomInfoPacket[] rooms)
    {
        // 🔥 전체 초기화 (핵심)
        for (int i = 0; i < roomCountText.Length; i++)
        {
            roomCountText[i].text = "0 / 2";
        }

        // 🔥 받은 값으로 덮어쓰기
        foreach (var room in rooms)
        {
            int index = room.roomId - 1;

            if (index >= 0 && index < roomCountText.Length)
            {
                roomCountText[index].text =
                    $"{room.playerCount} / {room.maxPlayers}";
            }
        }
    }

    public void OnClickLeft()
    {
        if (isUpdatingRoom)
        {
            Debug.Log("⛔ 업데이트 중 - 무시");
            return;
        }

        if (selectedTurnTime == 60) selectedTurnTime = 30;
        else if (selectedTurnTime == 90) selectedTurnTime = 60;
        else if (selectedTurnTime == 120) selectedTurnTime = 90;

        UpdateTimeUI();
    }

    public void OnClickRight()
    {
        if (isUpdatingRoom)
        {
            Debug.Log("⛔ 업데이트 중 - 무시");
            return;
        }

        if (selectedTurnTime == 30) selectedTurnTime = 60;
        else if (selectedTurnTime == 60) selectedTurnTime = 90;
        else if (selectedTurnTime == 90) selectedTurnTime = 120;

        UpdateTimeUI();
    }

    public void RequestInitialRoomList()
    {
        UpdateTimeUI(); // 👉 내부에서 서버 요청까지 같이 감
    }

    // UI 갱신
    void UpdateTimeUI()
    {
        if (isUpdatingRoom)
        {
            Debug.Log("⛔ UpdateTimeUI 차단");
            return;
        }

        timeText.text = selectedTurnTime.ToString();

        if (currentRoutine != null)
            StopCoroutine(currentRoutine);

        currentRoutine = StartCoroutine(RoomUpdateRoutine());
    }

    void SetTimeButtons(bool enable)
    {
        // 좌우 버튼이 따로 있다면 연결
        leftButton.interactable = enable;
        rightButton.interactable = enable;
    }

    IEnumerator RoomUpdateRoutine()
    {
        // 방 업데이트 중
        isUpdatingRoom = true;

        // 턴 시간 제한 업데이트 막기
        SetTimeButtons(false);

        // 🔥 UI 막기
        loadingPanel.SetActive(true);

        // 🔥 서버 값 요청
        NetworkController.Instance.RequestRoomList(selectedTurnTime);

        yield break;
    }

    public void OnRoomInfoReceived()
    {
        if (!gameObject.activeInHierarchy)
            return;

        if (currentRoutine != null)
        {
            StopCoroutine(currentRoutine);
            currentRoutine = null;
        }

        isUpdatingRoom = false;

        // 🔥 2프레임 안정화 후 끄기
        StartCoroutine(DisableLoadingNextFrame());
    }

    IEnumerator DisableLoadingNextFrame()
    {
        // 1프레임
        yield return null;

        // 2프레임 (모바일 안정화)
        yield return null;

        // 모바일 안정화 완료 → UX 고려하여 1초 딜레이한 후 UI 띄우기
        yield return sec1_delay;

        // UI 풀기
        loadingPanel.SetActive(false);
        // 턴 시간 제한 업데이트 풀기
        SetTimeButtons(true);
    }

    public IEnumerator FadeBackground()
    {
        float t = 0f;

        while (t < 1f)
        {
            t += Time.deltaTime * 2f;
            SetAlpha(t);
            yield return null;
        }

        while (t > 0f)
        {
            t -= Time.deltaTime * 2f;
            SetAlpha(t);
            yield return null;
        }
    }

    void SetAlpha(float a)
    {
        var c = backgroundPanel.color;
        c.a = a;
        backgroundPanel.color = c;
    }
}
using TMPro;
using UnityEngine;

public class DateHeaderUI : MonoBehaviour
{
    public TMP_Text dateHeaderText;

    public void Set(string text, int fontSize)
    {
        dateHeaderText.text = text;
        dateHeaderText.fontSize = fontSize;
    }
}
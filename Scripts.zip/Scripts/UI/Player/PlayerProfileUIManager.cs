﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerProfileUIManager : MonoBehaviour
{
    public static PlayerProfileUIManager Instance;

    [Header("UI References")]
    public TMP_Text nameText;
    public Image avatarImage;

    public TMP_Text winLoseRateText;

    public TMP_Text tierText;

    [Header("Tier Frame")]
    public Image tierFrame; // 🔥 추가

    // 🔥 캐싱
    Sprite gradeBronze, gradeSilver, gradeGold;
    Sprite danBronze, danSilver, danGold;

    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        LoadTierSprites(); // 🔥 한 번만 로드
    }

    void Start()
    {
        RefreshUI();
    }

    void LoadTierSprites()
    {
        gradeBronze = Resources.Load<Sprite>("Player/grade_bronze");
        gradeSilver = Resources.Load<Sprite>("Player/grade_silver");
        gradeGold = Resources.Load<Sprite>("Player/grade_gold");

        danBronze = Resources.Load<Sprite>("Player/dan_bronze");
        danSilver = Resources.Load<Sprite>("Player/dan_silver");
        danGold = Resources.Load<Sprite>("Player/dan_gold");
    }

    public void RefreshUI()
    {
        var profile = PlayerProfile.Instance;

        if (profile == null)
        {
            Debug.LogWarning("PlayerProfile 없음");
            return;
        }

        // 이름
        if (nameText != null)
            nameText.text = profile.nickname;

        // 아바타
        if (avatarImage != null)
        {
            var sprite = Resources.Load<Sprite>($"Avatars/avatar_{profile.avatarIndex}");
            if (sprite != null)
                avatarImage.sprite = sprite;
        }

        // 🔥 승패 + 승률 + 색상
        if (winLoseRateText != null)
        {
            int total = profile.win + profile.lose;
            float rate = total > 0 ? (profile.win / (float)total) * 100f : 0f;

            if (total == 0)
            {
                winLoseRateText.text = "0승 0패 (-)";
                winLoseRateText.color = Color.gray;
            }
            else
            {
                winLoseRateText.text = $"{profile.win}승 {profile.lose}패 ({rate:F1}%)";
                winLoseRateText.color = GetRateColor(rate); // 🔥 핵심
            }
        }

        // 🔥 티어 텍스트
        int tierValue = profile.tier;
        if (tierText != null)
            tierText.text = GetTierText(tierValue);

        // 🔥 프레임 적용
        if (tierFrame != null)
            tierFrame.sprite = GetTierFrameSprite(tierValue);
    }

    // 🔥 승률 색상
    Color GetRateColor(float rate)
    {
        if (rate >= 70f) return Color.green;
        if (rate >= 50f) return Color.yellow;
        return Color.red;
    }

    // 🔥 티어 계산 (점수 기반)
    string GetTierText(int score)
    {
        int tier = Mathf.Clamp(10 - (score / 100), 1, 10);

        if (score < 1000)
        {
            return $"{tier}급";
        }
        else
        {
            int dan = (score - 1000) / 100 + 1;
            return $"{dan}단";
        }
    }

    // 🔥 프레임 선택
    Sprite GetTierFrameSprite(int score)
    {
        if (score < 1000)
        {
            int tier = Mathf.Clamp(10 - (score / 100), 1, 10);

            if (tier >= 7) return gradeBronze;
            if (tier >= 4) return gradeSilver;
            return gradeGold;
        }
        else
        {
            int dan = (score - 1000) / 100 + 1;

            if (dan <= 3) return danBronze;
            if (dan <= 6) return danSilver;
            return danGold;
        }
    }
}
﻿using UnityEngine;

public class PlayerProfile : MonoBehaviour
{
    public static PlayerProfile Instance;

    public string uid;
    public string nickname;
    public int avatarIndex;

    public int win;
    public int lose;
    public int tier;

    void Awake()
    {
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void SetProfile(string uid, string name, int avatar, int win, int lose, int tier)
    {
        this.uid = uid;
        this.nickname = name;
        this.avatarIndex = avatar;

        this.win = win;
        this.lose = lose;
        this.tier = tier;
    }
}
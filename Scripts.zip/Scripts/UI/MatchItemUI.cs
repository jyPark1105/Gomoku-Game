﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MatchItemUI : MonoBehaviour
{
    [Header("Players")]
    public GameObject player1;
    public GameObject player2;

    public Image player1Avatar;
    public TMP_Text player1Name;

    public Image player2Avatar;
    public TMP_Text player2Name;

    [Header("Info")]
    public TMP_Text dateText;
    public TMP_Text moveCountText;

    [Header("Result")]
    public Image resultImage;   // ResultTextFrame
    public TMP_Text resultText; // ResultText

    private Sprite winSprite;
    private Sprite loseSprite;

    private MatchDataPacket data;
    private GomokuManager gomoku;

    // 🔥 초기화
    public void SetupFromList(MatchListItemPacket match, GomokuManager manager)
    {
        gomoku = manager;

        // 날짜
        dateText.text = FormatDate(match.startedAt);

        // 수
        moveCountText.text = $"전체 대국 수 : {match.moveCount}수";

        // 플레이어
        var p1 = match.players[0];
        var p2 = match.players[1];
        player1Name.text = p1.nickname;
        player2Name.text = p2.nickname;
        player1Avatar.sprite = LoadAvatar(p1.avatarIndex);
        player2Avatar.sprite = LoadAvatar(p2.avatarIndex);

        // 리소스
        if (winSprite == null)
            winSprite = Resources.Load<Sprite>("MatchHistory/match_history_win_green");

        if (loseSprite == null)
            loseSprite = Resources.Load<Sprite>("MatchHistory/match_history_lose_red");

        // 승패
        int myId = gomoku.GetMyPlayerIdPublic();
        bool isWin = (match.winner == myId);

        // 승패 UI 표시
        resultImage.sprite = isWin ? winSprite : loseSprite;
        resultText.text = isWin ? "승" : "패";

        // Outline
        SetOutline(player1, false);
        SetOutline(player2, false);

        if (match.winner == 1)
            SetOutline(player1, true);
        else if (match.winner == 2)
            SetOutline(player2, true);

        // 🔥 핵심: matchId 저장
        data = new MatchDataPacket
        {
            matchId = match.matchId
        };

        // 버튼 컴포넌트 온클릭 등록
        var button = GetComponent<Button>();
        if (button != null)
        {
            button.onClick.RemoveAllListeners();
            button.onClick.AddListener(OnClickItem);
        }
    }

    // 🔥 패널 클릭 → 복기
    public void OnClickItem()
    {
        if (data == null) return;

        Debug.Log("📡 복기 요청: " + data.matchId);

        NetworkController.Instance.RequestMatchData(data.matchId);
    }

    // ------------------------
    // 유틸
    // ------------------------
    string FormatDate(long timestamp) 
    { 
        var date = DateTimeOffset.FromUnixTimeMilliseconds(timestamp)
                    .ToOffset(TimeSpan.FromHours(9))
                    .DateTime;

        return date.ToString("yy/MM/dd HH:mm:ss"); 
    }

    void SetOutline(GameObject target, bool enable)
    {
        var outline = target.GetComponent<UIOutline>();
        if (outline != null)
            outline.enabled = enable;
    }

    Sprite LoadAvatar(int index)
    {
        return Resources.Load<Sprite>($"Avatars/avatar_{index}");
    }

}
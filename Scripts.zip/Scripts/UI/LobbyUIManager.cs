﻿using UnityEngine;
using UnityEngine.UI;

public class LobbyUIManager : MonoBehaviour
{
    [Header("Refs")]
    public GameStartUI gameStartUI;
    public LobbyNameUI nameUI;

    [Header("Root Panels")]
    public GameObject gameStartPanel;       // 방 리스트 포함 로비 화면
    public GameObject lobbyPanel;           // 처음 시작 화면
    public GameObject roomUIRoot;           // 방 내부 화면
    public GameObject matchHistoryPanel;    // 대국 기록 화면

    [Header("Lobby Name Panel")]
    public GameObject namePanel;
    public GameObject avatarPanel;
    [Header("Confirm Nickname Panel")]
    public GameObject confirmNicknamePanel;

    public Button useNicknameButton;
    public Button cancelNicknameButton;

    private void Start()
    {
        // 기본 시작 상태
        gameStartPanel.SetActive(false);
        lobbyPanel.SetActive(true);
        roomUIRoot.SetActive(false);
        matchHistoryPanel.SetActive(false);

        // 🔥 바로 프로필 입력 시작
        namePanel.SetActive(true);
        confirmNicknamePanel.SetActive(false);

        avatarPanel.SetActive(false);
    }

    /// <summary>
    /// 게임 시작 → 닉네임 & 초상화 설정
    /// </summary>
    public void EnterOnlineLobby()
    {
        gameStartPanel.SetActive(false);
        lobbyPanel.SetActive(true);
        roomUIRoot.SetActive(false);

        // 프로필 설정 시작
        namePanel.SetActive(true);
        avatarPanel.SetActive(false);

        // 아직 방 리스트는 요청하지 않음
    }

    /// <summary>
    /// 사용하기 버튼
    /// </summary>
    /// <param name="name"></param>
    public void OnClickUseNickname()
    {
        // 🔥 버튼 잠금 (중복 클릭 방지)
        if (useNicknameButton != null)
            useNicknameButton.interactable = false;

        if (cancelNicknameButton != null)
            cancelNicknameButton.interactable = false;

        string name = nameUI.currentInputName;

        PlayerProfile.Instance.nickname = name;

        // 🔥 즉시 닫기
        confirmNicknamePanel.SetActive(false);
        namePanel.SetActive(false);

        avatarPanel.SetActive(true);
    }

    /// <summary>
    /// 사용 안 하기 버튼
    /// </summary>
    public void OnClickCancelNickname()
    {
        // 🔥 서버에 예약 취소
        NetworkController.Instance.SendCancelNickname(nameUI.currentInputName);

        if (useNicknameButton != null)
            useNicknameButton.interactable = false;

        if (cancelNicknameButton != null)
            cancelNicknameButton.interactable = false;

        confirmNicknamePanel.SetActive(false);

        nameUI.ResetConfirmState();
    }

    public void ShowConfirmNicknamePanel()
    {
        confirmNicknamePanel.SetActive(true);

        // 🔥 버튼 초기화
        if (useNicknameButton != null)
            useNicknameButton.interactable = true;

        if (cancelNicknameButton != null)
            cancelNicknameButton.interactable = true;
    }

    public void HideConfirmNicknamePanel()
    {
        confirmNicknamePanel.SetActive(false);
    }

    /// <summary>
    /// 초상화 선택 완료
    /// </summary>
    public void OnAvatarSelected()
    {
        avatarPanel.SetActive(false);

        // 이제 방 리스트 요청
        gameStartUI.RequestInitialRoomList();
    }

    /// <summary>
    /// 초상화 확정 완료
    /// </summary>
    public void OnAvatarConfirmed()
    {
        // 🔥 로비 끄기
        lobbyPanel.SetActive(false);

        // 🔥 게임 시작 패널 켜기
        gameStartPanel.SetActive(true);

        // 필요하면 방 내부 UI 끄기
        roomUIRoot.SetActive(false);
    }

    /// <summary>
    /// 인게임 진입 시
    /// </summary>
    public void EnterInGame()
    {
        gameStartPanel.SetActive(false);
        lobbyPanel.SetActive(false);
        roomUIRoot.SetActive(true);
    }

    /// <summary>
    /// 방에서 나오면 다시 로비로
    /// </summary>
    public void ReturnToLobby()
    {
        gameStartPanel.SetActive(false);
        lobbyPanel.SetActive(true);
        roomUIRoot.SetActive(false);

        namePanel.SetActive(false);
        avatarPanel.SetActive(false);
    }

    /// <summary>
    /// 게임 시작 화면으로 완전히 돌아가기
    /// </summary>
    public void ReturnToStartPanel()
    {
        gameStartPanel.SetActive(true);
        lobbyPanel.SetActive(false);
        roomUIRoot.SetActive(false);

        namePanel.SetActive(false);
        avatarPanel.SetActive(false);
    }
}
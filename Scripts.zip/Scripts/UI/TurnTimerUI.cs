﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;

public class TurnTimerUI : MonoBehaviour
{
    [Header("Timer")]
    public Image timerFillImage;     // Filled / Horizontal / Origin Right
    public GameObject timerFrame;    // 부모 프레임
    public TMP_Text timerText;

    [Header("Board Timer (Only Allocate to Player Panel 1")]
    public Image boardFillImage;    // Filled / Vertical / Origin Bottom

    [Header("Miss Icons (Player's State Layout)")]
    public GameObject[] missIcons;   // 0,1,2

    double serverStartTime;          // 서버 기준 턴 시작 시각 (ms)
    float turnTimeLimit = 60f;       // 턴 제한 시간 (sec)
    float remainingTime = 60f;

    bool isRunning = false;
    int lastShownSecond = -1;

    // Horizontal, Player Panel
    Sprite normalSprite;
    Sprite dangerSprite;
    Sprite normalSpriteVertical;
    Sprite dangerSpriteVertical;

    bool isDangerState = false;
    bool isTickPlaying = false;

    void Update()
    {
        if (!isRunning) return;

        // 🔥 서버 기준 시간으로 매 프레임 다시 계산
        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        remainingTime = turnTimeLimit - (float)((now - serverStartTime) / 1000.0);

        if (remainingTime < 0f)
            remainingTime = 0f;

        // 🔥 Player Panel: 바 감소
        if (timerFillImage != null && turnTimeLimit > 0f)
        {
            timerFillImage.fillAmount = Mathf.Clamp01(remainingTime / turnTimeLimit);
        }

        // 🔥 Board Panel: 바 감소
        if (boardFillImage != null && turnTimeLimit > 0f)
        {
            boardFillImage.fillAmount =
                Mathf.Clamp01(remainingTime / turnTimeLimit);
        }

        int sec = Mathf.CeilToInt(remainingTime);

        // 🔥 15초 기준 상태 변경(Text UI 띄우기)
        if (remainingTime <= 15f)
        {
            if (!isDangerState)
            {
                isDangerState = true;

                if (timerFillImage != null && dangerSprite != null)
                    timerFillImage.sprite = dangerSprite;

                if (boardFillImage != null && dangerSpriteVertical != null)
                    boardFillImage.sprite = dangerSpriteVertical;

                if (timerFrame != null && !timerFrame.activeSelf)
                    timerFrame.SetActive(true);
            }

            if (timerText != null)
            {
                if (sec != lastShownSecond)
                {
                    timerText.text = sec.ToString();
                    lastShownSecond = sec;
                }
            }
        }
        else
        {
            if (isDangerState)
            {
                isDangerState = false;

                if (timerFillImage != null && normalSprite != null)
                    timerFillImage.sprite = normalSprite;

                if (boardFillImage != null && normalSpriteVertical != null)
                    boardFillImage.sprite = normalSpriteVertical;
            }

            if (timerFrame != null && timerFrame.activeSelf)
                timerFrame.SetActive(false);

            if (timerText != null)
                timerText.text = "";
        }

        // 🔥 15초 이하부터 tick
        if (remainingTime <= 15f && remainingTime > 0f)
        {
            if (!isTickPlaying)
            {
                isTickPlaying = true;
                AudioManager.Instance.StartTickLoop();
            }
        }
        else
        {
            if (isTickPlaying)
            {
                isTickPlaying = false;
                AudioManager.Instance.StopTickLoop();
            }
        }

        if (remainingTime <= 0f)
        {
            isRunning = false;

            if (isTickPlaying)
            {
                isTickPlaying = false;
                AudioManager.Instance.StopTickLoop();
            }
        }
    }

    public bool IsActive()
    {
        if (timerFillImage == null) return false;
        return timerFillImage.gameObject.activeSelf;
    }

    public void Init(float limit)
    {
        turnTimeLimit = limit;
        remainingTime = limit;
        serverStartTime = 0;
        lastShownSecond = -1;
        isRunning = false;

        // 🔥 최초 1회 로드
        if (normalSprite == null)
            normalSprite = Resources.Load<Sprite>("turn_timer_bar_horizontal");

        if (normalSpriteVertical == null)
            normalSpriteVertical = Resources.Load<Sprite>("turn_timer_bar_vertical");

        if (dangerSprite == null)
            dangerSprite = Resources.Load<Sprite>("turn_timer_bar_under_15sec_horizontal");

        if (dangerSpriteVertical == null)
            dangerSpriteVertical = Resources.Load<Sprite>("turn_timer_bar_under_15sec_vertical");

        if (timerFillImage != null)
        {
            timerFillImage.sprite = normalSprite;
            timerFillImage.fillAmount = 1f;
            timerFillImage.gameObject.SetActive(false);
        }

        if (boardFillImage != null)
        {
            boardFillImage.sprite = normalSpriteVertical;
            boardFillImage.fillAmount = 1f;
            boardFillImage.gameObject.SetActive(false);
        }

        if (timerFrame != null)
            timerFrame.SetActive(false);

        if (timerText != null)
            timerText.text = "";

        isDangerState = false;

        SetMissCount(0);
    }

    /// <summary>
    /// 기존 로컬 시작 방식
    /// 필요하면 유지하되, 온라인에서는 StartTurnWithServerTime 사용 권장
    /// </summary>
    public void StartTurn(float limit)
    {
        turnTimeLimit = limit;
        remainingTime = limit;

        // 🔥 현재 시각을 기준으로 로컬 시작
        serverStartTime = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        lastShownSecond = -1;
        isRunning = true;
        isDangerState = false;

        if (timerFillImage != null)
        {
            timerFillImage.gameObject.SetActive(true);
            timerFillImage.fillAmount = 1f;

            if (normalSprite != null)
                timerFillImage.sprite = normalSprite;
        }

        if (timerFrame != null)
            timerFrame.SetActive(false);

        if (timerText != null)
            timerText.text = "";
    }

    /// <summary>
    /// 🔥 서버 기준 시작 시각으로 타이머 시작
    /// serverStartTimeMs: 서버가 내려준 턴 시작 시각 (Unix ms)
    /// </summary>
    public void StartTurnWithServerTime(float limit, double serverStartTimeMs)
    {
        turnTimeLimit = limit;
        serverStartTime = serverStartTimeMs;

        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        remainingTime = turnTimeLimit - (float)((now - serverStartTime) / 1000.0);
        if (remainingTime < 0f)
            remainingTime = 0f;

        lastShownSecond = -1;
        isRunning = true;
        isDangerState = false;

        if (timerFillImage != null)
        {
            timerFillImage.gameObject.SetActive(true);
            timerFillImage.fillAmount = turnTimeLimit > 0f
                ? Mathf.Clamp01(remainingTime / turnTimeLimit)
                : 0f;

            if (normalSprite != null)
                timerFillImage.sprite = normalSprite;
        }

        if (boardFillImage != null)
        {
            boardFillImage.gameObject.SetActive(true);
            boardFillImage.fillAmount = turnTimeLimit > 0f
                ? Mathf.Clamp01(remainingTime / turnTimeLimit)
                : 0f;

            if (normalSpriteVertical != null)
                boardFillImage.sprite = normalSpriteVertical;
        }

        if (timerFrame != null)
            timerFrame.SetActive(remainingTime <= 15f);

        if (timerText != null)
            timerText.text = remainingTime <= 15f
                ? Mathf.CeilToInt(remainingTime).ToString()
                : "";
    }

    /// <summary>
    /// 🔥 재접속 복구용
    /// 남은 시간만 알고 있을 때 서버 시작 시각을 역산해서 설정
    /// </summary>
    public void StartTurnFromRemaining(float limit, float remaining)
    {
        turnTimeLimit = limit;
        remainingTime = Mathf.Clamp(remaining, 0f, limit);

        // 🔥 현재 시각 기준으로 서버 시작 시각 역산
        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        serverStartTime = now - ((turnTimeLimit - remainingTime) * 1000.0);

        lastShownSecond = -1;
        isRunning = true;
        isDangerState = false;

        if (timerFillImage != null)
        {
            timerFillImage.gameObject.SetActive(true);
            timerFillImage.fillAmount = turnTimeLimit > 0f
                ? Mathf.Clamp01(remainingTime / turnTimeLimit)
                : 0f;

            if (normalSprite != null)
                timerFillImage.sprite = normalSprite;
        }

        if (timerFrame != null)
            timerFrame.SetActive(remainingTime <= 15f);

        if (timerText != null)
            timerText.text = remainingTime <= 15f
                ? Mathf.CeilToInt(remainingTime).ToString()
                : "";
    }

    public void StopTurn()
    {
        if (isTickPlaying)
        {
            isTickPlaying = false;
            AudioManager.Instance.StopTickLoop();
        }

        isRunning = false;

        if (timerFillImage != null && timerFillImage.gameObject.activeSelf)
            timerFillImage.gameObject.SetActive(false);

        if (boardFillImage != null && boardFillImage.gameObject.activeSelf)
            boardFillImage.gameObject.SetActive(false);

        if (timerFrame != null && timerFrame.activeSelf)
            timerFrame.SetActive(false);

        if (timerText != null)
            timerText.text = "";
    }

    public void SetMissCount(int count)
    {
        if (missIcons == null) return;

        for (int i = 0; i < missIcons.Length; i++)
        {
            if (missIcons[i] != null)
                missIcons[i].SetActive(i < count);
        }
    }

    public void HideTimer()
    {
        if (isTickPlaying)
        {
            isTickPlaying = false;
            AudioManager.Instance.StopTickLoop();
        }

        if (!isRunning && timerFillImage != null && 
            !timerFillImage.gameObject.activeSelf &&
            (boardFillImage == null || !boardFillImage.gameObject.activeSelf))
            return;

        isRunning = false;

        if (timerFillImage != null && timerFillImage.gameObject.activeSelf)
            timerFillImage.gameObject.SetActive(false);

        if (boardFillImage != null && boardFillImage.gameObject.activeSelf)
            boardFillImage.gameObject.SetActive(false);

        if (timerFrame != null && timerFrame.activeSelf)
            timerFrame.SetActive(false);

        if (timerText != null)
            timerText.text = "";
    }

    public float GetRemainingTime()
    {
        return remainingTime;
    }

    public double GetServerStartTime()
    {
        return serverStartTime;
    }
}
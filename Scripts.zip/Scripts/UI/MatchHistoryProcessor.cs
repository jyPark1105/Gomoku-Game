using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public enum TimeFilter
{
    Daily = 0,
    Weekly = 1,
    Monthly = 2
}

public enum ResultFilter
{
    All = 0,
    Win = 1,
    Lose = 2
}

[System.Serializable]
public class MatchFilterOption
{
    public TimeFilter timeFilter = TimeFilter.Daily;
    public ResultFilter resultFilter = ResultFilter.All;
}

public class MatchStats
{
    public int total;
    public int win;
    public int lose;
    public float winRate;
    public float avgMove;
    public int currentWinStreak;
    public int maxWinStreak;
}

public class MatchHistoryProcessor
{
    public static List<MatchListItemPacket> ApplyFilter(
        List<MatchListItemPacket> matches,
        MatchFilterOption option,
        int myPlayerId)
    {
        var filtered = matches
            .Where(m =>
                IsInTimeRange(m, option.timeFilter) &&
                IsMatchResult(m, option.resultFilter, myPlayerId)
            )
            .OrderByDescending(m => m.startedAt)
            .Take(30)
            .ToList();

        return filtered;
    }

    static bool IsInTimeRange(MatchListItemPacket match, TimeFilter filter)
    {
        DateTime matchTime = DateTimeOffset
            .FromUnixTimeMilliseconds(match.startedAt)
            .LocalDateTime;

        DateTime now = DateTime.Now;

        switch (filter)
        {
            case TimeFilter.Daily:
                return matchTime.Date == now.Date;

            case TimeFilter.Weekly:
                return (now - matchTime).TotalDays <= 7;

            case TimeFilter.Monthly:
                return (now - matchTime).TotalDays <= 30;
        }

        return true;
    }

    static bool IsMatchResult(MatchListItemPacket match, ResultFilter filter, int myId)
    {
        if (filter == ResultFilter.All)
            return true;

        bool isWin = (match.winner == myId);

        if (filter == ResultFilter.Win)
            return isWin;

        if (filter == ResultFilter.Lose)
            return !isWin;

        return true;
    }

    public static MatchStats CalculateStats(List<MatchListItemPacket> matches, int myId)
    {
        MatchStats stats = new MatchStats();

        stats.total = matches.Count;

        int totalMoves = 0;
        int currentStreak = 0;
        int maxStreak = 0;

        foreach (var m in matches)
        {
            bool isWin = (m.winner == myId);

            if (isWin)
            {
                stats.win++;
                currentStreak++;
            }
            else
            {
                stats.lose++;
                maxStreak = Mathf.Max(maxStreak, currentStreak);
                currentStreak = 0;
            }

            totalMoves += m.moveCount;
        }

        maxStreak = Mathf.Max(maxStreak, currentStreak);

        stats.winRate = stats.total > 0 ? (float)stats.win / stats.total : 0f;
        stats.avgMove = stats.total > 0 ? (float)totalMoves / stats.total : 0f;
        stats.currentWinStreak = currentStreak;
        stats.maxWinStreak = maxStreak;

        return stats;
    }

    public static Dictionary<string, List<MatchListItemPacket>> GroupByDate(List<MatchListItemPacket> matches)
    {
        Dictionary<string, List<MatchListItemPacket>> grouped = new();

        foreach (var m in matches)
        {
            DateTime time = DateTimeOffset
                .FromUnixTimeMilliseconds(m.startedAt)
                .LocalDateTime;

            string key = time.ToString("yyyy-MM-dd");

            if (!grouped.ContainsKey(key))
                grouped[key] = new List<MatchListItemPacket>();

            grouped[key].Add(m);
        }

        return grouped;
    }
}
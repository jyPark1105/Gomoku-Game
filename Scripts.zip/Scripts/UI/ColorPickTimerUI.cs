﻿using UnityEngine;
using TMPro;
using System;

public class ColorPickTimerUI : MonoBehaviour
{
    public GameObject timerFrame;
    public TMP_Text timerText;

    public Action OnTimerEnd; // 🔥 추가

    float duration;
    double serverStartTime;

    bool isRunning = false;
    bool endNotified = false; // 🔥 추가
    int lastSec = -1;

    public void StartTimer(float totalDuration, double startTime)
    {
        duration = totalDuration;
        serverStartTime = startTime;

        isRunning = true;
        endNotified = false;
        lastSec = -1;

        if (timerText != null)
            timerText.text = "";

        if (timerFrame != null)
            timerFrame.SetActive(false);
    }

    public void StopTimer()
    {
        isRunning = false;
        endNotified = true;

        if (timerText != null)
            timerText.text = "";

        if (timerFrame != null)
            timerFrame.SetActive(false);
    }

    void Update()
    {
        if (!isRunning) return;

        double now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        float remaining = duration - (float)((now - serverStartTime) / 1000.0);

        if (remaining < 0f)
            remaining = 0f;

        int sec = Mathf.CeilToInt(remaining);

        if (remaining <= 5f)
        {
            if (timerFrame != null && !timerFrame.activeSelf)
                timerFrame.SetActive(true);

            if (sec != lastSec)
            {
                if (timerText != null)
                    timerText.text = sec.ToString();

                lastSec = sec;
            }
        }

        if (remaining <= 0f && !endNotified)
        {
            endNotified = true;
            isRunning = false;

            OnTimerEnd?.Invoke(); // 🔥 0초 알림
        }
    }
}
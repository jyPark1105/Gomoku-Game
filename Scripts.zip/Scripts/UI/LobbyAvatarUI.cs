﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LobbyAvatarUI : MonoBehaviour
{
    public GameObject panel;
    public Transform content;
    public GameObject avatarButtonPrefab;
    public LobbyUIManager lobbyUIManager;

    public Button selectToConfirmButton;

    public int avatarCount = 10;

    bool loaded = false;
    bool isSelected = false;

    List<Image> avatarImages = new List<Image>(); // 🔥 모든 이미지 저장

    int selectedIndex = -1;

    private void OnEnable()
    {
        isSelected = false;
        selectToConfirmButton.interactable = isSelected;
    }

    private void Start()
    {
        LoadAvatars();
    }

    void LoadAvatars()
    {
        if (loaded) return;
        loaded = true;

        for (int i = 0; i < avatarCount; i++)
        {
            Sprite sprite = Resources.Load<Sprite>($"Avatars/avatar_{i}");

            if (sprite == null)
            {
                Debug.LogWarning($"avatar_{i} 로드 실패");
                continue;
            }

            // *중요: 버튼과 이미지 컴포넌트 동시에 붙이기*
            GameObject btnObj = Instantiate(avatarButtonPrefab, content);

            Image img = btnObj.GetComponent<Image>();
            img.sprite = sprite;

            avatarImages.Add(img); // 🔥 저장

            int index = i;

            btnObj.GetComponent<Button>().onClick.AddListener(() =>
            {
                OnSelectAvatar(index);
            });
        }
    }

    void OnSelectAvatar(int index)
    {
        // 🔥 선택만
        selectedIndex = index;

        // UI 갱신
        for (int i = 0; i < avatarImages.Count; i++)
        {
            avatarImages[i].color = Color.white;
        }

        avatarImages[index].color = Color.gray;

        // 초기 1회만 실행
        if (!isSelected)
            selectToConfirmButton.interactable = true;
    }

    public void OnClickSelectToConfirmAvatar()
    {
        if (selectedIndex == -1)
        {
            Debug.LogWarning("아바타 선택 안 됨");
            return;
        }

        // 데이터 저장
        PlayerProfile.Instance.avatarIndex = selectedIndex;

        // 서버 전송
        NetworkController.Instance.SendProfile(
            PlayerProfile.Instance.nickname,
            selectedIndex
        );

        // 패널 처리
        panel.SetActive(false);

        // 🔥 UI 흐름 변경
        lobbyUIManager.OnAvatarConfirmed();
    }
}
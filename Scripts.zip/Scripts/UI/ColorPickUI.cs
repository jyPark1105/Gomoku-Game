﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using TMPro;

[System.Serializable]
public class ColorPickSlot
{
    public Button button;
    public Image qImage;
    public TMP_Text valueText;
    public TMP_Text ownerText;  // "본인" / "상대"

    public Image checkImage;  // 체크 이미지

    public int value;

    public bool isSelected; // 결과 반영
    public bool isLocked;   // 선점 상태
    public int ownerPlayerId; // 누가 선택했는지
}

public class ColorPickUI : MonoBehaviour
{
    public ColorPickTimerUI timerUI;

    public GameObject colorPickPanel;

    public ColorPickSlot[] slots; // 🔥 3개

    public TMP_Text noticeText; // "높은 숫자를 택해 선공하세요!", "자동 선택되었습니다!", "대국을 시작합니다!"

    bool isMyPickDone = false;
    bool resultResolved = false;

    Coroutine closeRoutine;

    int myPlayerIdCache;

    public void Show()
    {
        colorPickPanel.SetActive(true);

        isMyPickDone = false;
        resultResolved = false;

        // 값 초기화
        foreach (var slot in slots)
        {
            slot.isSelected = false;
            slot.isLocked = false;
            slot.value = 0;

            if (slot.qImage != null)
                slot.qImage.enabled = true;

            if (slot.valueText != null)
                slot.valueText.text = "";

            if (slot.button != null)
                slot.button.interactable = true;

            if (slot.checkImage != null)
                slot.checkImage.enabled = false;
        }
    }

    public void Hide()
    {
        if (colorPickPanel != null)
            colorPickPanel.SetActive(false);
    }

    // 🔥 버튼 클릭
    public void OnClickSlot(int index)
    {
        if (isMyPickDone) return;

        if (index < 0 || index >= slots.Length) return;

        var slot = slots[index];

        if (slot.isSelected || slot.isLocked) return;

        // 🔥 서버에 선택 요청
        NetworkController.Instance.SendPickColor(index);

        // ❌ 여기서 막지 말 것
        // isMyPickDone = true;

        // 👉 클릭 버튼만 잠금
        if (slot.button != null)
            slot.button.interactable = false;
    }

    void DisableAllButtons()
    {
        foreach (var slot in slots)
        {
            if (slot.button != null)
                slot.button.interactable = false;
        }
    }

    // 🔥 서버에서 결과 받았을 때 호출
    public void ApplySelection(int slotIndex, int playerId, int myPlayerId, int value)
    {
        // ID 저장
        myPlayerIdCache = myPlayerId;

        var slot = slots[slotIndex];

        slot.ownerPlayerId = playerId;
        slot.isSelected = true;
        slot.value = value;

        // 이미지 끄기
        if (slot.qImage != null)
            slot.qImage.enabled = false;

        // 값 텍스트 표시
        bool isMine = (playerId == myPlayerId);

        slot.ownerPlayerId = playerId;
        slot.isSelected = true;

        // ❗ 내 선택이면 공개
        if (isMine)
        {
            slot.valueText.text = value.ToString();

            if (slot.ownerText != null)
                slot.ownerText.text = "본인";
            
            // 🔥 여기서 확정
            isMyPickDone = true;
        }
        else
        {
            // ❗ 상대 선택 → 값 숨김
            slot.valueText.text = "?";

            if (slot.ownerText != null)
                slot.ownerText.text = "상대";
        }

        // 👉 슬롯은 항상 비활성화
        if (slot.button != null)
            slot.button.interactable = false;

        int count = GetSelectedCount();

        if (count == 2 && !resultResolved)
        {
            resultResolved = true;

            // 타이머 끄기
            if (timerUI != null)
                timerUI.StopTimer();

            RevealAllValues();

            ResolvePickResult();

            if (closeRoutine == null)
            {
                closeRoutine = StartCoroutine(Co_CloseAfterDelay());
            }
        }
    }

    IEnumerator Co_CloseAfterDelay()
    {
        yield return new WaitForSeconds(1f);

        if (noticeText != null)
        {
            noticeText.gameObject.SetActive(true);
            noticeText.text = "대국을 시작합니다!";
        }

        yield return new WaitForSeconds(1f);

        ResetUI();
    }

    public void ResetUI()
    {
        foreach (var slot in slots)
        {
            // 텍스트 초기화
            if (slot.valueText != null && !string.IsNullOrEmpty(slot.valueText.text))
                slot.valueText.text = "";

            // 텍스트 초기화
            if (slot.ownerText != null && !string.IsNullOrEmpty(slot.ownerText.text))
                slot.ownerText.text = "";

            // ? 이미지 켜기
            if (slot.qImage != null)
            {
                slot.qImage.enabled = true;
            }

            // 변수 초기화
            slot.isSelected = false;
            slot.isLocked = false;
            slot.value = 0;
            slot.ownerPlayerId = 0;

            // 버튼 활성화
            if (slot.button != null)
            {
                slot.button.interactable = true;
            }

            // 체크 이미지 끄기
            if (slot.checkImage != null)
                slot.checkImage.enabled = false;
        }

        if (noticeText != null)
        {
            // 초기화
            noticeText.text = "높은 숫자를 택해 선공하세요!";
            noticeText.gameObject.SetActive(false);
        }

        if (timerUI != null)
        {
            timerUI.OnTimerEnd = null;
            timerUI.StopTimer();
        }

        isMyPickDone = false;
        resultResolved = false;

        closeRoutine = null;

        // 고르기 루트 패널 끄기
        if (colorPickPanel != null)
            colorPickPanel.SetActive(false);
    }

    public void ResolvePickResult()
    {
        int firstIndex = -1;
        int secondIndex = -1;

        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i].value != 0) // 🔥 변경
            {
                if (firstIndex == -1)
                    firstIndex = i;
                else
                    secondIndex = i;
            }
        }

        if (firstIndex == -1 || secondIndex == -1)
        {
            Debug.LogWarning("❌ 선택 2개 안됨");
            return;
        }

        int v1 = slots[firstIndex].value;
        int v2 = slots[secondIndex].value;

        int winnerIndex = v1 > v2 ? firstIndex : secondIndex;

        Debug.Log($"🎯 흑돌: 슬롯 {winnerIndex} (값: {Mathf.Max(v1, v2)})");

        ShowWinnerCheck(winnerIndex);
    }

    public int GetSelectedCount()
    {
        int count = 0;

        foreach (var slot in slots)
        {
            if (slot.value != 0)
                count++;
        }

        return count;
    }

    public void LockSlot(int slotIndex, int playerId)
    {
        var slot = slots[slotIndex];

        slot.isLocked = true; // 🔥 isSelected 제거
        slot.value = 0;       // 🔥 결과 아직 없음

        if (slot.button != null)
            slot.button.interactable = false;

        if (playerId == myPlayerIdCache)
        {
            isMyPickDone = true;
        }
    }

    void RevealAllValues()
    {
        foreach (var slot in slots)
        {
            if (slot.value != 0)
            {
                if (slot.valueText != null)
                    slot.valueText.text = slot.value.ToString();
            }
        }
    }

    void ShowWinnerCheck(int winnerIndex)
    {
        for (int i = 0; i < slots.Length; i++)
        {
            if (slots[i].checkImage != null)
            {
                // 👉 승자만 ON
                slots[i].checkImage.enabled = (i == winnerIndex);
            }
        }
    }

    public void StartColorPickTimer(float duration, double startTime)
    {
        if (timerUI != null)
        {
            timerUI.OnTimerEnd = ShowAutoPickNotice;
            timerUI.StartTimer(duration, startTime);
        }
    }

    void ShowAutoPickNotice()
    {
        if (resultResolved) return;

        if (noticeText != null)
        {
            noticeText.gameObject.SetActive(true);
            noticeText.text = "자동 선택되었습니다!";
        }

        DisableAllButtons();
    }

}
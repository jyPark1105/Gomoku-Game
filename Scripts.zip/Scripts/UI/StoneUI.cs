﻿using TMPro;
using UnityEngine;
using System.Collections;

public class StoneUI : MonoBehaviour
{
    public TMP_Text moveText;

    int currentFontStage = 0;
    // 0: 초기
    // 1: 1~9
    // 2: 10~99
    // 3: 100+

    public void SetMoveNumber(int num)
    {
        moveText.text = num.ToString();
        moveText.gameObject.SetActive(true);

        // 🔥 1수 진입
        if (num == 1 && currentFontStage < 1)
        {
            moveText.fontSize = 19;
            currentFontStage = 1;
        }
        // 🔥 10수 진입
        else if (num == 10 && currentFontStage < 2)
        {
            moveText.fontSize = 16;
            currentFontStage = 2;
        }
        // 🔥 100수 진입
        else if (num == 100 && currentFontStage < 3)
        {
            moveText.fontSize = 13;
            currentFontStage = 3;
        }
    }

    public void HideMoveNumber()
    {
        if (moveText == null) return;
        moveText.gameObject.SetActive(false);
    }

    public IEnumerator PlayRemoveAnimation()
    {
        float duration = 0.2f;
        float t = 0f;

        RectTransform rt = GetComponent<RectTransform>();
        CanvasGroup cg = GetComponent<CanvasGroup>();

        if (cg == null)
            cg = gameObject.AddComponent<CanvasGroup>();

        Vector3 startScale = rt.localScale;

        while (t < 1f)
        {
            t += Time.deltaTime / duration;

            // Scale down
            rt.localScale = Vector3.Lerp(startScale, Vector3.zero, t);

            // Fade
            cg.alpha = Mathf.Lerp(1f, 0f, t);

            yield return null;
        }
    }
}
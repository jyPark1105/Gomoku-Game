﻿using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 🔥 Replay UI 상태 정의
/// UI는 "버튼 묶음"이 아니라 "상태"로 관리한다.
/// </summary>
public enum ReplayUIState
{
    InGame,        // 게임 중: 계속하기 / 나가기
    GameEnd,       // 게임 종료: 재시작하기 / 복기하기 / 나가기
    Request,       // 상대의 재시작 요청을 받은 상태
    Requesting     // 내가 재시작 요청을 보낸 상태
}

public class ReplayUI : MonoBehaviour
{
    [Header("Managers")]
    public GomokuManager gomokuManager;
    public ReplayManager replayManager;

    [Header("Root UI")]
    public GameObject roomUIRoot;        // 방 내부 패널 UI
    public GameObject gameStartPanel;    // 방 외부 패널 UI
    public GameObject matchHistoryPanel; // 대국 기록 패널 UI
        
    [Header("RoomUIRoot Childs UI")]
    public GameObject inGameUI;          // 게임 플레이 UI
    public GameObject replayUIRoot;      // 복기 화면 루트 UI
    public GameObject replayUIChild;     // 복기 화면 내부 UI 

    [Header("Panels")]
    public GameObject q_PlayingGamePanel;            // 게임 중 메뉴: 계속하기 / 나가기
    public GameObject q_EndGamePanel;           // 게임 종료 메뉴: 재시작하기 / 복기하기 / 나가기
    public GameObject replayRequestPanel;     // 상대가 재시작 요청했을 때
    public GameObject replayRequestingPanel;  // 내가 재시작 요청한 뒤 대기 상태

    [Header("Replay Controls")]
    public GameObject replayControlPanel;     // 복기 재생 UI 전체
    public Slider replaySlider;               // 타임라인 슬라이더
    private bool isSliderDragging = false;

    [Header("Replay Info")]
    public TMPro.TMP_Text speedText;   // ex) 1.00x
    public TMPro.TMP_Text moveText;    // ex) 23 / 84

    private float[] speedList = { 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f };
    private int speedIndex = 2; // 기본 1.0

    // =========================================================
    // 🔥 상태별 UI 표시
    // =========================================================

    /// <summary>
    /// 전달받은 상태에 맞는 패널만 표시
    /// </summary>
    public void Show(ReplayUIState state)
    {
        if (q_PlayingGamePanel != null) q_PlayingGamePanel.SetActive(false);
        if (q_EndGamePanel != null) q_EndGamePanel.SetActive(false);
        if (replayRequestPanel != null) replayRequestPanel.SetActive(false);
        if (replayRequestingPanel != null) replayRequestingPanel.SetActive(false);
        if (replayControlPanel != null) replayControlPanel.SetActive(false);

        switch (state)
        {
            case ReplayUIState.InGame:
                if (q_PlayingGamePanel != null) q_PlayingGamePanel.SetActive(true);
                break;

            case ReplayUIState.GameEnd:
                if (q_EndGamePanel != null) q_EndGamePanel.SetActive(true);
                break;

            case ReplayUIState.Request:
                if (replayRequestPanel != null) replayRequestPanel.SetActive(true);
                break;

            case ReplayUIState.Requesting:
                if (replayRequestingPanel != null) replayRequestingPanel.SetActive(true);
                break;
        }
    }

    /// <summary>
    /// 모든 패널 숨김
    /// </summary>
    public void HideAll()
    {
        if (q_PlayingGamePanel != null) q_PlayingGamePanel.SetActive(false);
        if (q_EndGamePanel != null) q_EndGamePanel.SetActive(false);
        if (replayRequestPanel != null) replayRequestPanel.SetActive(false);
        if (replayRequestingPanel != null) replayRequestingPanel.SetActive(false);
        if (replayControlPanel != null) replayControlPanel.SetActive(false);
    }

    // =========================================================
    // 🔥 GomokuManager / Router 호환용 래퍼 함수
    // =========================================================

    /// <summary>
    /// 예전 gomoku.ShowGameEndPanelPublic(true) 호환용
    /// 게임 종료 패널 표시
    /// </summary>
    public void ShowGameEndPanel()
    {
        Show(ReplayUIState.GameEnd);
    }

    /// <summary>
    /// 예전 gomoku.ShowGameEndPanelPublic(bool) 호환용
    /// true면 게임 종료 패널, false면 전부 닫기
    /// </summary>
    public void ShowGameEndPanel(bool show)
    {
        if (show) Show(ReplayUIState.GameEnd);
        else HideAll();
    }

    /// <summary>
    /// 예전 gomoku.ShowReplayRequestPanelPublic(bool) 호환용
    /// </summary>
    public void ShowReplayRequestPanel(bool show)
    {
        if (show) Show(ReplayUIState.Request);
        else HideAll();
    }

    /// <summary>
    /// 예전 gomoku.ShowReplayRequestingPanelPublic(bool) 호환용
    /// </summary>
    public void ShowReplayRequestingPanel(bool show)
    {
        if (show) Show(ReplayUIState.Requesting);
        else HideAll();
    }

    /// <summary>
    /// 예전 gomoku.HideReplayPanelsPublic() 호환용
    /// </summary>
    public void HideReplayPanels()
    {
        HideAll();
    }

    /// <summary>
    /// 게임 종료 시 직접 호출용
    /// </summary>
    public void ShowGameEndUI()
    {
        Show(ReplayUIState.GameEnd);
    }

    /// <summary>
    /// 재시작 요청 받았을 때 직접 호출용
    /// </summary>
    public void ShowRequestUI()
    {
        Show(ReplayUIState.Request);
    }

    /// <summary>
    /// 재시작 요청 보낸 뒤 대기 상태 직접 호출용
    /// </summary>
    public void ShowRequestingUI()
    {
        Show(ReplayUIState.Requesting);
    }

    // =========================================================
    // 🎮 인게임 / 종료 패널 버튼
    // =========================================================

    /// <summary>
    /// 게임 중 Replay 버튼 눌렀을 때
    /// </summary>
    public void OnClickOpenMenu()
    {
        AudioManager.Instance.PlayClick();
        Show(ReplayUIState.InGame);
    }

    /// <summary>
    /// 계속하기
    /// </summary>
    public void OnClickContinue()
    {
        AudioManager.Instance.PlayClick();
        HideAll();
    }

    /// <summary>
    /// 게임 종료 후 복기하기
    /// </summary>
    public void OnClickWatchReplay()
    {
        AudioManager.Instance.PlayClick();

        string matchId = gomokuManager.GetLastMatchId();

        if (string.IsNullOrEmpty(matchId))
        {
            Debug.LogError("❌ matchId 없음 → 복기 불가");
            return;
        }

        Debug.Log("📡 GET_MATCH 요청: " + matchId);

        NetworkController.Instance.RequestMatchData(matchId);

        HideAll();
    }

    /// <summary>
    /// 게임 종료 후 재시작 요청하기
    /// </summary>
    public void OnClickRestartGameRequest()
    {
        AudioManager.Instance.PlayClick();

        gomokuManager.RequestRestart();
        Show(ReplayUIState.Requesting);
    }

    /// <summary>
    /// 요청 받았을 때 그냥 대기
    /// </summary>
    public void OnClickWait()
    {
        AudioManager.Instance.PlayClick();
    }

    /// <summary>
    /// 나가기
    /// </summary>
    public void OnClickExit()
    {
        AudioManager.Instance.PlayClick();

        HideAll();

        if (gomokuManager.IsReplayMode())
        {
            gomokuManager.ExitReplayMode(); // 🔥 복기 종료
        }
        else
        {
            gomokuManager.LeaveRoom(); // 🔥 진짜 나가기
        }
    }

    // 🔥 복기 시작 전 UI 전환 전용 함수
    public void PrepareReplayView()
    {
        Debug.Log("🎯 Replay UI 전환");

        // 🔥 방 UI 켜기
        if (roomUIRoot != null)
            roomUIRoot.SetActive(true);

        // 🔥 기존 패널 끄기
        if (gomokuManager != null)
        {
            if (matchHistoryPanel != null)
                matchHistoryPanel.SetActive(false);

            if (gameStartPanel != null)
                gameStartPanel.SetActive(false);
        }

        // 게임 플레이 UI 끄기
        if (inGameUI != null)
            inGameUI.SetActive(false);

        // 복기 화면 루트 & 차일드 UI 켜기
        if (replayUIRoot != null)
            replayUIRoot.SetActive(true);
        if (replayUIChild != null)
            replayUIChild.SetActive(true);
    }

    // =========================================================
    // 🎬 복기 컨트롤 UI
    // =========================================================

    /// <summary>
    /// 복기 UI 초기 세팅
    /// </summary>
    public void SetupReplayUI(int moveCount)
    {
        if (replayControlPanel != null)
            replayControlPanel.SetActive(true);

        if (replaySlider != null)
        {
            replaySlider.minValue = 0;
            replaySlider.maxValue = moveCount;
            replaySlider.wholeNumbers = true;
            replaySlider.value = 0;
        }

        speedIndex = 2; // 1.0
        UpdateSpeedText();

        UpdateMoveText(0, moveCount);
    }

    public void UpdateMoveText(int current, int total)
    {
        if (moveText != null)
            moveText.text = $"{current} / {total}";
    }

    /// <summary>
    /// 슬라이더 값 변경 시 해당 수순으로 점프
    /// </summary>
    public void OnSliderChanged(float value)
    {
        // 🔥 [최적화 핵심]
        // 드래그 중에는 게임 상태를 바꾸지 않는다.
        // 이유:
        // - 기존 구조는 매 프레임 JumpTo 호출 → ResetGame + 전체 재렌더링 발생
        // - 모바일에서 CPU 사용량 급증 → 프레임 드랍 발생
        // 해결:
        // - 드래그 중에는 UI만 반영하고 실제 게임 상태는 유지

        if (!isSliderDragging)
            return;

        // 🔥 UI만 업데이트 (텍스트만)
        UpdateMoveText((int)value, (int)replaySlider.maxValue);
    }

    public void OnSliderPointerDown()
    {
        isSliderDragging = true;

        // 🔥 자동 재생 강제 정지
        // 이유:
        // - 드래그 중 자동 재생이 계속 진행되면 UX 깨짐
        // - 사용자가 보고 싶은 수에 고정되어야 함
        if (replayManager != null)
            replayManager.SetPaused(true);
    }

    public void OnSliderPointerUp()
    {
        isSliderDragging = false;

        if (replayManager == null || replaySlider == null)
            return;

        // 🔥 [핵심 최적화]
        // 드래그 끝났을 때 한 번만 JumpTo 실행
        // 이유:
        // - 기존: 드래그 중 계속 JumpTo → 성능 폭발
        // - 개선: 마지막 위치에서만 1회 실행

        int targetIndex = (int)replaySlider.value;

        replayManager.JumpTo(targetIndex);

        // 🔥 자동 재생 다시 시작
        replayManager.SetPaused(false);
    }

    /// <summary>
    /// 슬라이더 값을 현재 replay index와 동기화
    /// </summary>
    public void UpdateSlider()
    {
        if (replaySlider == null || replayManager == null)
            return;

        // 🔥 드래그 중에는 자동 업데이트 막는다
        // 이유:
        // - 드래그 중인데 값이 강제로 바뀌면 UX 깨짐
        if (isSliderDragging)
            return;

        replaySlider.SetValueWithoutNotify(replayManager.GetCurrentIndex());
    }

    // =========================================================
    // ⏸ 복기 조작 버튼
    // =========================================================

    public void OnClickPause()
    {
        if (replayManager == null) return;

        AudioManager.Instance.PlayClick();
        replayManager.TogglePause();
    }
    public void OnClickChangeSpeed()
    {
        if (replayManager == null) return;

        AudioManager.Instance.PlayClick();

        speedIndex++;
        if (speedIndex >= speedList.Length)
            speedIndex = 0;

        float speed = speedList[speedIndex];

        replayManager.SetSpeed(speed);

        UpdateSpeedText();
    }

    void UpdateSpeedText()
    {
        if (speedText != null)
            speedText.text = $"{speedList[speedIndex]:0.00}x";
    }

    public void OnClickStepBack()
    {
        if (replayManager == null) return;

        AudioManager.Instance.PlayClick();
        replayManager.StepBack();
        UpdateSlider();
    }

    public void OnClickStepForward()
    {
        if (replayManager == null) return;

        AudioManager.Instance.PlayClick();
        replayManager.StepForward();
        UpdateSlider();
    }
}
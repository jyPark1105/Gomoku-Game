﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;

public class LobbyNameUI : MonoBehaviour
{
    public TMP_InputField inputField;
    public GameObject panel;
    public LobbyUIManager lobbyUIManager;
    public Button confirmButton;    // 닉네임 확정 버튼
    public Button suggestButton;    // 닉네임 추천 버튼

    public TMP_Text nameWarnText;

    public string currentInputName; // 서버에 전달할 입력값 (이름)
    public string reservedNickname; // 🔥 서버에서 예약된 닉네임

    public bool isSuggestedName = false;
    bool isConfirmed = false;

    private void Start()
    {
        inputField.onSubmit.AddListener(_ => OnClickConfirm());

        inputField.onValueChanged.AddListener(OnInputChanged);
    }

    private void OnEnable()
    {
        // 🔥 패널 열릴 때 초기화
        isConfirmed = false;

        if (!isSuggestedName)
            inputField.text = "";

        confirmButton.interactable = true;
    }

    void OnInputChanged(string value)
    {
        isSuggestedName = false;

        nameWarnText.text = "";
        ResetConfirmState();
    }

    public void OnClickConfirm()
    {
        if (isConfirmed) return;

        string rawName = inputField.text;

        if (string.IsNullOrWhiteSpace(rawName))
        {
            nameWarnText.text = "닉네임을 입력해주세요.";
            return;
        }

        // 🔥 공통 검증 (추천도 포함)
        if (rawName.StartsWith(" ") || rawName.EndsWith(" "))
        {
            nameWarnText.text = "앞뒤 공백은 사용할 수 없습니다.";
            return;
        }

        if (rawName.Contains("  "))
        {
            nameWarnText.text = "공백은 연속으로 사용할 수 없습니다.";
            return;
        }

        if (!TryValidateName(rawName, out string error))
        {
            nameWarnText.text = error;
            return;
        }

        currentInputName = rawName;

        // 🔥 확정하면 예약 닉네임 초기화
        reservedNickname = rawName;

        isConfirmed = true;
        confirmButton.interactable = false;

        // 🔥 무조건 서버 검증
        NetworkController.Instance.SendCheckNickname(rawName);
    }

    bool TryValidateName(string name, out string error)
    {
        error = "";

        int weight = 0;
        int hangulCount = 0;
        int englishCount = 0;

        foreach (char c in name)
        {
            // 🔥 공백
            if (c == ' ')
            {
                weight += 1;
                continue;
            }

            // 🔥 완성형 한글
            if (c >= 0xAC00 && c <= 0xD7A3)
            {
                weight += 2;
                hangulCount++;
                continue;
            }

            // 🔥 영어
            if (char.IsLetter(c))
            {
                weight += char.IsUpper(c) ? 2 : 1;
                englishCount++;
                continue;
            }

            // 🔥 여기 걸리면 자음/모음/특수문자
            if (c >= 0x3131 && c <= 0x318E)
            {
                error = "자음/모음만으로는 닉네임을 만들 수 없습니다.";
            }
            else
            {
                error = "한글, 영어만 사용할 수 있습니다.";
            }

            return false;
        }

        // 🔥 길이 제한
        if (weight > 12)
        {
            error = "닉네임이 너무 깁니다.";
            return false;
        }

        // 🔥 한글 only
        if (hangulCount > 0 && englishCount == 0)
        {
            if (hangulCount < 2)
            {
                error = "닉네임은 한글 2글자 이상이어야 합니다.";
                return false;
            }
        }

        // 🔥 영어 only
        if (englishCount > 0 && hangulCount == 0)
        {
            if (englishCount < 3)
            {
                error = "닉네임은 영어 3글자 이상이어야 합니다.";
                return false;
            }
        }

        // 🔥 혼합
        if (hangulCount > 0 && englishCount > 0)
        {
            if (weight < 4)
            {
                error = "닉네임이 너무 짧습니다.";
                return false;
            }
        }

        return true;
    }

    public void OnClickSuggest()
    {
        Debug.Log("🔥 추천 버튼 눌림");

        if (suggestButton != null)
            suggestButton.interactable = false;

        nameWarnText.text = ""; // 🔥 초기화

        // 🔥 이전 입력 닉네임 예약 해제
        if (!string.IsNullOrEmpty(reservedNickname))
        {
            NetworkController.Instance.SendCancelNickname(reservedNickname);
            reservedNickname = null;
        }

        NetworkController.Instance.SendRequestNicknameSuggest();

        StartCoroutine(Co_SuggestCooldown());
    }

    IEnumerator Co_SuggestCooldown()
    {
        yield return new WaitForSeconds(1f);

        if (suggestButton != null)
            suggestButton.interactable = true;
    }

    public void ResetConfirmState()
    {
        isConfirmed = false;
        isSuggestedName = false;

        reservedNickname = null;

        if (confirmButton != null)
            confirmButton.interactable = true;
    }
}
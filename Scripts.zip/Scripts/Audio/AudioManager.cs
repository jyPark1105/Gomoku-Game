﻿using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance;

    [Header("Audio Sources")]
    public AudioSource bgmSource;
    public AudioSource sfxSource;
    [Header("Extra Source (Tick Only)")]
    public AudioSource tickSource;
    [Range(0f, 1f)]
    public float tickVolume = 0.15f;

    [Header("Clips")]
    public AudioClip bgm;
    public AudioClip clickSound;    // UI 클릭 (Default)
    public AudioClip placeSound;    // 돌 놓기
    public AudioClip invalidSound;  // 클릭 무효화
    public AudioClip tickSound;     // 턴 타이머
    public AudioClip winSound;      // 승리 효과음

    void Awake()
    {
        Instance = this;

        // 🔥 tickSource 없으면 자동 생성
        if (tickSource == null)
        {
            tickSource = gameObject.AddComponent<AudioSource>();
        }

        tickSource.loop = true;
        tickSource.playOnAwake = false;
    }

    void Start()
    {
        PlayBGM();
    }

    public void PlayBGM()
    {
        if (bgm == null) return;

        bgmSource.clip = bgm;
        bgmSource.loop = true;
        bgmSource.Play();
    }

    public void PlayClick()
    {
        sfxSource.PlayOneShot(clickSound);
    }

    public void PlayPlace()
    {
        sfxSource.PlayOneShot(placeSound);
    }

    public void PlayInvalid()
    {
        sfxSource.PlayOneShot(invalidSound);
    }

    public void PlayWin()
    {
        sfxSource.PlayOneShot(winSound);
    }

    public void StartTickLoop()
    {
        if (tickSound == null) return;

        // 🔥 이미 재생 중이면 무시
        if (tickSource.isPlaying) return;

        tickSource.clip = tickSound;
        tickSource.volume = tickVolume;
        tickSource.Play();
    }

    public void StopTickLoop()
    {
        if (!tickSource.isPlaying) return;

        tickSource.Stop();
    }
}